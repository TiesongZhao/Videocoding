#ifndef _TwoDExtension_H_
#define _TwoDExtension_H_

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BLOCK_PARTITION_NUM 7
#define REF_SPATIAL_8x8BLOCK_NUM 6
#define REF_TEMPORAL_8x8BLOCK_NUM 4

#define OVERALL_ALOG_ZTS
#define RESULT_STAT

#ifdef OVERALL_ALOG_ZTS
	#define TWOD_EXTENSION_ALOG
	#define SEARCH_RANGE_ADAPTION
#endif OVERALL_ALOG_ZTS

#ifdef TWOD_EXTENSION_ALOG
	#define SPATIAL_TEMPORAL_ADAPTION
	#define DIST_CHECKING
	#define COST_CHECKING
#endif TWOD_EXTENSION_ALOG

// definition of reference blocks
typedef struct {
	char IsCurImg;
	char IsEdge;
	double Td[2];
	double NMV[2];
	double SpatialWeight;
	double SpatialWeightSet[REF_SPATIAL_8x8BLOCK_NUM];
	double TemporalWeightSet[REF_TEMPORAL_8x8BLOCK_NUM];
} Ref8x8block;
int map_width, map_height;
Ref8x8block **Ref8x8Map;

// definition of Mode-Mapping
extern int Mode2TwoD[16][2];

// definition of reference block position
typedef struct {
	char IsSpatial;
	char delta_x;
	char delta_y;
} RefBlockPos;
extern const RefBlockPos SpatialSet[REF_SPATIAL_8x8BLOCK_NUM];
extern const RefBlockPos TemporalSet[REF_TEMPORAL_8x8BLOCK_NUM];

// definition of optimal mode list
typedef struct {
	unsigned char mode;
	double dist_from_predicted_point;
} OptimalMode;
OptimalMode OptimalModeList[BLOCK_PARTITION_NUM];

// definition of mode decision thresholds
double Th_alpha, Th_beta;	// if dist>alpha || cost>beta*min_cost, stop 

// temporal-spatial weight adaption
double weight_adaption_speed;
double SpatialOptimal[2],TemporalOptimal[2];

// statistics
FILE *fp_stat;

// not hold for first inter frame
int EncodeSeqs;

// definition of functions
int init_map(int width, int height);
void get_2D_value(int bestmode, int best8x8mode, int *Td_x, int *Td_y);
void set_2D_value(int block_x_8x8, int block_y_8x8, int Td_x, int Td_y);
void set_as_previous_map();
int free_map();

void init_TS_weight(int block_x, int block_y);
void TS_weight_adaption(int block_x, int block_y, double alpha);
void BubbleSort_for_optimalmodelist(OptimalMode *array, char length);
void init_OptimalModeList(int block_x, int block_y);
void write_one_record(char *InFile, int NumberBFrames, int QPISlice, int QPPSlice, int QPBSlice,
				 int SearchRange, double TotalTime, double METime, double PSNR, double Bitrates);

#ifdef SEARCH_RANGE_ADAPTION
	// search range adaption
	int pred_search_range;
	double Th_lambda;	// Search range adaption parameter
	void set_NMV(int block_x, int block_y, int mb_type, int *b8mode, int *b8pdir, short bi_pred_me,
		short ******all_mv, short ******bipred_mv1, short ******bipred_mv2, char ***ref_idx, int islice);
	void search_range_prediction(int block_x, int block_y, int input_search_range);
#endif SEARCH_RANGE_ADAPTION

#endif _TwoDExtension_H_
