#include "TwoDExtension.h"

// Mode-Mapping
int Mode2TwoD[16][2]={
	{0,0},	//0		PSKIP  BSKIP_DIRECT
	{0,0},  //1		P16x16
	{0,3},	//2		P16x8
	{3,0},	//3		P8x16
	{3,3},	//4		SMB8x8
	{3,5},	//5		SMB8x4
	{5,3},	//6		SMB4x8
	{5,5},	//7		SMB4x4
	{-1,-1},//8		P8x8
	{5,5},	//9		I4MB
	{0,0},	//10	I16MB
	{-1,-1},//11	IBLOCK
	{-1,-1},//12	SI4MB
	{3,3},	//13	I8MB
	{-1,-1},//14	IPCM
	{-1,-1}	//15	MAXMODE
};

// Temporal-Spatial Set
/*
*   -> delta_x
*   X B C E	
*   A 0 1
*   D 2 3
*/
const RefBlockPos SpatialSet[REF_SPATIAL_8x8BLOCK_NUM]={
	{1,-1,-1},  //X
	{1,-1, 0},	//A
	{1, 0,-1},	//B
	{1, 1,-1},	//C
	{1,-1, 1},	//D
	{1, 2,-1}	//E
};
const RefBlockPos TemporalSet[REF_TEMPORAL_8x8BLOCK_NUM]={
	{0, 0, 0},	//0
	{0, 1, 0},	//1
	{0, 0, 1},	//2
	{0, 1, 1}	//3
};

/*
 ************************************************************************
 * \brief
 *    Initialize MB map for a picture. 
 * \input
 *	  width=img->width, height=img->height
 * \output
 *    0 for error, 1 for succeeded.
 ************************************************************************
 */
int init_map(int width, int height)
{
	int i,j;
	Ref8x8block example;
	map_width=(int)ceil(width/8.0);
	map_height=(int)ceil(height/8.0);
	example.IsCurImg=0;
	example.IsEdge=0;
	example.Td[0]=example.Td[1]=2.0;
	example.NMV[0]=example.NMV[1]=0;
	for(i=0; i< REF_SPATIAL_8x8BLOCK_NUM; i++)
		example.SpatialWeightSet[i]=1.0/REF_SPATIAL_8x8BLOCK_NUM;
	for(i=0; i< REF_TEMPORAL_8x8BLOCK_NUM; i++)
		example.TemporalWeightSet[i]=1.0/REF_TEMPORAL_8x8BLOCK_NUM;
	example.SpatialWeight=0.8;

	//parameter initialization
	weight_adaption_speed=0.1;
	Th_alpha=3.5;
	Th_beta=1.0;
#ifdef SEARCH_RANGE_ADAPTION
	Th_lambda=3.0;
#endif SEARCH_RANGE_ADAPTION
	EncodeSeqs=-1;

	if((Ref8x8Map=(Ref8x8block**)calloc(map_height,sizeof(Ref8x8block*)))==NULL)
	{
		return 0;
	}
	if((Ref8x8Map[0]=(Ref8x8block*)calloc(map_height*map_width,sizeof(Ref8x8block)))==NULL)
	{
		return 0;
	}
	for(i=1; i<map_height; i++)
		Ref8x8Map[i] = Ref8x8Map[i-1] + map_width;
	for (i=0; i<map_height; i++)
	{
		for(j=0; j<map_width; j++)
			Ref8x8Map[i][j] = example;
	}
	return 1;
}

/*!
 ************************************************************************
 * \brief
 *    Get 2D value from Mapping Matrix.
 ************************************************************************
 */
void get_2D_value(int bestmode, int best8x8mode, int *Td_x, int *Td_y)
{
	if(bestmode<0 || bestmode>15)
	{
		*Td_x=-1;
		*Td_y=-1;
		return;
	}
	if(bestmode != 8)
	{
		*Td_x=Mode2TwoD[bestmode][0];
		*Td_y=Mode2TwoD[bestmode][1];
	}
	else
	{
		/*if(best8x8mode==0)
		{
			*Td_x=Mode2TwoD[4][0];
			*Td_y=Mode2TwoD[4][1];
		}
		else
		{*/
			*Td_x=Mode2TwoD[best8x8mode][0];
			*Td_y=Mode2TwoD[best8x8mode][1];
		/*}*/
	}
}
/*!
 ************************************************************************
 * \brief
 *    Set 2D values.
 ************************************************************************
 */
void set_2D_value(int block_x_8x8, int block_y_8x8, int Td_x, int Td_y)
{
	if(Td_x<0 || Td_y<0)
		return;
	Ref8x8Map[block_y_8x8][block_x_8x8].Td[0] = Td_x;
    Ref8x8Map[block_y_8x8][block_x_8x8].Td[1] = Td_y;
}

#ifdef SEARCH_RANGE_ADAPTION
/*!
************************************************************************
* \brief
*    Set normailized 8x8 motion vectors.
* \input
*    block_x=img->block_x, block_y=img->block_y
*    mb_type=currMB->mb_type, b8mode=currMB->b8mode, b8pdir=currMB->b8pdir, bi_pred_me=currMB->bi_pred_me
*    all_mv=img->all_mv, bipred_mv1=img->bipred_mv1, bipred_mv2=img->bipred_mv2
*    ref_idx=enc_picture->ref_idx
************************************************************************
*/
void set_NMV(int block_x, int block_y, int mb_type, int *b8mode, int *b8pdir, short bi_pred_me,
			 short ******all_mv, short ******bipred_mv1, short ******bipred_mv2, char ***ref_idx, int islice)
{
	int ii, jj, kk, block, ref_0, ref_1;
	
	for(block=0; block<4; block++)
	{
		double *Normalized8x8MV = Ref8x8Map[block_y/2+block/2][block_x/2+block%2].NMV;
		if(b8pdir[block]<0) continue;
		Normalized8x8MV[0] = Normalized8x8MV[1] = 0.0;
		for(kk=0; kk<4; kk++)
		{
			ii = block%2*2+kk%2;
			jj = block/2*2+kk/2;
			ref_0 = ref_idx[0][block_y+jj][block_x+ii];
			ref_1 = ref_idx[1][block_y+jj][block_x+ii];
			if(b8pdir[block]==0)
			{
				Normalized8x8MV[0] += all_mv[jj][ii][0][ref_0][b8mode[block]][0] / (ref_0+1.0);
				Normalized8x8MV[1] += all_mv[jj][ii][0][ref_0][b8mode[block]][1] / (ref_0+1.0);
			}
			else if(b8pdir[block]==1)
			{
				Normalized8x8MV[0] += all_mv[jj][ii][1][ref_1][b8mode[block]][0] / (ref_1+1.0);
				Normalized8x8MV[1] += all_mv[jj][ii][1][ref_1][b8mode[block]][1] / (ref_1+1.0);
			}
			else if(b8pdir[block]==2)
			{
				if (bi_pred_me && mb_type==1)
				{
					all_mv  = bi_pred_me == 1 ? bipred_mv1 : bipred_mv2;
					ref_0 = 0;
					ref_1 = 0;
				}
				Normalized8x8MV[0] += all_mv[jj][ii][0][ref_0][b8mode[block]][0] / (ref_0+1.0) / 2.0;
				Normalized8x8MV[1] += all_mv[jj][ii][0][ref_0][b8mode[block]][1] / (ref_0+1.0) / 2.0;
				Normalized8x8MV[0] += all_mv[jj][ii][1][ref_1][b8mode[block]][0] / (ref_1+1.0) / 2.0;
				Normalized8x8MV[1] += all_mv[jj][ii][1][ref_1][b8mode[block]][1] / (ref_1+1.0) / 2.0;
			}			
		}
		Normalized8x8MV[0] /= 4.0;
		Normalized8x8MV[1] /= 4.0;
	}
}

/*!
************************************************************************
* \brief
*    Search range prediction.
* \output
*    pred_search_range (invalid when negtive)
************************************************************************
*/
void search_range_prediction(int block_x, int block_y, int input_search_range)
{
	int kk;
	double *Normalized8x8MV;
	double SRA_mean_x,SRA_mean_y,SRA_sigma_x,SRA_sigma_y;
	int ref_blk_num=0;	
	SRA_mean_x=SRA_mean_y=SRA_sigma_x=SRA_sigma_y=0.0;
	//if(EncodeSeqs<1) return;
	for(kk=0; kk<REF_SPATIAL_8x8BLOCK_NUM; kk++)
	{
		int ref_blk_x = block_x/2 + SpatialSet[kk].delta_x;
		int ref_blk_y = block_y/2 + SpatialSet[kk].delta_y;
		if(ref_blk_x<0 || ref_blk_y<0 || ref_blk_x>=map_width || ref_blk_y>=map_height)
			continue;
		ref_blk_num ++;
		Normalized8x8MV=Ref8x8Map[ref_blk_y][ref_blk_x].NMV;
		SRA_mean_x += Normalized8x8MV[0];
		SRA_mean_y += Normalized8x8MV[1];
		SRA_sigma_x += Normalized8x8MV[0]*Normalized8x8MV[0];
		SRA_sigma_y += Normalized8x8MV[1]*Normalized8x8MV[1];
	}
	if(ref_blk_num>3)
	{
		SRA_sigma_x = SRA_sigma_x/ref_blk_num-SRA_mean_x*SRA_mean_x/ref_blk_num/ref_blk_num;
		SRA_sigma_y = SRA_sigma_y/ref_blk_num-SRA_mean_y*SRA_mean_y/ref_blk_num/ref_blk_num;
		SRA_sigma_x = SRA_sigma_x>0? sqrt(SRA_sigma_x) : 0;
		SRA_sigma_y = SRA_sigma_y>0? sqrt(SRA_sigma_y) : 0;
		pred_search_range = (int)(max(SRA_sigma_x,SRA_sigma_y)*Th_lambda+0.5);
		pred_search_range = min(input_search_range, max(input_search_range/8, pred_search_range));
	}
	else
	{
		pred_search_range=input_search_range;
	}
}
#endif SEARCH_RANGE_ADAPTION

/*!
 ************************************************************************
 * \brief
 *    Set the map as the one of the previous picture.
 ************************************************************************
 */
void set_as_previous_map()
{
	int i,j;
	for (i=0; i<map_height; i++)
	{
		for(j=0; j<map_width; j++)
			Ref8x8Map[i][j].IsCurImg = 0;
	}
}

/*!
 ************************************************************************
 * \brief
 *    Free the memory allocation. 
 * \output
 *    0 for error, 1 for succeeded.
 ************************************************************************
 */
int free_map()
{
	if(Ref8x8Map)
	{
		if (Ref8x8Map[0])
			free (Ref8x8Map[0]);
		else
		{
			return 0;
		}		
		free (Ref8x8Map);		
	} 
	else
	{
		return 0;
	}
	return 1;
}


/*!
 ************************************************************************
 * \brief
 *    Compute all the weights for Blocks of temporal-spatial set.
 *    IsEdge checked.
 ************************************************************************
 */
void init_TS_weight(int block_x, int block_y)
{
	int k;
	double TWeightSum, SWeightSum;
	int ref_x, ref_y;
	int pos_x = block_x/2;
	int pos_y = block_y/2;
	Ref8x8block *CurrRefBlock = &Ref8x8Map[pos_y][pos_x];

	if(EncodeSeqs!=1) return;

	// Spatial weights initialization
	SWeightSum=0.0;
	for(k=0; k<REF_SPATIAL_8x8BLOCK_NUM; k++)
	{
		ref_x = pos_x + SpatialSet[k].delta_x;
		ref_y = pos_y + SpatialSet[k].delta_y;
		if (ref_x<0 || ref_x>=map_width || ref_y<0 || ref_y>=map_height)
		{
			CurrRefBlock->SpatialWeightSet[k] = 0.0;
		}
		else
		{
			CurrRefBlock->SpatialWeightSet[k] = 1.0;
			SWeightSum += 1.0;
		}
	}
	for(k=0; k<REF_SPATIAL_8x8BLOCK_NUM; k++)
	{
		if(SWeightSum!=0)
		{
			CurrRefBlock->SpatialWeightSet[k] /= SWeightSum;
		}
	}

	// Temporal weights initialization
	TWeightSum=0.0;
	for(k=0; k<REF_TEMPORAL_8x8BLOCK_NUM; k++)
	{
		ref_x = pos_x + TemporalSet[k].delta_x;
		ref_y = pos_y + TemporalSet[k].delta_y;
		if (ref_x<0 || ref_x>=map_width || ref_y<0 || ref_y>=map_height)
		{
			CurrRefBlock->TemporalWeightSet[k] = 0.0;
		}
		else
		{
			CurrRefBlock->TemporalWeightSet[k] = 1.0;
			TWeightSum += 1.0;
		}
	}
	for(k=0; k<REF_TEMPORAL_8x8BLOCK_NUM; k++)
	{
		CurrRefBlock->TemporalWeightSet[k] /= TWeightSum;
	}

	if(pos_x==0 || pos_y==0 || pos_x==map_width-1 || pos_y==map_height-1)
	{
		CurrRefBlock->IsEdge = 1;
		CurrRefBlock->SpatialWeight = SWeightSum/(SWeightSum+TWeightSum); 
	}
	else
	{
		CurrRefBlock->IsEdge=0;
	}	
}

/*!
 ************************************************************************
 * \brief
 *    Compute weights for temporal and spatial set.
 ************************************************************************
 */
void TS_weight_adaption(int block_x, int block_y, double alpha)
{
	double SpatialWeight;
	int pos_x = block_x/2;
	int pos_y = block_y/2;
	if(Ref8x8Map[pos_y][pos_x].IsEdge || EncodeSeqs<=1) return;
	if(SpatialOptimal[0]!=TemporalOptimal[0] || SpatialOptimal[1]!=TemporalOptimal[1])
	{
		int block;
		double beta;
		double best_point[2]={0.0,0.0};
		for(block=0; block<4; block++)
		{
			double *TwoDTemp = Ref8x8Map[pos_y+block/2][pos_x+block%2].Td;
			best_point[0] += (TwoDTemp[0]>0)? TwoDTemp[0]:3;
			best_point[1] += (TwoDTemp[1]>0)? TwoDTemp[1]:3;
		}
		best_point[0] /= 4;
		best_point[1] /= 4;
		beta = (SpatialOptimal[0]-TemporalOptimal[0])*(best_point[0]-TemporalOptimal[0])+
			(SpatialOptimal[1]-TemporalOptimal[1])*(best_point[1]-TemporalOptimal[1]);
		beta /= (SpatialOptimal[0]-TemporalOptimal[0])*(SpatialOptimal[0]-TemporalOptimal[0])+
			(SpatialOptimal[1]-TemporalOptimal[1])*(SpatialOptimal[1]-TemporalOptimal[1]);
		SpatialWeight = max(0, min(1,(1-alpha)*Ref8x8Map[pos_y][pos_x].SpatialWeight+alpha*beta));
		for(block=0; block<4; block++)
		{
			Ref8x8Map[pos_y+block/2][pos_x+block%2].SpatialWeight = SpatialWeight;
		}
	}
}

/*!
 ************************************************************************
 * \brief
 *    A bubble sort function.
 ************************************************************************
 */
void BubbleSort_for_modelist(OptimalMode *array, char length)
{
	int i, j;
	OptimalMode temp;
	for(i=0; i<length; i++)
	{
		for(j=length-1; j>i; j--)
		{
			if(array[j].dist_from_predicted_point<array[j-1].dist_from_predicted_point)
			{
				temp = array[j];
				array[j] = array[j-1];
				array[j-1] = temp;
			}
		}
	}
}

/*!
 ************************************************************************
 * \brief
 *    Predict the optimal mode list with the weights pre-computed.
 *	  OptimalModeList[BLOCK_PARTITION_NUM] created.
 ************************************************************************
 */
void init_OptimalModeList(int block_x, int block_y)
{
	int k;
	int pos_x = block_x/2;
	int pos_y = block_y/2;
	if(EncodeSeqs<=1)
	{
		for(k=0; k<BLOCK_PARTITION_NUM; k++)
		{
			OptimalModeList[k].mode = k+1;
            OptimalModeList[k].dist_from_predicted_point = -1;
		}
	}
	else
	{
		Ref8x8block *RefTemp;
		int kk;
		double pred_point_x=0.0, pred_point_y=0.0;
		double SpatialWeight=0.0;
		SpatialOptimal[0]=SpatialOptimal[1]=TemporalOptimal[0]=TemporalOptimal[1]=0.0;

		//Spatial Prediction
		for(k=0,kk=0; k<REF_SPATIAL_8x8BLOCK_NUM; k++)
		{
			if(Ref8x8Map[pos_y][pos_x].SpatialWeightSet[k])
			{
				RefTemp = &Ref8x8Map[pos_y+SpatialSet[k].delta_y][pos_x+SpatialSet[k].delta_x];
				SpatialOptimal[0] += RefTemp->Td[0] * Ref8x8Map[pos_y][pos_x].SpatialWeightSet[k];
				SpatialOptimal[1] += RefTemp->Td[1] * Ref8x8Map[pos_y][pos_x].SpatialWeightSet[k];
				kk ++; SpatialWeight += RefTemp->SpatialWeight;				
			}
		}
		if(kk!=0) SpatialWeight /= kk;

		//Temporal Prediction
		for(k=0; k<REF_TEMPORAL_8x8BLOCK_NUM; k++)
		{
			//if(Ref8x8Map[pos_y][pos_x].TemporalWeightSet[k])
			//{
				RefTemp = &Ref8x8Map[pos_y+TemporalSet[k].delta_y][pos_x+TemporalSet[k].delta_x];
				TemporalOptimal[0] += RefTemp->Td[0] * Ref8x8Map[pos_y][pos_x].TemporalWeightSet[k];
				TemporalOptimal[1] += RefTemp->Td[1] * Ref8x8Map[pos_y][pos_x].TemporalWeightSet[k];				
			//}
		}
		
		//Get the optimal mode
		pred_point_x = SpatialWeight * (SpatialOptimal[0]-TemporalOptimal[0])+TemporalOptimal[0];
		pred_point_y = SpatialWeight * (SpatialOptimal[1]-TemporalOptimal[1])+TemporalOptimal[1];

		for(k=0; k<BLOCK_PARTITION_NUM; k++)
		{
			OptimalModeList[k].mode = k+1;
            OptimalModeList[k].dist_from_predicted_point = 
				sqrt((Mode2TwoD[k+1][0]-pred_point_x)*(Mode2TwoD[k+1][0]-pred_point_x)+
				(Mode2TwoD[k+1][1]-pred_point_y)*(Mode2TwoD[k+1][1]-pred_point_y));
		}
		BubbleSort_for_modelist(OptimalModeList,BLOCK_PARTITION_NUM);
	}	
}

#ifdef RESULT_STAT
void write_one_record(char *InFile, int NumberBFrames, int QPISlice, int QPPSlice, int QPBSlice,
					  int SearchRange, double TotalTime, double METime, double PSNR, double Bitrates)
{
	int FileNum;
	char *FileList[13]={
		"coastguard_qcif.yuv", 
		"foreman_qcif.yuv",
		"mobile_qcif.yuv",
		"mother_qcif.yuv",
		"news_qcif.yuv",
		"paris_qcif.yuv",
		"silent_qcif.yuv",
		"football_cif.yuv",
		"funfair_cif.yuv",
		"garden_cif.yuv",
		"stefan_cif.yuv",
		"table_cif.yuv",
		"bus_cif.yuv"
	};
	for(FileNum=0; FileNum<13; FileNum++)
	{
		if(strcmp(InFile, FileList[FileNum])==0)
			break;
	}
	if(FileNum==13)
	{
		fprintf(fp_stat,"error filename.\n");
		return;
	}
	fprintf(fp_stat,"%d\t%d\t%d\t%d\t%d\t%d\t%5.3f\t%5.3f\t%5.3f\t%6.2f\n",
		FileNum, NumberBFrames, QPISlice, QPPSlice, QPBSlice, SearchRange,
		TotalTime, METime, PSNR, Bitrates);
}

#endif RESULT_STAT