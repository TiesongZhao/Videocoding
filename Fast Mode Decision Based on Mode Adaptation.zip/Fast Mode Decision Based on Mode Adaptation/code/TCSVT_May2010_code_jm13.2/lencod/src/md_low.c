
/*!
 ***************************************************************************
 * \file md_low.c
 *
 * \brief
 *    Main macroblock mode decision functions and helpers
 *
 **************************************************************************
 */

#include <math.h>
#include <limits.h>
#include <float.h>

#include "global.h"
#include "rdopt_coding_state.h"
#include "mb_access.h"
#include "intrarefresh.h"
#include "image.h"
#include "transform8x8.h"
#include "ratectl.h"
#include "mode_decision.h"
#include "fmo.h"
#include "me_umhex.h"
#include "me_umhexsmp.h"
#include "macroblock.h"


//==== MODULE PARAMETERS ====
static imgpel temp_imgY[16][16]; // to temp store the Y data for 8x8 transform
static imgpel temp_imgU[16][16];
static imgpel temp_imgV[16][16];



/*!
*************************************************************************************
* \brief
*    Mode Decision for a macroblock
*************************************************************************************
*/

#ifndef OVERALL_ALOG_ZTS

void encode_one_macroblock_low (Macroblock *currMB)
{

  int         block, mode, i, j, k, dummy;
  char        best_pdir;
  RD_PARAMS   enc_mb;
  char        best_ref[2] = {0, -1};
  int         bmcost[5] = {INT_MAX};
  double      rd_cost = 0, min_rd_cost = 1e30;
  int         cost = 0;
  int         min_cost = INT_MAX, cost_direct=0, have_direct=0, i16mode=0;
  int         intra1 = 0;
  int         temp_cpb = 0;
  int         best_transform_flag = 0;
  int         cost8x8_direct = 0;
  short       islice      = (short) (img->type==I_SLICE);
  short       bslice      = (short) (img->type==B_SLICE);
  short       pslice      = (short) ((img->type==P_SLICE) || (img->type==SP_SLICE));
  short       intra       = (short) (islice || (pslice && img->mb_y==img->mb_y_upd && img->mb_y_upd!=img->mb_y_intra));
  int         lambda_mf[3];
  int         pix_x, pix_y;
  int         prev_mb_nr  = FmoGetPreviousMBNr(img->current_mb_nr);
  Macroblock* prevMB      = (prev_mb_nr >= 0) ? &img->mb_data[prev_mb_nr]:NULL ;

  char   **ipredmodes = img->ipredmode; // Wang Hanli, store the intra prediction mode [blk4x4][blk4x4]
  short   *allmvs = input->IntraProfile ? NULL: img->all_mv[0][0][0][0][0];
  int     ****i4p;  //for non-RD-opt. mode
  imgpel  (*curr_mpr)[16] = img->mpr[0]; // Wang Hanli, current prediction storage

  int tmp_8x8_flag, tmp_no_mbpart;
  // Fast Mode Decision
  short inter_skip = 0;

  // #Step 1: Wang Hanli, get flag_intra_SAD.
  if(input->SearchMode == UM_HEX)
  {
    UMHEX_decide_intrabk_SAD();
  }
  else if (input->SearchMode == UM_HEX_SIMPLE)
  {
	// Get smpUMHEX_flag_intra_SAD.
    smpUMHEX_decide_intrabk_SAD();
  }

  // #Step 2: Wang Hanli, force intra predicted if condition holds true.
  intra |= RandomIntra (img->current_mb_nr);    // Forced Pseudo-Random Intra

  // #Step 3: Wang Hanli, Initialize encoding parameters for MB.
  //===== Setup Macroblock encoding parameters =====
  init_enc_mb_params(currMB, &enc_mb, intra, bslice);

  // reset chroma intra predictor to default
  currMB->c_ipred_mode = DC_PRED_8;

  //=====   S T O R E   C O D I N G   S T A T E   =====
  //---------------------------------------------------
  // #Step 4: Wang Hanli, Store coding state (for rd-optimized mode decision) to cs_cm.
  store_coding_state (currMB, cs_cm);

  if (!intra)
  {
    //===== set direct motion vectors =====
    best_mode = 1;
    if (bslice)
    {
	  // #Step 5: Wang Hanli, Set the direct MV and reference index for B_SLICE only, 
	  //          Wang Hanli, pp. 170 (8.4.1.2.2) and pp. 171 (8.4.1.2.3). 
      Get_Direct_Motion_Vectors (currMB);
    }

    if (input->CtxAdptLagrangeMult == 1)
    {
      get_initial_mb16x16_cost(currMB);
    }

	// #Step 6: Wang Hanli, ME for 16x16 (skip), 16x8, 8x16

    //===== MOTION ESTIMATION FOR 16x16, 16x8, 8x16 BLOCKS =====
    for (min_cost=INT_MAX, mode=1; mode<4; mode++)
    {
      bi_pred_me = 0;
      img->bi_pred_me[mode]=0;
      if (enc_mb.valid[mode] && !inter_skip)
      {
        for (cost=0, block=0; block<(mode==1?1:2); block++) // Wang Hanli, partitioned block index
        {
          update_lambda_costs(&enc_mb, lambda_mf);

		  // #Step 6.1: Wang Hanli, ME for each MB partition, [ouput]: motion_cost, enc_picture->ref_idx, 
		  //            Wang Hanli, enc_picture->mv, img->all_mv, img->bipred_mv1, img->bipred_mv2
          PartitionMotionSearch (currMB, mode, block, lambda_mf);

          //--- set 4x4 block indizes (for getting MV) --- // Wang Hanli, (i,j) = (x,y) of 4x4 blocks
          j = (block==1 && mode==2 ? 2 : 0); // Wang Hanli, 16x8
          i = (block==1 && mode==3 ? 2 : 0); // Wang Hanli, 8x16

          //--- get cost and reference frame for List 0 prediction ---
          bmcost[LIST_0] = INT_MAX;

		  // #Step 6.2, Wang Hanli, calculate the reference cost and the final RD cost for forward prediction
		  //			Wang Hanli, [output]: bmcost[LIST_0]
          list_prediction_cost(currMB, LIST_0, block, mode, enc_mb, bmcost, best_ref);

          if (bslice)
          {

			// #Step 6.3, Wang Hanli, calculate the reference cost and the final RD cost for forward prediction
			//			  Wang Hanli, [output]: bmcost[LIST_1]

            //--- get cost and reference frame for List 1 prediction ---
            bmcost[LIST_1] = INT_MAX;
            list_prediction_cost(currMB, LIST_1, block, mode, enc_mb, bmcost, best_ref);

            // #Step 6.4, Wang Hanli, calculate the reference cost and the final RD cost for forward prediction
			//			  Wang Hanli, [output]: bmcost[BI_PRED]
			//            Wang Hanli, simple combined method for bi-prediction

			// Compute bipredictive cost between best list 0 and best list 1 references
            list_prediction_cost(currMB, BI_PRED, block, mode, enc_mb, bmcost, best_ref);

            // Finally, if mode 16x16, compute cost for bipredictive ME vectore
            if (input->BiPredMotionEstimation && mode == 1)
            {
              list_prediction_cost(currMB, BI_PRED_L0, block, mode, enc_mb, bmcost, 0);
              list_prediction_cost(currMB, BI_PRED_L1, block, mode, enc_mb, bmcost, 0);
            }
            else
            {
              bmcost[BI_PRED_L0] = INT_MAX;
              bmcost[BI_PRED_L1] = INT_MAX;
            }

			// #Step 6.5, Wang Hanli, determine the best prediction direction
			//			  Wang Hanli, [output]: best_pdir, cost, bi_pred_me, img->bi_pred_me, best_ref
						
            // Determine prediction list based on mode cost
            determine_prediction_list(mode, bmcost, best_ref, &best_pdir, &cost, &bi_pred_me);
          }
          else // if (bslice)
          {
            best_pdir  = 0;
            cost      += bmcost[LIST_0];
          }

		  // #Step 6.6, Wang Hanli, Assign enc_picture reference and MV parameters.
		  //			Wang Hanli, If the list determined by prediction direction is not used, 
		  //			Wang Hanli, set reference -1 (ref_idx, ref_pic_id) and MVs 0.
		  //			Wang Hanli, [output]:  enc_picture->ref_idx,  enc_picture->ref_pic_id,  enc_picture->mv
          assign_enc_picture_params(mode, best_pdir, block, enc_mb.list_offset[LIST_0], best_ref[LIST_0], best_ref[LIST_1], bslice);

		  // #Step 6.7, Wang Hanli, record the best reference index and prediction direction.

          //----- set reference frame and direction parameters -----
          if (mode==3)
          {
			// Wang Hanli, 8x8 block based record
            best8x8l0ref [3][block  ] = best8x8l0ref [3][  block+2] = best_ref[LIST_0];
            best8x8pdir  [3][block  ] = best8x8pdir  [3][  block+2] = best_pdir;
            best8x8l1ref [3][block  ] = best8x8l1ref [3][  block+2] = best_ref[LIST_1];
          }
          else if (mode==2)
          {
            best8x8l0ref [2][2*block] = best8x8l0ref [2][2*block+1] = best_ref[LIST_0];
            best8x8pdir  [2][2*block] = best8x8pdir  [2][2*block+1] = best_pdir;
            best8x8l1ref [2][2*block] = best8x8l1ref [2][2*block+1] = best_ref[LIST_1];
          }
          else
          {
            memset(&best8x8l0ref [1][0], best_ref[LIST_0], 4 * sizeof(char));
            memset(&best8x8l1ref [1][0], best_ref[LIST_1], 4 * sizeof(char));
            best8x8pdir  [1][0] = best8x8pdir  [1][1] = best8x8pdir  [1][2] = best8x8pdir  [1][3] = best_pdir;
          }

          //--- set reference frames and motion vectors ---
          if (mode>1 && block==0) // Wang Hanli, similar to assign_enc_picture_params()
            SetRefAndMotionVectors (currMB, block, mode, best_pdir, best_ref[LIST_0], best_ref[LIST_1]);
        } // for (block=0; block<(mode==1?1:2); block++)

		// #Step 6.8, Wang Hanli, judge whether use transform8x8_size
        currMB->luma_transform_size_8x8_flag = 0; // Wang Hanli, default:disabled
        if (input->Transform8x8Mode) //for inter rd-off, set 8x8 to do 8x8 transform
        {
		  // Wang Hanli, set currMB->mb_type, currMB->bi_pred_me, currMB->b8mode[4], 
		  // Wang Hanli, enc_picture->ref_idx, enc_picture->ref_pic_id, currMB->b8pdir[4]
          SetModesAndRefframeForBlocks(currMB, mode);

		  // Wang Hanli, judge whether use transform_size_8x8_flag based on the difference of cost
          currMB->luma_transform_size_8x8_flag = TransformDecision(currMB, -1, &cost); // Wang Hanli, cost may be changed
        }

		// #Step 6.9, Wang Hanli, store best_mode, min_cost, best_transform_flag
        if ((!inter_skip) && (cost < min_cost))
        {
          best_mode = (short) mode;
          min_cost  = cost;
          best_transform_flag = currMB->luma_transform_size_8x8_flag;

          if (input->CtxAdptLagrangeMult == 1)
          {
			// Wang Hanli, update lambda_mf_factor
            adjust_mb16x16_cost(cost);
          }
        }
      } // if (enc_mb.valid[mode])
    } // for (mode=1; mode<4; mode++)

	// #Step 7: Wang Hanli, ME for 8x8, 8x4, 4x8, and 4x4

    if ((!inter_skip) && enc_mb.valid[P8x8])
    {
      giRDOpt_B8OnlyFlag = 1;

      tr8x8.cost8x8 = INT_MAX;
      tr4x4.cost8x8 = INT_MAX;

	  // #Step 7.1: Wang Hanli, store coding state to cs_mb
      //===== store coding state of macroblock =====
      store_coding_state (currMB, cs_mb); // Wang Hanli, seems useless, since the backup information is not changed

      currMB->all_blk_8x8 = -1;

	  // #Step 7.2: Wang Hanli, check the 8x8 mode for four 8x8 blocks
      if (input->Transform8x8Mode)
      {
        tr8x8.cost8x8 = 0;
        //===========================================================
        // Check 8x8 partition with transform size 8x8
        //===========================================================
        //=====  LOOP OVER 8x8 SUB-PARTITIONS  (Motion Estimation & Mode Decision) =====
        for (cost_direct=cbp8x8=cbp_blk8x8=cnt_nonz_8x8=0, block = 0; block < 4; block++)
        {
		  // Wang Hanli, ****cofAC8x8ts[3]: [plane][8x8block][4x4block][level/run][scan_pos]
		  // Wang Hanli, [output]: tr8x8->cost8x8|part8x8mode|part8x8pdir|part8x8l0ref|part8x8l1ref
          // Wang Hanli, tr8x8->rec_mbY(U,V)8x8: reconstruction pixel
		  // Wang Hanli, tr8x8->mpr8x8: prediction pixel value
		  // Wang Hanli, tr8x8->lrec: reconstruction pixel for SI/SP
		  // Wang Hanli, cbp8x8 and cnt_nonz_8x8
		  // Wang Hanli, cofAC8x8ts[0:2][block] stores the img->CofAC coefficients
          submacroblock_mode_decision(enc_mb, &tr8x8, currMB, cofAC8x8ts[0][block], cofAC8x8ts[1][block], cofAC8x8ts[2][block],
            &have_direct, bslice, block, &cost_direct, &cost, &cost8x8_direct, 1);
          best8x8mode       [block] = tr8x8.part8x8mode [block];
          best8x8pdir [P8x8][block] = tr8x8.part8x8pdir [block];
          best8x8l0ref[P8x8][block] = tr8x8.part8x8l0ref[block];
          best8x8l1ref[P8x8][block] = tr8x8.part8x8l1ref[block];
        }

		// Wang Hanli, in order to differentiate from the following 4x4 size check
        // following params could be added in RD_8x8DATA structure
        cbp8_8x8ts      = cbp8x8;
        cbp_blk8_8x8ts  = cbp_blk8x8;
        cnt_nonz8_8x8ts = cnt_nonz_8x8;
        currMB->luma_transform_size_8x8_flag = 0; //switch to 4x4 transform size

        //--- re-set coding state (as it was before 8x8 block coding) ---
        //reset_coding_state (currMB, cs_mb);
      }// if (input->Transform8x8Mode)

	  // #Step 7.3: Wang Hanli, Check 8x8, 8x4, 4x8, 4x4 mode for each 8x8 block with transform size 4x4.
      if (input->Transform8x8Mode != 2) // Wang Hanli, do not force 8x8 transform
      {
        tr4x4.cost8x8 = 0;
        //=================================================================
        // Check 8x8, 8x4, 4x8 and 4x4 partitions with transform size 4x4
        //=================================================================
        //=====  LOOP OVER 8x8 SUB-PARTITIONS  (Motion Estimation & Mode Decision) =====
        for (cost_direct=cbp8x8=cbp_blk8x8=cnt_nonz_8x8=0, block=0; block<4; block++)
        {
          submacroblock_mode_decision(enc_mb, &tr4x4, currMB, cofAC8x8[block], cofAC8x8CbCr[0][block], cofAC8x8CbCr[1][block],
            &have_direct, bslice, block, &cost_direct, &cost, &cost8x8_direct, 0);

          best8x8mode       [block] = tr4x4.part8x8mode [block];
          best8x8pdir [P8x8][block] = tr4x4.part8x8pdir [block];
          best8x8l0ref[P8x8][block] = tr4x4.part8x8l0ref[block];
          best8x8l1ref[P8x8][block] = tr4x4.part8x8l1ref[block];
        }
        //--- re-set coding state (as it was before 8x8 block coding) ---
        // reset_coding_state (currMB, cs_mb);
      }// if (input->Transform8x8Mode != 2)

	  // #Step 7.4: Wang Hanli, Reset coding state (as it was before 8x8 block coding).

      //--- re-set coding state (as it was before 8x8 block coding) ---
      reset_coding_state (currMB, cs_mb);

      // This is not enabled yet since mpr has reverse order.
      if (input->RCEnable)
        rc_store_diff(img->opix_x, img->opix_y, curr_mpr);


	  // #Step 7.5: Wang Hanli, update best mode, min cost.

      //check cost for P8x8 for non-rdopt mode
      if (tr4x4.cost8x8 < min_cost || tr8x8.cost8x8 < min_cost)
      {
        best_mode = P8x8;
        if (input->Transform8x8Mode == 2)
        {
          min_cost = tr8x8.cost8x8;
          currMB->luma_transform_size_8x8_flag=1;
        }
        else if (input->Transform8x8Mode)
        {
          if (tr8x8.cost8x8 < tr4x4.cost8x8)
          {
            min_cost = tr8x8.cost8x8;
            currMB->luma_transform_size_8x8_flag=1;
          }
          else if(tr4x4.cost8x8 < tr8x8.cost8x8)
          {
            min_cost = tr4x4.cost8x8;
            currMB->luma_transform_size_8x8_flag=0;
          }
          else
          {
            if (GetBestTransformP8x8() == 0)
            {
              min_cost = tr4x4.cost8x8;
              currMB->luma_transform_size_8x8_flag=0;
            }
            else
            {
              min_cost = tr8x8.cost8x8;
              currMB->luma_transform_size_8x8_flag=1;
            }
          }
        }
        else
        {
          min_cost = tr4x4.cost8x8;
          currMB->luma_transform_size_8x8_flag=0;
        }
      }// if ((tr4x4.cost8x8 < min_cost || tr8x8.cost8x8 < min_cost))
      giRDOpt_B8OnlyFlag = 0;
    }
    else // if (enc_mb.valid[P8x8])
    {
      tr4x4.cost8x8 = INT_MAX;
    }

    // Find a motion vector for the Skip mode
    if(pslice)
      FindSkipModeMotionVector (currMB);
  }
  else // if (!intra)
  {
    min_cost = INT_MAX;
  }

  // #Step 7.6: Wang Hanli, perform chroma intra prediction

  //========= C H O O S E   B E S T   M A C R O B L O C K   M O D E =========
  //-------------------------------------------------------------------------
  tmp_8x8_flag = currMB->luma_transform_size_8x8_flag;  //save 8x8_flag
  tmp_no_mbpart = currMB->NoMbPartLessThan8x8Flag;      //save no-part-less
  if ((img->yuv_format != YUV400) && (img->yuv_format != YUV444))
    // precompute all chroma intra prediction modes
    IntraChromaPrediction(currMB, NULL, NULL, NULL);

   // #Step 7.6: Wang Hanli, check DIRECT mode
  
  if (enc_mb.valid[0] && bslice) // check DIRECT MODE
  {
	// #Step 7.6.1, Wang Hanli, get the direct cost: cost
    if(have_direct) // Wang Hanli, when submacroblock encoding, for each 4x4 or 8x8 block, the direct mode is checked
    {
      switch(input->Transform8x8Mode)
      {
      case 1: // Mixture of 8x8 & 4x4 transform
        cost = ((cost8x8_direct < cost_direct) || !(enc_mb.valid[5] && enc_mb.valid[6] && enc_mb.valid[7]))
          ? cost8x8_direct : cost_direct;
        break;
      case 2: // 8x8 Transform only
        cost = cost8x8_direct;
        break;
      default: // 4x4 Transform only
        cost = cost_direct;
        break;
      }
    }
    else
    { //!have_direct  Wang Hanli, default consider 4x4 direct base cost
      cost = GetDirectCostMB (currMB, bslice);
    }

	// #Step 7.6.2, Wang Hanli, update the cost: cost
    if (cost!=INT_MAX)
    {
      cost -= (int)floor(16*enc_mb.lambda_md+0.4999);
    }

	// #Step 7.6.3, Wang Hanli, if best mode is direct mode then update 
    if (cost <= min_cost)
    {
      if(active_sps->direct_8x8_inference_flag && input->Transform8x8Mode)
      {
        if(input->Transform8x8Mode==2)
          currMB->luma_transform_size_8x8_flag=1;
        else
        {
          if(cost8x8_direct < cost_direct)
            currMB->luma_transform_size_8x8_flag=1;
          else
            currMB->luma_transform_size_8x8_flag=0;
        }
      }
      else
        currMB->luma_transform_size_8x8_flag=0;

      //Rate control
      if (input->RCEnable)
        rc_store_diff(img->opix_x, img->opix_y, curr_mpr);

      min_cost  = cost;
      best_mode = 0;
      tmp_8x8_flag = currMB->luma_transform_size_8x8_flag;
    }
    else
    {
      currMB->luma_transform_size_8x8_flag = tmp_8x8_flag; // restore if not best
      currMB->NoMbPartLessThan8x8Flag = tmp_no_mbpart; // restore if not best
    }
  }

  // #Step 8: Wang Hanli, check INTRA prediction modes

  min_rd_cost = (double) min_cost;

  // #Step 8.1: Wang Hanli, check INTRA8x8 prediction modes

  if (enc_mb.valid[I8MB]) // check INTRA8x8
  {
    currMB->luma_transform_size_8x8_flag = 1; // at this point cost will ALWAYS be less than min_cost

    currMB->mb_type = I8MB;
    temp_cpb = Mode_Decision_for_new_Intra8x8Macroblock (currMB, enc_mb.lambda_md, &rd_cost);

    if (rd_cost <= min_rd_cost) //HYU_NOTE. bug fix. 08/15/07
    {
      currMB->cbp = temp_cpb;
      if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
      {
        curr_cbp[0] = cmp_cbp[1];  
        curr_cbp[1] = cmp_cbp[2];
      }

      if(enc_mb.valid[I4MB])   //KHHan. bug fix. Oct.15.2007
      {
        //coeffs
        if (input->Transform8x8Mode != 2) 
        {
		  // Wang Hanli, if INTRA4X4 is checked later and INTRA8x8 is the best so far, store img->cofAC to cofAC for backup
          i4p=cofAC; cofAC=img->cofAC; img->cofAC=i4p;
        }
      }

      for(j=0; j<MB_BLOCK_SIZE; j++)
      {
        pix_y = img->pix_y + j;
        for(i=0; i<MB_BLOCK_SIZE; i++)
        {
          pix_x = img->pix_x + i;
          temp_imgY[j][i] = enc_picture->imgY[pix_y][pix_x];
        }
      }

      if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
      {
        for(j=0; j<MB_BLOCK_SIZE; j++)
        {
          pix_y = img->pix_y + j;
          for(i=0; i<MB_BLOCK_SIZE; i++)
          {
            pix_x = img->pix_x + i;
            temp_imgU[j][i] = enc_picture->imgUV[0][pix_y][pix_x]; 
            temp_imgV[j][i] = enc_picture->imgUV[1][pix_y][pix_x];
          }
        }
      }
      
      //Rate control
      if (input->RCEnable)
        rc_store_diff(img->opix_x, img->opix_y, curr_mpr);

	  // Wang Hanli, update the best mode and related RD-cost
      min_rd_cost  = rd_cost; 
      best_mode = I8MB;
      tmp_8x8_flag = currMB->luma_transform_size_8x8_flag;
    }
    else
    {
      currMB->luma_transform_size_8x8_flag = tmp_8x8_flag; // restore if not best
      if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
      {
        cmp_cbp[1] = curr_cbp[0]; 
        cmp_cbp[2] = curr_cbp[1]; 
        currMB->cbp |= cmp_cbp[1];    
        currMB->cbp |= cmp_cbp[2];    
        cmp_cbp[1] = currMB->cbp;   
        cmp_cbp[2] = currMB->cbp;
      }
    }
  }

  // #Step 8.2: Wang Hanli, check INTRA4x4 prediction modes

  if (enc_mb.valid[I4MB]) // check INTRA4x4
  {
    currMB->luma_transform_size_8x8_flag = 0;
    currMB->mb_type = I4MB;
    temp_cpb = Mode_Decision_for_Intra4x4Macroblock (currMB, enc_mb.lambda_md, &rd_cost);

    if (rd_cost <= min_rd_cost) 
    {
      currMB->cbp = temp_cpb;

      //Rate control
      if (input->RCEnable)
        rc_store_diff(img->opix_x, img->opix_y, curr_mpr);

      min_rd_cost  = rd_cost; 
      best_mode = I4MB;
      tmp_8x8_flag = currMB->luma_transform_size_8x8_flag;
    }
    else
    {
      currMB->luma_transform_size_8x8_flag = tmp_8x8_flag; // restore if not best
      if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
      {
        cmp_cbp[1] = curr_cbp[0]; 
        cmp_cbp[2] = curr_cbp[1]; 
        currMB->cbp |= cmp_cbp[1];    
        currMB->cbp |= cmp_cbp[2];    
        cmp_cbp[1] = currMB->cbp;   
        cmp_cbp[2] = currMB->cbp;
      }
      //coeffs Wang Hanli, restore the best transform coefficients
      i4p=cofAC; cofAC=img->cofAC; img->cofAC=i4p;
    }
  }

  // #Step 8.3: Wang Hanli, check INTRA16x16 prediction modes

  if (enc_mb.valid[I16MB]) // check INTRA16x16
  {
    currMB->luma_transform_size_8x8_flag = 0;
	// Wang Hanli, [output]: img->mpr_16x16
    intrapred_16x16 (currMB, PLANE_Y);
    if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
    {
      select_plane(PLANE_U);
      intrapred_16x16 (currMB, PLANE_U);
      select_plane(PLANE_V);
      intrapred_16x16 (currMB, PLANE_V);
      select_plane(PLANE_Y);
    }
    rd_cost = find_sad_16x16 (currMB, &i16mode);

    if (rd_cost < min_rd_cost)
    {
      //Rate control      
      if (input->RCEnable)
        rc_store_diff(img->opix_x,img->opix_y,img->mpr_16x16[0][i16mode]);

      best_mode   = I16MB;      
      currMB->cbp = dct_16x16 (currMB, PLANE_Y, i16mode);
      if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
      {
        select_plane(PLANE_U);
        cmp_cbp[1] = dct_16x16(currMB, PLANE_U, i16mode);
        select_plane(PLANE_V);
        cmp_cbp[2] = dct_16x16(currMB, PLANE_V, i16mode);   

        select_plane(PLANE_Y);
        currMB->cbp |= cmp_cbp[1];    
        currMB->cbp |= cmp_cbp[2];    
        cmp_cbp[1] = currMB->cbp;   
        cmp_cbp[2] = currMB->cbp;
      }

    }
    else
    {
      currMB->luma_transform_size_8x8_flag = tmp_8x8_flag; // restore
      currMB->NoMbPartLessThan8x8Flag = tmp_no_mbpart;     // restore
    }
  }

  intra1 = IS_INTRA(currMB);

  //=====  S E T   F I N A L   M A C R O B L O C K   P A R A M E T E R S ======
  //---------------------------------------------------------------------------
  {

	// #Step 9: Wang Hanli, set MB parameters and Luma residue coding for INTER16x16, 16x8, and 8x16.

    //===== set parameters for chosen mode =====
    SetModesAndRefframeForBlocks (currMB, best_mode);

    if (best_mode==P8x8)
    {
      if (currMB->luma_transform_size_8x8_flag && (cbp8_8x8ts == 0) && input->Transform8x8Mode != 2)
        currMB->luma_transform_size_8x8_flag = 0;	// Wang Hanli, update the flag

	  // Wang Hanli, because the flag is update, reset or restore encoding results 
	  // Wang Hanli, such as ref_idx, all_mv, pred_mv, imgY/UV, cofAC, etc.
      SetCoeffAndReconstruction8x8 (currMB);

      memset(currMB->intra_pred_modes, DC_PRED, MB_BLOCK_PARTITIONS * sizeof(char));
      for (k=0, j = img->block_y; j < img->block_y + BLOCK_MULTIPLE; j++)
        memset(&ipredmodes[j][img->block_x], DC_PRED, BLOCK_MULTIPLE * sizeof(char));
    }
    else
    {
      //===== set parameters for chosen mode =====
      if (best_mode == I8MB) // Wang Hanli, set img->ipredmode and imgY/imgUV for INTRA8x8
      {
		// Wang Hanli, set img->ipredmode
        memcpy(currMB->intra_pred_modes,currMB->intra_pred_modes8x8, MB_BLOCK_PARTITIONS * sizeof(char));
        for(j = img->block_y; j < img->block_y + BLOCK_MULTIPLE; j++)
          memcpy(&img->ipredmode[j][img->block_x],&img->ipredmode8x8[j][img->block_x], BLOCK_MULTIPLE * sizeof(char));

		// Wang Hanli, restore back imgY/imgUV from temp_imgY/imgUV 
        //--- restore reconstruction for 8x8 transform ---
        for(j=0; j<MB_BLOCK_SIZE; j++)
        {
          memcpy(&enc_picture->imgY[img->pix_y + j][img->pix_x],temp_imgY[j], MB_BLOCK_SIZE * sizeof(imgpel));
        }
        if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
        {
          for(j=0; j<MB_BLOCK_SIZE; j++)
          {
            memcpy(&enc_picture->imgUV[0][img->pix_y + j][img->pix_x],temp_imgU[j], MB_BLOCK_SIZE * sizeof(imgpel)); 
            memcpy(&enc_picture->imgUV[1][img->pix_y + j][img->pix_x],temp_imgV[j], MB_BLOCK_SIZE * sizeof(imgpel));
          }
        }
      }

      if ((best_mode!=I4MB)&&(best_mode != I8MB))
      {
        memset(currMB->intra_pred_modes,DC_PRED, MB_BLOCK_PARTITIONS * sizeof(char));
        for(j = img->block_y; j < img->block_y + BLOCK_MULTIPLE; j++)
          memset(&ipredmodes[j][img->block_x],DC_PRED, BLOCK_MULTIPLE * sizeof(char));

        if (best_mode!=I16MB) // Wang Hanli, for inter coding
        {
          if((best_mode>=1) && (best_mode<=3))	
            currMB->luma_transform_size_8x8_flag = best_transform_flag;

		  // Wang Hanli, residue coding for luma componets and only for 16x16, 16x8, 8x16, 
		  // Wang Hanli, because the others are done
		  // Wang Hanli, [output]: currMB->cbp, currMB->cbp_blk, enc_picture->imgY, img->cofAC 
          LumaResidualCoding (currMB);

          if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
          {
            if((currMB->cbp==0 && cmp_cbp[1] == 0 && cmp_cbp[2] == 0) &&(best_mode==0))
              currMB->luma_transform_size_8x8_flag = 0;
          }
          else if((currMB->cbp==0)&&(best_mode==0))
            currMB->luma_transform_size_8x8_flag = 0;

          //Rate control
          if (input->RCEnable)
            rc_store_diff(img->opix_x,img->opix_y,curr_mpr);
        }
      }
    }
	
    //check luma cbp for transform size flag
    if (((currMB->cbp&15) == 0) && !(IS_OLDINTRA(currMB) || currMB->mb_type == I8MB))
      currMB->luma_transform_size_8x8_flag = 0;

	// #Step 10: Wang Hanli, do the intra chroma prediction again, seems redundant.
	//           Wang Hanli,  currMB->c_ipred_mode and  img->mpr_16x16[uv][mode][y][x]

    // precompute all chroma intra prediction modes
    if ((img->yuv_format != YUV400) && (img->yuv_format != YUV444))
      IntraChromaPrediction(currMB, NULL, NULL, NULL);

    img->i16offset = 0;
    dummy = 0;

	// #Step 11: Wang Hanli, chroma residue coding
	//           Wang Hanli, [output]: img->cofDC[uv], img->m7[uv], currMB->cbp
	//			 Wang Hanli, currMB->cbp_blk, img->cofAC[uv], enc_picture->imgUV
	if ((img->yuv_format != YUV400) && (img->yuv_format != YUV444))
      ChromaResidualCoding (currMB);

	// #Step 12: Wang Hanli,  Gets mode offset for intra16x16 mode: img->i16offset
    if (best_mode==I16MB)
    {
      img->i16offset = I16Offset  (currMB->cbp, i16mode);
    }

	// #Step 13: Wang Hanli, get enc_picture->mv[LIST][by][bx][2] from img->all_mv, 
	//           Wang Hanli, set rdopt->all_mv and rdopt->pred_mv from img->all_mv and img->pred_mv.
    SetMotionVectorsMB (currMB, bslice);

	// #Step 14: Wang Hanli, check P-SLICE SKIP mode.
    //===== check for SKIP mode =====
    if((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
    {
      if ((pslice) && best_mode==1 && currMB->cbp==0 && cmp_cbp[1] == 0 && cmp_cbp[2] == 0 &&
        enc_picture->ref_idx[LIST_0][img->block_y][img->block_x]    == 0 &&
        enc_picture->mv     [LIST_0][img->block_y][img->block_x][0] == allmvs[0] &&
        enc_picture->mv     [LIST_0][img->block_y][img->block_x][1] == allmvs[1])
      {
        currMB->mb_type = currMB->b8mode[0] = currMB->b8mode[1] = currMB->b8mode[2] = currMB->b8mode[3] = 0;
        currMB->luma_transform_size_8x8_flag = 0;
      }
    }
    else if ((pslice) && best_mode==1 && currMB->cbp==0 &&
      enc_picture->ref_idx[LIST_0][img->block_y][img->block_x]    == 0 &&
      enc_picture->mv     [LIST_0][img->block_y][img->block_x][0] == allmvs[0] &&
      enc_picture->mv     [LIST_0][img->block_y][img->block_x][1] == allmvs[1])
    {
      currMB->mb_type = currMB->b8mode[0] = currMB->b8mode[1] = currMB->b8mode[2] = currMB->b8mode[3] = 0;
      currMB->luma_transform_size_8x8_flag = 0;
    }

	// Wang Hanli, copy useful information to rdopt variable
    if(img->MbaffFrameFlag)
      set_mbaff_parameters(currMB);
  }

  // Rate control
  if(input->RCEnable && input->RCUpdateMode <= MAX_RC_MODE)
    rc_store_mad(currMB);

  // #Step 15: Wang Hanli, update currMB->prev_cbp, currMB->qp, currMB->delta_qp, img->qp, currMB->prev_cbp 
  // Wang Hanli, currMB->qp_scaled[3], DCT function pointers, 
  update_qp_cbp(currMB, best_mode);

  rdopt->min_rdcost = min_rd_cost;

  if ( (img->MbaffFrameFlag)
    && (img->current_mb_nr%2)
    && (currMB->mb_type ? 0:((bslice) ? !currMB->cbp:1))  // bottom is skip
    && (prevMB->mb_type ? 0:((bslice) ? !prevMB->cbp:1))
    && !(field_flag_inference(currMB) == enc_mb.curr_mb_field)) // top is skip
  {
    rdopt->min_rdcost = 1e30;  // don't allow coding of a MB pair as skip if wrong inference
  }

  // Wang Hanli, update refresh_map[blk8x8_y][blk8x8_x]
  //===== Decide if this MB will restrict the reference frames =====
  if (input->RestrictRef)
    update_refresh_map(intra, intra1, currMB);

  if(input->SearchMode == UM_HEX)
  {
	// Wang Hanli, update flag_intra, fastme_l0_cost, fastme_l1_cost, fastme_ref_cost 
    UMHEX_skip_intrabk_SAD(best_mode, listXsize[enc_mb.list_offset[LIST_0]]);
  }
  else if(input->SearchMode == UM_HEX_SIMPLE)
  {
	// Wang Hanli, update smpUMHEX_flag_intra, smpUMHEX_l0_cost, smpUMHEX_l1_cost
    smpUMHEX_skip_intrabk_SAD(best_mode, listXsize[enc_mb.list_offset[LIST_0]]);
  }

  //--- constrain intra prediction ---
  if(input->UseConstrainedIntraPred && (img->type==P_SLICE || img->type==B_SLICE))
  {
    img->intra_block[img->current_mb_nr] = IS_INTRA(currMB);
  }
}

#endif OVERALL_ALOG_ZTS

#ifdef OVERALL_ALOG_ZTS

void encode_one_macroblock_low (Macroblock *currMB)
{
  int         block, mode, i, j, k, dummy, index;
  RD_PARAMS   enc_mb;
  char        best_ref[2] = {0, -1};
  int         bmcost[5] = {INT_MAX};
  double      rd_cost = 0, min_rd_cost = 1e30;
  int         cost = 0;
  int         min_cost = INT_MAX, cost_direct=0, have_direct=0, i16mode=0;
  int         intra1 = 0;
  int         temp_cpb = 0;
  int         best_transform_flag = 0;
  int         cost8x8_direct = 0;
  short       islice      = (short) (img->type==I_SLICE);
  short       bslice      = (short) (img->type==B_SLICE);
  short       pslice      = (short) ((img->type==P_SLICE) || (img->type==SP_SLICE));
  short       intra       = (short) (islice || (pslice && img->mb_y==img->mb_y_upd && img->mb_y_upd!=img->mb_y_intra));
  int         pix_x, pix_y;
  int         prev_mb_nr  = FmoGetPreviousMBNr(img->current_mb_nr);
  Macroblock* prevMB      = (prev_mb_nr >= 0) ? &img->mb_data[prev_mb_nr]:NULL ;

  char   **ipredmodes = img->ipredmode; // Wang Hanli, store the intra prediction mode [blk4x4][blk4x4]
  short   *allmvs = input->IntraProfile ? NULL: img->all_mv[0][0][0][0][0];
  int     ****i4p;  //for non-RD-opt. mode
  imgpel  (*curr_mpr)[16] = img->mpr[0]; // Wang Hanli, current prediction storage

  int tmp_8x8_flag, tmp_no_mbpart;
  // Fast Mode Decision
  short inter_skip = 0;

  char sub_macroblock_checked=0;
  if(!img->block_x && !img->block_y)
  {
	  EncodeSeqs += 1;
	  set_as_previous_map();
  }
  if(EncodeSeqs ==1)
  {
	  init_TS_weight(img->block_x, img->block_y);
  }
  if(!islice)
  {	  
	  init_OptimalModeList(img->block_x, img->block_y);
  }

  // #Step 1: Wang Hanli, get flag_intra_SAD.
  if(input->SearchMode == UM_HEX)
  {
    UMHEX_decide_intrabk_SAD();
  }
  else if (input->SearchMode == UM_HEX_SIMPLE)
  {
	// Get smpUMHEX_flag_intra_SAD.
    smpUMHEX_decide_intrabk_SAD();
  }

  // #Step 2: Wang Hanli, force intra predicted if condition holds true.
  intra |= RandomIntra (img->current_mb_nr);    // Forced Pseudo-Random Intra

  // #Step 3: Wang Hanli, Initialize encoding parameters for MB.
  //===== Setup Macroblock encoding parameters =====
  init_enc_mb_params(currMB, &enc_mb, intra, bslice);

  // reset chroma intra predictor to default
  currMB->c_ipred_mode = DC_PRED_8;

#ifdef SEARCH_RANGE_ADAPTION
  if(!islice)
  {
	  search_range_prediction(img->block_x, img->block_y, input->search_range);
  }
#endif SEARCH_RANGE_ADAPTION 

  //=====   S T O R E   C O D I N G   S T A T E   =====
  //---------------------------------------------------
  // #Step 4: Wang Hanli, Store coding state (for rd-optimized mode decision) to cs_cm.
  store_coding_state (currMB, cs_cm);

  if (!intra)
  {
    //===== set direct motion vectors =====
    best_mode = 1;
    if (bslice)
    {
	  // #Step 5: Wang Hanli, Set the direct MV and reference index for B_SLICE only, 
	  //          Wang Hanli, pp. 170 (8.4.1.2.2) and pp. 171 (8.4.1.2.3). 
      Get_Direct_Motion_Vectors (currMB);
    }

    if (input->CtxAdptLagrangeMult == 1)
    {
      get_initial_mb16x16_cost(currMB);
    }
	for(min_cost=INT_MAX,index=0; index<BLOCK_PARTITION_NUM; index++)
	{
		mode=OptimalModeList[index].mode;
		if(mode==1)
		{
			// #Step 7.6: Wang Hanli, check DIRECT mode			
			if (enc_mb.valid[0] && bslice) // check DIRECT MODE
			{
				tmp_8x8_flag = currMB->luma_transform_size_8x8_flag;  //save 8x8_flag
				tmp_no_mbpart = currMB->NoMbPartLessThan8x8Flag;      //save no-part-less
				// #Step 7.6.1, Wang Hanli, get the direct cost: cost
				if(have_direct) // Wang Hanli, when submacroblock encoding, for each 4x4 or 8x8 block, the direct mode is checked
				{
					switch(input->Transform8x8Mode)
					{
					case 1: // Mixture of 8x8 & 4x4 transform
						cost = ((cost8x8_direct < cost_direct) || !(enc_mb.valid[5] && enc_mb.valid[6] && enc_mb.valid[7]))
							? cost8x8_direct : cost_direct;
						break;
					case 2: // 8x8 Transform only
						cost = cost8x8_direct;
						break;
					default: // 4x4 Transform only
						cost = cost_direct;
						break;
					}
				}
				else
				{ //!have_direct  Wang Hanli, default consider 4x4 direct base cost
					cost = GetDirectCostMB (currMB, bslice);
				}
				
				// #Step 7.6.2, Wang Hanli, update the cost: cost
				if (cost!=INT_MAX)
				{
					cost -= (int)floor(16*enc_mb.lambda_md+0.4999);
				}
				
				// #Step 7.6.3, Wang Hanli, if best mode is direct mode then update 
				if (cost <= min_cost)
				{
					if(active_sps->direct_8x8_inference_flag && input->Transform8x8Mode)
					{
						if(input->Transform8x8Mode==2)
							currMB->luma_transform_size_8x8_flag=1;
						else
						{
							if(cost8x8_direct < cost_direct)
								currMB->luma_transform_size_8x8_flag=1;
							else
								currMB->luma_transform_size_8x8_flag=0;
						}
					}
					else
						currMB->luma_transform_size_8x8_flag=0;
					
					//Rate control
					if (input->RCEnable)
						rc_store_diff(img->opix_x, img->opix_y, curr_mpr);
					
					min_cost  = cost;
					best_mode = 0;
					tmp_8x8_flag = currMB->luma_transform_size_8x8_flag;
				}
				else
				{
					currMB->luma_transform_size_8x8_flag = tmp_8x8_flag; // restore if not best
					currMB->NoMbPartLessThan8x8Flag = tmp_no_mbpart; // restore if not best
				}
			}
		}
		if(mode<4)
		{
#ifdef DIST_CHECKING
			if(EncodeSeqs>1 && OptimalModeList[index].dist_from_predicted_point>Th_alpha)
			{
				goto InterEnd;
			}
#endif DIST_CHECKING
			if (enc_mb.valid[mode] && (!inter_skip))
			{
				cost=InterModeDecision_ZTS(currMB, enc_mb, bslice, mode);
				if(cost<min_cost)
				{
					best_mode = (short) mode;
					min_cost  = cost;
					best_transform_flag = currMB->luma_transform_size_8x8_flag;	
					if (input->CtxAdptLagrangeMult == 1)
					{
						adjust_mb16x16_cost(cost);
					}
				}
#ifdef COST_CHECKING
				else if (EncodeSeqs>1 && cost>Th_beta*min_cost)
				{
						goto InterEnd;
				}
#endif COST_CHECKING			
			}
		}//if(mode>0 && mode<4)
		else if(!sub_macroblock_checked)
		{
#ifdef DIST_CHECKING
			if(pslice && EncodeSeqs>1 && OptimalModeList[index].dist_from_predicted_point>Th_alpha)
			{
				goto InterEnd;
			}
#endif DIST_CHECKING
			//int Td_x, Td_y;
			sub_macroblock_checked=1;
			if (enc_mb.valid[P8x8] && (!inter_skip))
			{
				giRDOpt_B8OnlyFlag = 1;	
				tr8x8.cost8x8 = INT_MAX;
				tr4x4.cost8x8 = INT_MAX;
					
				//===== store coding state of macroblock =====
				store_coding_state (currMB, cs_mb); 
				
				currMB->all_blk_8x8 = -1;
				if (input->Transform8x8Mode)
				{
					tr8x8.cost8x8 = 0;
					//===========================================================
					// Check 8x8 partition with transform size 8x8
					//===========================================================
					//=====  LOOP OVER 8x8 SUB-PARTITIONS  (Motion Estimation & Mode Decision) =====
					for (cost_direct=cbp8x8=cbp_blk8x8=cnt_nonz_8x8=0, block = 0; block < 4; block++)
					{
						SubInterModeDecision_ZTS(enc_mb, &tr8x8, currMB, cofAC8x8ts[0][block], cofAC8x8ts[1][block], cofAC8x8ts[2][block],
							&have_direct, bslice, block, &cost_direct, &cost, &cost8x8_direct, 1);
						best8x8mode       [block] = tr8x8.part8x8mode [block];
						best8x8pdir [P8x8][block] = tr8x8.part8x8pdir [block];
						best8x8l0ref[P8x8][block] = tr8x8.part8x8l0ref[block];
						best8x8l1ref[P8x8][block] = tr8x8.part8x8l1ref[block];
					}
					cbp8_8x8ts      = cbp8x8;
					cbp_blk8_8x8ts  = cbp_blk8x8;
					cnt_nonz8_8x8ts = cnt_nonz_8x8;
					currMB->luma_transform_size_8x8_flag = 0; //switch to 4x4 transform size
				}// if (input->Transform8x8Mode)		
					
				if (input->Transform8x8Mode != 2)
				{			
					tr4x4.cost8x8 = 0;
					//=================================================================
					// Check 8x8, 8x4, 4x8 and 4x4 partitions with transform size 4x4
					//=================================================================
					//=====  LOOP OVER 8x8 SUB-PARTITIONS  (Motion Estimation & Mode Decision) =====
					for (cost_direct=cbp8x8=cbp_blk8x8=cnt_nonz_8x8=0, block=0; block<4; block++)
					{
						SubInterModeDecision_ZTS(enc_mb, &tr4x4, currMB, cofAC8x8[block], cofAC8x8CbCr[0][block], cofAC8x8CbCr[1][block],
								&have_direct, bslice, block, &cost_direct, &cost, &cost8x8_direct, 0);
						best8x8mode       [block] = tr4x4.part8x8mode [block];
						best8x8pdir [P8x8][block] = tr4x4.part8x8pdir [block];
						best8x8l0ref[P8x8][block] = tr4x4.part8x8l0ref[block];
						best8x8l1ref[P8x8][block] = tr4x4.part8x8l1ref[block];
					}
				}// if (input->Transform8x8Mode != 2)

				//--- re-set coding state (as it was before 8x8 block coding) ---
				reset_coding_state (currMB, cs_mb);
					
				// This is not enabled yet since mpr has reverse order.
				if (input->RCEnable)
					rc_store_diff(img->opix_x, img->opix_y, curr_mpr);				
				if (tr4x4.cost8x8 < min_cost || tr8x8.cost8x8 < min_cost)				
				{
					best_mode = P8x8;
					if (input->Transform8x8Mode == 2)
					{
						min_cost = tr8x8.cost8x8;
						currMB->luma_transform_size_8x8_flag=1;
					}
					else if (input->Transform8x8Mode)
					{
						if (tr8x8.cost8x8 < tr4x4.cost8x8)
						{
							min_cost = tr8x8.cost8x8;
							currMB->luma_transform_size_8x8_flag=1;
						}
						else if(tr4x4.cost8x8 < tr8x8.cost8x8)
						{
							min_cost = tr4x4.cost8x8;
							currMB->luma_transform_size_8x8_flag=0;
						}
						else
						{
							if (GetBestTransformP8x8() == 0)
							{
								min_cost = tr4x4.cost8x8;
								currMB->luma_transform_size_8x8_flag=0;
							}
							else
							{
								min_cost = tr8x8.cost8x8;
								currMB->luma_transform_size_8x8_flag=1;
							}
						}
					}
					else
					{
						min_cost = tr4x4.cost8x8;
						currMB->luma_transform_size_8x8_flag=0;
					}
				}// if ((tr4x4.cost8x8 < min_cost || tr8x8.cost8x8 < min_cost))
#ifdef COST_CHECKING
				else if(EncodeSeqs>1 && tr4x4.cost8x8>Th_beta*min_cost && tr8x8.cost8x8>Th_beta*min_cost)
				{
					goto InterEnd;
				}
#endif COST_CHECKING
				giRDOpt_B8OnlyFlag = 0;
			}//if (enc_mb.valid[P8x8] && (!inter_skip))
			else
			{
				tr4x4.cost8x8 = INT_MAX;
			}
		}//else if(!sub_macroblock_checked)	
		if(pslice)
		{
			FindSkipModeMotionVector (currMB);
		}
	}//for(min_cost=INT_MAX,index=0; index<7; index++)
  }// if (!intra)
  else 
  {
	  min_cost = INT_MAX;
  }
  
#ifdef TWOD_EXTENSION_ALOG
InterEnd:
#endif TWOD_EXTENSION_ALOG
		 
  // #Step 7.6: Wang Hanli, perform chroma intra prediction

  //========= C H O O S E   B E S T   M A C R O B L O C K   M O D E =========
  //-------------------------------------------------------------------------
  tmp_8x8_flag = currMB->luma_transform_size_8x8_flag;  //save 8x8_flag
  tmp_no_mbpart = currMB->NoMbPartLessThan8x8Flag;      //save no-part-less
  if ((img->yuv_format != YUV400) && (img->yuv_format != YUV444))
    // precompute all chroma intra prediction modes
    IntraChromaPrediction(currMB, NULL, NULL, NULL);

  // #Step 8: Wang Hanli, check INTRA prediction modes

  min_rd_cost = (double) min_cost;

  // #Step 8.1: Wang Hanli, check INTRA8x8 prediction modes

  if (enc_mb.valid[I8MB]) // check INTRA8x8
  {
    currMB->luma_transform_size_8x8_flag = 1; // at this point cost will ALWAYS be less than min_cost

    currMB->mb_type = I8MB;
    temp_cpb = Mode_Decision_for_new_Intra8x8Macroblock (currMB, enc_mb.lambda_md, &rd_cost);

    if (rd_cost <= min_rd_cost) //HYU_NOTE. bug fix. 08/15/07
    {
      currMB->cbp = temp_cpb;
      if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
      {
        curr_cbp[0] = cmp_cbp[1];  
        curr_cbp[1] = cmp_cbp[2];
      }

      if(enc_mb.valid[I4MB])   //KHHan. bug fix. Oct.15.2007
      {
        //coeffs
        if (input->Transform8x8Mode != 2) 
        {
		  // Wang Hanli, if INTRA4X4 is checked later and INTRA8x8 is the best so far, store img->cofAC to cofAC for backup
          i4p=cofAC; cofAC=img->cofAC; img->cofAC=i4p;
        }
      }

      for(j=0; j<MB_BLOCK_SIZE; j++)
      {
        pix_y = img->pix_y + j;
        for(i=0; i<MB_BLOCK_SIZE; i++)
        {
          pix_x = img->pix_x + i;
          temp_imgY[j][i] = enc_picture->imgY[pix_y][pix_x];
        }
      }

      if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
      {
        for(j=0; j<MB_BLOCK_SIZE; j++)
        {
          pix_y = img->pix_y + j;
          for(i=0; i<MB_BLOCK_SIZE; i++)
          {
            pix_x = img->pix_x + i;
            temp_imgU[j][i] = enc_picture->imgUV[0][pix_y][pix_x]; 
            temp_imgV[j][i] = enc_picture->imgUV[1][pix_y][pix_x];
          }
        }
      }
      
      //Rate control
      if (input->RCEnable)
        rc_store_diff(img->opix_x, img->opix_y, curr_mpr);

	  // Wang Hanli, update the best mode and related RD-cost
      min_rd_cost  = rd_cost; 
      best_mode = I8MB;
      tmp_8x8_flag = currMB->luma_transform_size_8x8_flag;
    }
    else
    {
      currMB->luma_transform_size_8x8_flag = tmp_8x8_flag; // restore if not best
      if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
      {
        cmp_cbp[1] = curr_cbp[0]; 
        cmp_cbp[2] = curr_cbp[1]; 
        currMB->cbp |= cmp_cbp[1];    
        currMB->cbp |= cmp_cbp[2];    
        cmp_cbp[1] = currMB->cbp;   
        cmp_cbp[2] = currMB->cbp;
      }
    }
  }

  // #Step 8.2: Wang Hanli, check INTRA4x4 prediction modes

  if (enc_mb.valid[I4MB] && (!islice || EncodeSeqs<2 || OptimalModeList[0].mode!=0)) // check INTRA4x4
  {
    currMB->luma_transform_size_8x8_flag = 0;
    currMB->mb_type = I4MB;
    temp_cpb = Mode_Decision_for_Intra4x4Macroblock (currMB, enc_mb.lambda_md, &rd_cost);

    if (rd_cost <= min_rd_cost) 
    {
      currMB->cbp = temp_cpb;

      //Rate control
      if (input->RCEnable)
        rc_store_diff(img->opix_x, img->opix_y, curr_mpr);

      min_rd_cost  = rd_cost; 
      best_mode = I4MB;
      tmp_8x8_flag = currMB->luma_transform_size_8x8_flag;
    }
    else
    {
      currMB->luma_transform_size_8x8_flag = tmp_8x8_flag; // restore if not best
      if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
      {
        cmp_cbp[1] = curr_cbp[0]; 
        cmp_cbp[2] = curr_cbp[1]; 
        currMB->cbp |= cmp_cbp[1];    
        currMB->cbp |= cmp_cbp[2];    
        cmp_cbp[1] = currMB->cbp;   
        cmp_cbp[2] = currMB->cbp;
      }
      //coeffs Wang Hanli, restore the best transform coefficients
      i4p=cofAC; cofAC=img->cofAC; img->cofAC=i4p;
    }
  }

  // #Step 8.3: Wang Hanli, check INTRA16x16 prediction modes

  if (enc_mb.valid[I16MB] && (!islice || EncodeSeqs<2 || OptimalModeList[0].mode!=7)) // check INTRA16x16
  {
    currMB->luma_transform_size_8x8_flag = 0;
	// Wang Hanli, [output]: img->mpr_16x16
    intrapred_16x16 (currMB, PLANE_Y);
    if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
    {
      select_plane(PLANE_U);
      intrapred_16x16 (currMB, PLANE_U);
      select_plane(PLANE_V);
      intrapred_16x16 (currMB, PLANE_V);
      select_plane(PLANE_Y);
    }
    rd_cost = find_sad_16x16 (currMB, &i16mode);

    if (rd_cost < min_rd_cost)
    {
      //Rate control      
      if (input->RCEnable)
        rc_store_diff(img->opix_x,img->opix_y,img->mpr_16x16[0][i16mode]);

      best_mode   = I16MB;      
      currMB->cbp = dct_16x16 (currMB, PLANE_Y, i16mode);
      if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
      {
        select_plane(PLANE_U);
        cmp_cbp[1] = dct_16x16(currMB, PLANE_U, i16mode);
        select_plane(PLANE_V);
        cmp_cbp[2] = dct_16x16(currMB, PLANE_V, i16mode);   

        select_plane(PLANE_Y);
        currMB->cbp |= cmp_cbp[1];    
        currMB->cbp |= cmp_cbp[2];    
        cmp_cbp[1] = currMB->cbp;   
        cmp_cbp[2] = currMB->cbp;
      }

    }
    else
    {
      currMB->luma_transform_size_8x8_flag = tmp_8x8_flag; // restore
      currMB->NoMbPartLessThan8x8Flag = tmp_no_mbpart;     // restore
    }
  }

  intra1 = IS_INTRA(currMB);

  //////////////////////////////////////////////////////////////////////////
  //set the mode map
#ifdef TWOD_EXTENSION_ALOG
  {
	  int kk;
	  int Td_x, Td_y;
	  if(best_mode != P8x8)
	  {
		  get_2D_value(best_mode, 0, &Td_x, &Td_y);
		  for(kk=0; kk<4; kk++)
		  {
			  set_2D_value(img->block_x/2+kk%2, img->block_y/2+kk/2, Td_x, Td_y);
		  }
	  }
	  else
	  {
		  for(kk=0; kk<4; kk++)
		  {
			  get_2D_value(best_mode, best8x8mode[kk], &Td_x, &Td_y);
			  set_2D_value(img->block_x/2+kk%2, img->block_y/2+kk/2, Td_x, Td_y);
		  }
	  }
  }
#ifdef SPATIAL_TEMPORAL_ADAPTION
  if(!islice)
  {
	  TS_weight_adaption(img->block_x, img->block_y, weight_adaption_speed);
  }  
#endif SPATIAL_TEMPORAL_ADAPTION

#endif TWOD_EXTENSION_ALOG
  //////////////////////////////////////////////////////////////////////////
    
  //=====  S E T   F I N A L   M A C R O B L O C K   P A R A M E T E R S ======
  //---------------------------------------------------------------------------
  {

	// #Step 9: Wang Hanli, set MB parameters and Luma residue coding for INTER16x16, 16x8, and 8x16.

    //===== set parameters for chosen mode =====
    SetModesAndRefframeForBlocks (currMB, best_mode);

    if (best_mode==P8x8)
    {
      if (currMB->luma_transform_size_8x8_flag && (cbp8_8x8ts == 0) && input->Transform8x8Mode != 2)
        currMB->luma_transform_size_8x8_flag = 0;	// Wang Hanli, update the flag

	  // Wang Hanli, because the flag is update, reset or restore encoding results 
	  // Wang Hanli, such as ref_idx, all_mv, pred_mv, imgY/UV, cofAC, etc.
      SetCoeffAndReconstruction8x8 (currMB);

      memset(currMB->intra_pred_modes, DC_PRED, MB_BLOCK_PARTITIONS * sizeof(char));
      for (k=0, j = img->block_y; j < img->block_y + BLOCK_MULTIPLE; j++)
        memset(&ipredmodes[j][img->block_x], DC_PRED, BLOCK_MULTIPLE * sizeof(char));
    }
    else
    {
      //===== set parameters for chosen mode =====
      if (best_mode == I8MB) // Wang Hanli, set img->ipredmode and imgY/imgUV for INTRA8x8
      {
		// Wang Hanli, set img->ipredmode
        memcpy(currMB->intra_pred_modes,currMB->intra_pred_modes8x8, MB_BLOCK_PARTITIONS * sizeof(char));
        for(j = img->block_y; j < img->block_y + BLOCK_MULTIPLE; j++)
          memcpy(&img->ipredmode[j][img->block_x],&img->ipredmode8x8[j][img->block_x], BLOCK_MULTIPLE * sizeof(char));

		// Wang Hanli, restore back imgY/imgUV from temp_imgY/imgUV 
        //--- restore reconstruction for 8x8 transform ---
        for(j=0; j<MB_BLOCK_SIZE; j++)
        {
          memcpy(&enc_picture->imgY[img->pix_y + j][img->pix_x],temp_imgY[j], MB_BLOCK_SIZE * sizeof(imgpel));
        }
        if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
        {
          for(j=0; j<MB_BLOCK_SIZE; j++)
          {
            memcpy(&enc_picture->imgUV[0][img->pix_y + j][img->pix_x],temp_imgU[j], MB_BLOCK_SIZE * sizeof(imgpel)); 
            memcpy(&enc_picture->imgUV[1][img->pix_y + j][img->pix_x],temp_imgV[j], MB_BLOCK_SIZE * sizeof(imgpel));
          }
        }
      }

      if ((best_mode!=I4MB)&&(best_mode != I8MB))
      {
        memset(currMB->intra_pred_modes,DC_PRED, MB_BLOCK_PARTITIONS * sizeof(char));
        for(j = img->block_y; j < img->block_y + BLOCK_MULTIPLE; j++)
          memset(&ipredmodes[j][img->block_x],DC_PRED, BLOCK_MULTIPLE * sizeof(char));

        if (best_mode!=I16MB) // Wang Hanli, for inter coding
        {
          if((best_mode>=1) && (best_mode<=3))	
            currMB->luma_transform_size_8x8_flag = best_transform_flag;

		  // Wang Hanli, residue coding for luma componets and only for 16x16, 16x8, 8x16, 
		  // Wang Hanli, because the others are done
		  // Wang Hanli, [output]: currMB->cbp, currMB->cbp_blk, enc_picture->imgY, img->cofAC 
          LumaResidualCoding (currMB);

          if ((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
          {
            if((currMB->cbp==0 && cmp_cbp[1] == 0 && cmp_cbp[2] == 0) &&(best_mode==0))
              currMB->luma_transform_size_8x8_flag = 0;
          }
          else if((currMB->cbp==0)&&(best_mode==0))
            currMB->luma_transform_size_8x8_flag = 0;

          //Rate control
          if (input->RCEnable)
            rc_store_diff(img->opix_x,img->opix_y,curr_mpr);
        }
      }
    }
	
    //check luma cbp for transform size flag
    if (((currMB->cbp&15) == 0) && !(IS_OLDINTRA(currMB) || currMB->mb_type == I8MB))
      currMB->luma_transform_size_8x8_flag = 0;

	// #Step 10: Wang Hanli, do the intra chroma prediction again, seems redundant.
	//           Wang Hanli,  currMB->c_ipred_mode and  img->mpr_16x16[uv][mode][y][x]

    // precompute all chroma intra prediction modes
    if ((img->yuv_format != YUV400) && (img->yuv_format != YUV444))
      IntraChromaPrediction(currMB, NULL, NULL, NULL);

    img->i16offset = 0;
    dummy = 0;

	// #Step 11: Wang Hanli, chroma residue coding
	//           Wang Hanli, [output]: img->cofDC[uv], img->m7[uv], currMB->cbp
	//			 Wang Hanli, currMB->cbp_blk, img->cofAC[uv], enc_picture->imgUV
	if ((img->yuv_format != YUV400) && (img->yuv_format != YUV444))
      ChromaResidualCoding (currMB);

	// #Step 12: Wang Hanli,  Gets mode offset for intra16x16 mode: img->i16offset
    if (best_mode==I16MB)
    {
      img->i16offset = I16Offset  (currMB->cbp, i16mode);
    }

	// #Step 13: Wang Hanli, get enc_picture->mv[LIST][by][bx][2] from img->all_mv, 
	//           Wang Hanli, set rdopt->all_mv and rdopt->pred_mv from img->all_mv and img->pred_mv.
    SetMotionVectorsMB (currMB, bslice);

#ifdef SEARCH_RANGE_ADAPTION
	if(!islice)
	{
		set_NMV(img->block_x, img->block_y, currMB->mb_type, currMB->b8mode, currMB->b8pdir,currMB->bi_pred_me, 
			img->all_mv, img->bipred_mv1, img->bipred_mv2, enc_picture->ref_idx, islice);
	}
#endif SEARCH_RANGE_ADAPTION

	// #Step 14: Wang Hanli, check P-SLICE SKIP mode.
    //===== check for SKIP mode =====
    if((img->yuv_format == YUV444) && !IS_INDEPENDENT(input))
    {
      if ((pslice) && best_mode==1 && currMB->cbp==0 && cmp_cbp[1] == 0 && cmp_cbp[2] == 0 &&
        enc_picture->ref_idx[LIST_0][img->block_y][img->block_x]    == 0 &&
        enc_picture->mv     [LIST_0][img->block_y][img->block_x][0] == allmvs[0] &&
        enc_picture->mv     [LIST_0][img->block_y][img->block_x][1] == allmvs[1])
      {
        currMB->mb_type = currMB->b8mode[0] = currMB->b8mode[1] = currMB->b8mode[2] = currMB->b8mode[3] = 0;
        currMB->luma_transform_size_8x8_flag = 0;
      }
    }
    else if ((pslice) && best_mode==1 && currMB->cbp==0 &&
      enc_picture->ref_idx[LIST_0][img->block_y][img->block_x]    == 0 &&
      enc_picture->mv     [LIST_0][img->block_y][img->block_x][0] == allmvs[0] &&
      enc_picture->mv     [LIST_0][img->block_y][img->block_x][1] == allmvs[1])
    {
      currMB->mb_type = currMB->b8mode[0] = currMB->b8mode[1] = currMB->b8mode[2] = currMB->b8mode[3] = 0;
      currMB->luma_transform_size_8x8_flag = 0;
    }

	// Wang Hanli, copy useful information to rdopt variable
    if(img->MbaffFrameFlag)
      set_mbaff_parameters(currMB);
  }

  // Rate control
  if(input->RCEnable && input->RCUpdateMode <= MAX_RC_MODE)
    rc_store_mad(currMB);

  // #Step 15: Wang Hanli, update currMB->prev_cbp, currMB->qp, currMB->delta_qp, img->qp, currMB->prev_cbp 
  // Wang Hanli, currMB->qp_scaled[3], DCT function pointers, 
  update_qp_cbp(currMB, best_mode);

  rdopt->min_rdcost = min_rd_cost;

  if ( (img->MbaffFrameFlag)
    && (img->current_mb_nr%2)
    && (currMB->mb_type ? 0:((bslice) ? !currMB->cbp:1))  // bottom is skip
    && (prevMB->mb_type ? 0:((bslice) ? !prevMB->cbp:1))
    && !(field_flag_inference(currMB) == enc_mb.curr_mb_field)) // top is skip
  {
    rdopt->min_rdcost = 1e30;  // don't allow coding of a MB pair as skip if wrong inference
  }

  // Wang Hanli, update refresh_map[blk8x8_y][blk8x8_x]
  //===== Decide if this MB will restrict the reference frames =====
  if (input->RestrictRef)
    update_refresh_map(intra, intra1, currMB);

  if(input->SearchMode == UM_HEX)
  {
	// Wang Hanli, update flag_intra, fastme_l0_cost, fastme_l1_cost, fastme_ref_cost 
    UMHEX_skip_intrabk_SAD(best_mode, listXsize[enc_mb.list_offset[LIST_0]]);
  }
  else if(input->SearchMode == UM_HEX_SIMPLE)
  {
	// Wang Hanli, update smpUMHEX_flag_intra, smpUMHEX_l0_cost, smpUMHEX_l1_cost
    smpUMHEX_skip_intrabk_SAD(best_mode, listXsize[enc_mb.list_offset[LIST_0]]);
  }

  //--- constrain intra prediction ---
  if(input->UseConstrainedIntraPred && (img->type==P_SLICE || img->type==B_SLICE))
  {
    img->intra_block[img->current_mb_nr] = IS_INTRA(currMB);
  }
}

#endif OVERALL_ALOG_ZTS