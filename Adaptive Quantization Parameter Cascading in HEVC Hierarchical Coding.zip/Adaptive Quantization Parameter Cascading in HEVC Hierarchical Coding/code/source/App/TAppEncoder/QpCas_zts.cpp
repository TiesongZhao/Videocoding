#include "QpCas_zts.h"

#ifdef QP_CAS_ZTS
	QpCasZtsClass *MyQpCas;
#endif

QpCasZtsClass::QpCasZtsClass()
{
	// init Qstep list
	QList[0] = 0.625;
	QList[1] = 0.6875;
	QList[2] = 0.8125;
	QList[3] = 0.875;
	QList[4] = 1;
	QList[5] = 1.125;
	for (int k=6; k<=51; k++)
	{
		QList[k] = QList[k%6] * pow(2.0, k/6);
	}

	// init update rate
	m_UpdateRate.gamma_r = 0.87;
	m_UpdateRate.mad_r = 0.84;
	m_UpdateRate.mu_r = 0.25;
	m_UpdateRate.nu_r = 0.25;
	delta_l = 0.5;
	m_IQpShift = -2;
	m_L1Shift = 1;
	m_LmShift = 1;
	gop_level_para = 0;
}

QpCasZtsClass::~QpCasZtsClass()
{
	delete []m_dwgt;
	delete []m_rwgt;
	delete []m_Qp;
	delete []m_NumFrmsInLayer;
	delete []m_FrmStat;
	delete []m_FrmStat_old;
	delete []n_a;
	delete []n_b1;
	delete []n_b2;
	delete []n_x;
}

void QpCasZtsClass::InitAll(int NumLayers, int BasicQp, int NumGOPs)
{
	m_BasicQp = BasicQp;
	m_NumLayers = NumLayers;
	m_dwgt = new double[NumLayers];
	m_rwgt = new double[NumLayers];
	m_Qp = new int[NumLayers];
	m_NumFrmsInLayer = new int[NumLayers];
	//m_L1Shift = NumLayers-1;

	// init r-d weight
	m_dwgt[0] = pow(1+2*delta_l,m_NumLayers-1)/(1-delta_l);
	m_rwgt[0] = pow(2.0, -(m_NumLayers-1));
	for (int L=1; L<m_NumLayers; L++)
	{
		m_dwgt[L] = pow(1+2*delta_l,m_NumLayers-1-L);
		m_rwgt[L] = pow(2.0, -(m_NumLayers-L));
	}

	// init frame stat
	m_CurrGOPId = -2;	
	m_NumFrmsInLayer[0] = 1;
	m_NumFrmsInLayer[1] = 1;
	m_NumFrmsInGOP = 2;
	int InitQpSum = 2 * m_BasicQp + 3;
	for (int L=2; L<m_NumLayers; L++)
	{
		m_NumFrmsInLayer[L] = m_NumFrmsInLayer[L-1]<<1;
		m_NumFrmsInGOP += m_NumFrmsInLayer[L];
		InitQpSum += m_NumFrmsInLayer[L] * (m_BasicQp + L + 1);
	}
	m_AveQp = int(floor(InitQpSum*1.0 / m_NumFrmsInGOP + 0.5));
	m_FrmStat = new FrmStatZts[m_NumFrmsInGOP];
	m_FrmStat_old = new FrmStatZts[m_NumFrmsInGOP];

	n_c = QList[m_AveQp];

	// Qp cascading 2
	m_NumGOPs = NumGOPs;

	// init Qp cascading
	m_NumLayers = NumLayers;
	n_a = new double[NumLayers];
	n_b1 = new double[NumLayers];
	n_b2 = new double[NumLayers];
	n_x = new double[NumLayers+1];

#ifdef STAT_ZTS
	fail_num=success_num=0;
#endif
}

void QpCasZtsClass::StartGOP(bool IsIntra)
{
	m_CurrGOPId ++;

	if (IsIntra || m_CurrGOPId < 0) // I frame
	{
		m_Qp[0] = m_BasicQp + 1;
		m_CurrGOPId = -1;
		return;
	}
	else if (m_CurrGOPId == 0) // first gop
	{
		m_Qp[0] = m_BasicQp + 1;
		for (int L=1; L<m_NumLayers; L++)
		{
			m_Qp[L] = m_Qp[0] + m_L1Shift + L - 1;
		}
		m_Qp[m_NumLayers - 1] += (m_LmShift-1);
		m_CurrFrmId = -1;
		return;
	}
	else
	{
		for (int k=0; k<m_NumFrmsInGOP; k++)
		{
			m_FrmStat_old[k] = m_FrmStat[k];
		}
		m_CurrFrmId = -1;
	}

	// update parameters
	if (m_CurrGOPId == 1)
		m_Paras_pred = m_Paras;
	else
		//m_Paras_pred = m_Paras_pred*(1-m_UpdateRate)+m_Paras*m_UpdateRate;
		m_Paras_pred += (m_Paras-m_Paras_pred)*m_UpdateRate;

	int L;
	n_c = QList[m_AveQp];
	for (L=0; L<m_NumLayers; L++)
	{
		n_a[L] = -m_dwgt[L]*m_Paras_pred.gamma[L];
		n_b1[L] = 2*m_rwgt[L]*m_Paras_pred.mu[L]*m_Paras_pred.mad[L];
		n_b2[L] = m_rwgt[L]*m_Paras_pred.nu[L]*m_Paras_pred.mad[L];
		n_x[L] = Qp2Qstep(m_Qp[L])-n_c;
	}
	n_x[m_NumLayers] = 1; // lambda
	
	m_QpCasErr = false;
	CalcLayerQp(0);
	double tmp3=0;
	for (L=0; L<m_NumLayers; L++)
	{
		m_Qp[L] = Qstep2Qp(n_x[L]+n_c);
		//if (m_Qp[L]<m_AveQp-3 || m_Qp[L]>m_AveQp+3 || (L==1 && m_Qp[L]<=m_Qp[L-1]) || (L>1 && m_Qp[L]<m_Qp[L-1]))
		m_Qp[L]= m_Qp[L]<m_AveQp-3? m_AveQp-3: m_Qp[L];
		m_Qp[L] = m_Qp[L]>m_AveQp + 3 ? m_AveQp + 3 : m_Qp[L]; // required. 
		if (L>0 && m_Qp[L]<=m_Qp[L-1])
			m_QpCasErr = true;
		if (L<m_NumLayers-1)
			tmp3+=m_Qp[L]*m_NumFrmsInLayer[L];
	}
	m_Qp[m_NumLayers-1] = int(floor((m_AveQp*m_NumFrmsInGOP-tmp3)/m_NumFrmsInLayer[m_NumLayers-1]));
	if (m_QpCasErr)
	{
			m_Qp[0] = m_BasicQp + 1;
			for (L = 1; L<m_NumLayers; L++)
			{
				m_Qp[L] = m_Qp[0] + m_L1Shift + L - 1;
			}
			m_Qp[m_NumLayers - 1] += (m_LmShift - 1);

#ifdef STAT_ZTS
		fail_num++;
	}
	else
	{
		success_num++;
#endif

	}
}


void QpCasZtsClass::CalcLayerQp(int L)
{
	int M = m_NumLayers-L;

	double F0 = 0;
	if (L>0)
	{
		for (int n=0; n<L; n++)
		{
			double tmp1 = n_x[n]+n_c;
			F0 += n_x[n]*(n_b1[n]/tmp1+n_b2[n])/tmp1/tmp1;
		}
	}

	int i, j, k;
	
	double *VctA = new double[M];
	double *VctB = new double[M];
	double *VctC = new double[M];
	int Mplus1 = M+1;
	double *VctF = new double[Mplus1];
	double *VctE = new double[Mplus1];
	double **Jext = new double *[Mplus1];
	Jext[0] = new double[2*Mplus1*Mplus1];
	for (j=1; j<Mplus1; j++)
	{
		Jext[j] = Jext[j-1]+2*Mplus1;
	}

	int loop = 0;
	while (1)
	{
		loop ++;
		if (loop>=100)
		{
			m_QpCasErr = true;
				return;
		}

		// init vectors
		VctF[0] = F0;
		for (int m=0; m<M; m++)
		{
			int n = L+m;
			double tmp1 = n_x[n]+n_c, tmp2 = 2*n_x[n]-n_c;
			double tmp3 = tmp1*(n_x[n]-n_c);
			double tmp13 = tmp1*tmp1*tmp1;
			if (fabs(tmp1)<0.0001)
			{
				m_QpCasErr = true;
				return;
			}
			VctC[m] = -n_b1[n]*tmp2-n_b2[n]*tmp3;
			VctA[m] = VctC[m]/tmp13/tmp1;
			VctB[m] = 4*n_a[n]*tmp13-2*n_x[m_NumLayers]*(n_b1[n]+n_b2[n]*n_x[n]);
			VctF[0] += n_x[n]*(n_b1[n]/tmp1+n_b2[n])/tmp1/tmp1;
			VctF[m+1] = n_a[n]*tmp13*tmp1+n_x[m_NumLayers]*VctC[m];
		}

		// calculate determinant
		double det = 0;
		for (i=0; i<M; i++)
		{
			double tmp1=VctA[i]*VctC[i];
			for (j=0; j<M; j++)
			{
				if (j==i) continue;
				tmp1 *= VctB[j];
			}
			det += tmp1;
		}
		if (fabs(det)<0.00000001)
		{
			m_QpCasErr = true;
				return;
		}		

		// init matrix
		for (j=0; j<Mplus1; j++)
		{
			for (i=0; i<2*Mplus1; i++)
				Jext[j][i] = 0;
		}
		//for (j=0; j<Mplus1-1; j++)
		for (j=0; j<M; j++)
		{
			Jext[0][j] = VctA[j];
			Jext[j+1][j] = VctB[j];
			//Jext[j+1][Mplus1-1] = VctC[j];
			Jext[j+1][M] = VctC[j];
			Jext[j][j+Mplus1] = 1;
		}
		//Jext[Mplus1-1][2*Mplus1-1] = 1;
		Jext[M][2*M+1] = 1;

		// inverse matrix
		for (i=1; i<2*Mplus1; i++)
		{
			Jext[0][i] /= Jext[0][0];
		}
		Jext[0][0] = 1;
		for (j=1; j<Mplus1; j++)
		{			
			for (i=j; i<2*Mplus1; i++)
			{
				Jext[j][i] -= Jext[j-1][i]*Jext[j][j-1];
			}
			Jext[j][j-1] = 0;
			for (i=j+1; i<2*Mplus1; i++)
			{
				Jext[j][i] /= Jext[j][j];
			}
			Jext[j][j] = 1;
		}
		//for(k=0; k<Mplus1-1; k++)
		for(k=0; k<M; k++)
		{
			for (j=k+1; j<Mplus1; j++)
			{
				double tmp = Jext[k][j];
				for (i=0; i<2*Mplus1; i++)
				{
					Jext[k][i] -= Jext[j][i]*tmp;
				}
			}
		}
		// inverse matrix: Jext[0:Mplus1-1][Mplus1:2*Mplus1-1] 

		// newton method
		double err = 0;
		for (j=0; j<Mplus1; j++)
		{
			VctE[j] = 0;
			for (i=0; i<Mplus1; i++)
			{
				VctE[j] += Jext[j][Mplus1+i]*VctF[i];
			}
			err += VctE[j] * VctE[j];
			n_x[j+L] -= VctE[j];
		}
		if (err < 0.01*Mplus1)
			break;
	}

	delete []VctA;
	delete []VctB;
	delete []VctC;
	delete []VctF;
	delete []VctE;
	delete []Jext[0];
	delete []Jext;
}

double QpCasZtsClass::Qp2Qstep(int Qp)
{
	if (Qp<0 || Qp>51)
	{
		return 0;
	}
	return QList[Qp];
}

int QpCasZtsClass::Qstep2Qp(double Qstep)
{
	int QpM, QpL = 0, QpU = 51;
	while (QpU-QpL>1)
	{
		QpM = (QpL+QpU+1)>>1;
		if(Qstep>=Qp2Qstep(QpM))
			QpL = QpM;
		else
			QpU = QpM;
	}
	Qstep *= Qstep;
	if(Qstep < Qp2Qstep(QpL)*Qp2Qstep(QpU) )
		return QpL;
	return QpU;
}

int QpCasZtsClass::GetLayerQp(int L, bool IsIslice)
{
	if (IsIslice)
		return m_Qp[L] + m_IQpShift;
	return m_Qp[L];
}

void QpCasZtsClass::StoreFrameStat(int TLayer, double MAD, double D, double R)
{
	if (m_CurrGOPId<0) return;
	m_Paras.mad[TLayer] += MAD;
	m_FrmStat[++m_CurrFrmId].L = TLayer;
	m_FrmStat[m_CurrFrmId].Q = Qp2Qstep(m_Qp[TLayer]);
	m_FrmStat[m_CurrFrmId].D = D;
	m_FrmStat[m_CurrFrmId].R = R;
	m_FrmStat[m_CurrFrmId].MAD = MAD;
}


#ifdef STAT_ZTS
double QpCasZtsClass::GetFailRate()
{
	double tot_num = success_num+fail_num;
	return (fail_num/tot_num);
}
#endif

void QpCasZtsClass::EndGOP(bool bEos)
{
	if (m_CurrGOPId<0 || bEos) return;

	// update MAD
	// update D-Q
	for (int L=0; L<m_NumLayers; L++)
	{
		double sum_mad_L = 0;
		double xx_d = 0, xy_d = 0;
		for (int k =0; k<m_NumFrmsInGOP; k++)
		{
			if(m_FrmStat[k].L != L)
				continue;
			sum_mad_L += m_FrmStat[k].MAD;
			xy_d += m_FrmStat[k].Q * m_FrmStat[k].D;
			xx_d += m_FrmStat[k].Q * m_FrmStat[k].Q;
		}
		m_Paras.mad[L] = sum_mad_L/m_NumFrmsInLayer[L];
		m_Paras.gamma[L] = xy_d/xx_d;
	}

	// update R-Q
	double xx_r = 0, yy_r = 0, xy_r = 0;
	double xz_r = 0, yz_r = 0;
	double sum_x = 0, sum_y = 0, sum_z = 0;
	for (int k=0; k<m_NumFrmsInGOP; k++)
	{
		double tmp_y = m_FrmStat[k].MAD/m_FrmStat[k].Q;
		double tmp_x = tmp_y/m_FrmStat[k].Q;
		double tmp_z = m_FrmStat[k].R;
		xx_r += tmp_x*tmp_x;
		xy_r += tmp_x*tmp_y;
		yy_r += tmp_y*tmp_y;
		xz_r += tmp_x*tmp_z;
		yz_r += tmp_y*tmp_z;
		sum_x += tmp_x;
		sum_y += tmp_y;
		sum_z += tmp_z;
	}
	xx_r -= sum_x*sum_x;
	xy_r -= sum_x*sum_y;
	yy_r -= sum_y*sum_y;
	xz_r -= sum_x*sum_z;
	yz_r -= sum_y*sum_z;
	double tmp = xx_r*yy_r - xy_r*xy_r;
	double mu = (xz_r*yy_r-yz_r*xy_r)/tmp;
	double nu = (xx_r*yz_r-xy_r*xz_r)/tmp;

	if (m_CurrGOPId<1)
	{
		for(int L=0; L<m_NumLayers; L++)
		{
			m_Paras.mu[L] = mu;
			m_Paras.nu[L] = nu;
		}
	}
	else
	{
		for(int L=0; L<m_NumLayers; L++)
		{
			xx_r = 0, yy_r = 0, xy_r = 0;
			xz_r = 0, yz_r = 0;
			sum_x = 0, sum_y = 0, sum_z = 0;
			bool pred_fail = false;
			for (int k=0; k<m_NumFrmsInGOP; k++)
			{
				if(m_FrmStat[k].L != L) continue;
				if(m_FrmStat[k].Q==m_FrmStat_old[k].Q)
				{
					pred_fail=true;
					break;
				}
				double tmp_y = m_FrmStat[k].MAD/m_FrmStat[k].Q;
				double tmp_x = tmp_y/m_FrmStat[k].Q;
				double tmp_z = m_FrmStat[k].R;
				xx_r += tmp_x*tmp_x;
				xy_r += tmp_x*tmp_y;
				yy_r += tmp_y*tmp_y;
				xz_r += tmp_x*tmp_z;
				yz_r += tmp_y*tmp_z;
				sum_x += tmp_x;
				sum_y += tmp_y;
				sum_z += tmp_z;
				tmp_y = m_FrmStat_old[k].MAD/m_FrmStat_old[k].Q;
				tmp_x = tmp_y/m_FrmStat_old[k].Q;
				tmp_z = m_FrmStat_old[k].R;
				xx_r += tmp_x*tmp_x;
				xy_r += tmp_x*tmp_y;
				yy_r += tmp_y*tmp_y;
				xz_r += tmp_x*tmp_z;
				yz_r += tmp_y*tmp_z;
				sum_x += tmp_x;
				sum_y += tmp_y;
				sum_z += tmp_z;
			}
			if(pred_fail)
			{
				m_Paras.mu[L] = mu;
				m_Paras.nu[L] = nu;
			}
			else
			{
				xx_r -= sum_x*sum_x;
				xy_r -= sum_x*sum_y;
				yy_r -= sum_y*sum_y;
				xz_r -= sum_x*sum_z;
				yz_r -= sum_y*sum_z;
				tmp = xx_r*yy_r - xy_r*xy_r;
				m_Paras.mu[L] = (xz_r*yy_r-yz_r*xy_r)/tmp;
				m_Paras.nu[L] = (xx_r*yz_r-xy_r*xz_r)/tmp;
			}
		}
	}
}


#ifdef STAT_ZTS
	StatZtsClass *MyStat;
#endif

StatZtsClass::StatZtsClass()
{
	m_SeqNo = -1;
	m_Qp = -1;
	m_YPSNR = 0;
	m_YSSIM = 0;
	m_BR = 0;
}

StatZtsClass::~StatZtsClass()
{
}

void StatZtsClass::SetSequenceNo(std::string InputSequence)
{
	std::string z_FileList[24] = {
		// ClassA
		"Traffic_2560x1600_30_crop.yuv",
		"PeopleOnStreet_2560x1600_30_crop.yuv",
		"NebutaFestival_2560x1600_60_10bit_crop.yuv",
		"SteamLocomotiveTrain_2560x1600_60_10bit_crop.yuv",
		// ClassB
		"Kimono1_1920x1080_24.yuv",
		"ParkScene_1920x1080_24.yuv",
		"Cactus_1920x1080_50.yuv",
		"BQTerrace_1920x1080_60.yuv",
		"BasketballDrive_1920x1080_50.yuv",
		// ClassC
		"RaceHorses_832x480_30.yuv",
		"BQMall_832x480_60.yuv",
		"PartyScene_832x480_50.yuv",
		"BasketballDrill_832x480_50.yuv",
		// ClassD
		"RaceHorses_416x240_30.yuv",
		"BQSquare_416x240_60.yuv",
		"BlowingBubbles_416x240_50.yuv",
		"BasketballPass_416x240_50.yuv",
		// ClassE
		"FourPeople_1280x720_60.yuv",
		"Johnny_1280x720_60.yuv",
		"KristenAndSara_1280x720_60.yuv",
		//ClassF
		"BasketballDrillText_832x480_50.yuv",
		"ChinaSpeed_1024x768_30.yuv",
		"SlideEditing_1280x720_30.yuv",
		"SlideShow_1280x720_20.yuv"
	};
#if defined(_WIN32) || defined(_WIN64)
	std::string::size_type pos1 = InputSequence.find_last_of("\\");
#else
	std::string::size_type pos1 = InputSequence.find_last_of("/");
#endif 
	pos1 ++;
	std::string::size_type pos2 = InputSequence.size();
	std::string input_file_name = InputSequence.substr(pos1, pos2 - pos1);
	for (m_SeqNo = 0; m_SeqNo<24; m_SeqNo++)
	{
		if (z_FileList[m_SeqNo] == input_file_name)
			break;
	}
}

void StatZtsClass::SetQp(int Qp)
{
	m_Qp = Qp;
}

void StatZtsClass::SetYPSNR(double YPSNR)
{
	m_YPSNR = YPSNR;
}

void StatZtsClass::SetYSSIM(double YSSIM)
{
	m_YSSIM = YSSIM;
}

void StatZtsClass::SetBR (double bits)
{
	m_BR = bits;
}

void StatZtsClass::Output(std::string StatFile, double tot_time)
{
	std::ofstream res(StatFile.c_str(), ios::out|ios::app);
#ifdef QP_CAS_ZTS
	res << m_SeqNo << "\t" << m_Qp << "\t" << m_YPSNR << "\t" << m_YSSIM << "\t" << m_BR << "\t" << MyQpCas->GetFailRate() << "\t" << tot_time << endl;
#else
	res << m_SeqNo << "\t" << m_Qp << "\t" << m_YPSNR << "\t" << m_YSSIM << "\t" << m_BR << endl;
#endif 
	res.close();
}

double StatZtsClass::CalculateSSIM(short *ImgX, short *ImgY, int height, int width, int stride)
{
	// height>square_window_size;
	// width>square_window_size;
	int square_window_size = 4;
	int N = square_window_size*square_window_size;
	double c1 = 6.5025, c2 = 58.5225;
	int height_clip = height-square_window_size+1;
	int width_clip = width-square_window_size+1;
	double ssim = 0;
	for (int j=0; j<height_clip; j++)
	{
		for (int i=0; i<width_clip; i++)
		{
			short *start_x = ImgX + j*stride + i;
			short *start_y = ImgY + j*stride + i;
			double mu_x = 0, mu_y = 0, sigma_x2 = 0, sigma_y2 = 0, sigma_xy = 0;
			for (int m=0; m<square_window_size; m++)
			{
				for (int n=0; n<square_window_size; n++)
				{
					short pix_x = *(start_x+m*stride+n);
					short pix_y = *(start_y+m*stride+n);
					mu_x += pix_x;
					mu_y += pix_y;
					sigma_x2 += pix_x*pix_x;
					sigma_y2 += pix_y*pix_y;
					sigma_xy += pix_x*pix_y;
				}
			}
			mu_x /= N;
			mu_y /= N;
			sigma_x2 /= (N-1);
			sigma_x2 -= mu_x*mu_x*N/(N-1);
			sigma_y2 /= (N-1);
			sigma_y2 -= mu_y*mu_y*N/(N-1);
			sigma_xy /= (N-1);
			sigma_xy -= mu_x*mu_y*N/(N-1);
			ssim += (2*mu_x*mu_y+c1)*(2*sigma_xy+c2)/(mu_x*mu_x+mu_y*mu_y+c1)/(sigma_x2+sigma_y2+c2);
		}
	}
	ssim /= (height_clip*width_clip);
	return ssim;
}