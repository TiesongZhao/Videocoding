#ifndef __ZTS_QPCAS_H__
#define __ZTS_QPCAS_H__

#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

#define MAX_LAYER_NUM 7

#define QP_CAS_ZTS

#define STAT_ZTS

class FrmStatZts{
public:
	int L;
	double Q;
	double D;
	double R;
	double MAD;
public:
	FrmStatZts operator = (FrmStatZts &x)
	{
		L = x.L;
		Q = x.Q;
		D = x.D;
		R = x.R;
		MAD = x.MAD;
		return *this;
	}
};

class RDUpdateParasZts{
public:
	RDUpdateParasZts(){;}
	~RDUpdateParasZts(){;}
	double gamma_r;
	double mu_r;
	double nu_r;
	double mad_r;
};

class RDParasZts{
public:
	RDParasZts()
	{
		for (int L=0; L<MAX_LAYER_NUM; L++)
			mu[L] = nu[L] = gamma[L] = mad[L] = 0;
	}
	~RDParasZts(){;}
	RDParasZts operator = (RDParasZts &x)
	{
		for (int L=0; L<MAX_LAYER_NUM; L++)
		{
			mu[L] = x.mu[L];
			nu[L] = x.nu[L];
			gamma[L] = x.gamma[L];
			mad[L] = x.mad[L];
		}
		return *this;
	}
	RDParasZts operator += (const RDParasZts &x)
	{
		for (int L=0; L<MAX_LAYER_NUM; L++)
		{
			mu[L] += x.mu[L];
			nu[L] += x.nu[L];
			gamma[L] += x.gamma[L];
			mad[L] += x.mad[L];
		}
		return *this;
	}
	RDParasZts operator - (RDParasZts &x)
	{
		RDParasZts y;
		for (int L=0; L<MAX_LAYER_NUM; L++)
		{
			y.mu[L] = mu[L] - x.mu[L];
			y.nu[L] = nu[L] - x.nu[L];
			y.gamma[L] = gamma[L] - x.gamma[L];
			y.mad[L] = mad[L] - x.mad[L];
		}
		return y;
	}
	RDParasZts operator * (RDUpdateParasZts &x)
	{
		RDParasZts y;
		for (int L=0; L<MAX_LAYER_NUM; L++)
		{
			y.mu[L] = mu[L] * x.mu_r;
			y.nu[L] = nu[L] * x.nu_r;
			y.gamma[L] = gamma[L] * x.gamma_r;
			y.mad[L] = mad[L] * x.mad_r;
		}
		return y;
	}
public:
	double gamma[MAX_LAYER_NUM];
	double mu[MAX_LAYER_NUM];
	double nu[MAX_LAYER_NUM];
	double mad[MAX_LAYER_NUM]; // maximum GOP=32
};

class QpCasZtsClass{
public:
	QpCasZtsClass();
	~QpCasZtsClass();
	void InitAll(int NumLayers, int BasicQp, int NumGOPs); 
	void StartGOP(bool IsIntra); // Qp cascading
	int GetLayerQp(int L, bool IsSlice);
	void StoreFrameStat(int TLayer, double MAD, double D, double R); // store coding results
	void EndGOP(bool bEos); // update R-Q, D-Q models
#ifdef STAT_ZTS
	double GetFailRate();
#endif

protected:
	double Qp2Qstep(int Qp);
	int Qstep2Qp(double Qstep);

private:
	void CalcLayerQp(int L);

private:
	// inter layer dependency
	int m_NumLayers;
	double delta_l;
	double *m_dwgt; // distortion weight
	double *m_rwgt; // rate weight

	// Qp
	int m_AveQp, m_BasicQp;
	int *m_Qp;
	double QList[52];
	double gop_level_para;

	int m_IQpShift;
	int m_L1Shift;
	int m_LmShift;

	// RD model parameters
	RDParasZts m_Paras, m_Paras_pred;
	int m_NumFrmsInGOP;
	int *m_NumFrmsInLayer;
	FrmStatZts *m_FrmStat, *m_FrmStat_old;
	int m_CurrFrmId;
	int m_CurrGOPId;
	RDUpdateParasZts m_UpdateRate; // mad, d, r
	bool m_QpCasErr;

	// Qp cascading
	double *n_a, *n_b1, *n_b2, n_c;
	double *n_x;

	// Qp cascading 2
	double *n_c_shift;
	int m_NumGOPs;

#ifdef STAT_ZTS
	int fail_num, success_num;
#endif

};


#ifdef QP_CAS_ZTS
	extern QpCasZtsClass *MyQpCas;
#endif


class StatZtsClass{
public:
	StatZtsClass();
	~StatZtsClass();
	double CalculateSSIM(short *ImgX, short *ImgY, int height, int width, int stride);
	void SetSequenceNo(std::string InputSequence);
	void SetQp(int Qp);
	void SetYPSNR(double YPSNR);
    void SetYSSIM(double YSSIM);
	void SetBR(double bits);
	void Output(std::string StatFile, double tot_time);

private:
	int m_SeqNo;
	int m_Qp;
	double m_YPSNR;
	double m_YSSIM;
	double m_BR;
};

#ifdef STAT_ZTS
	extern StatZtsClass *MyStat;
#endif


#endif 