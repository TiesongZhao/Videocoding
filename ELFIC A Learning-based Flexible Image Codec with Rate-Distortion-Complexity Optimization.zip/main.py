import os
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
import torch
from args import get_args
import Learner_image
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.deterministic = False


def main():
    args = get_args()
    Learner_image.Trainer(args).train()
    # Learner_image.Trainer(args).RDC_search_greedy_CA()
    return 0


if __name__ == "__main__":
    main()
