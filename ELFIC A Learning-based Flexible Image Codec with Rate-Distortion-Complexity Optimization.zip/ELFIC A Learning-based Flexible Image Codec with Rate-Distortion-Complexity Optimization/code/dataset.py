import os
from PIL import Image
from glob import glob
from torch.utils.data import Dataset
from torchvision import transforms

class ImageDatasets(Dataset):
    def __init__(self, data_dir, image_size=256):
        self.data_dir = data_dir
        self.image_size = image_size
        if isinstance(self.data_dir, list):
            self.image_path = sorted(glob(os.path.join(self.data_dir[0], "*.*")))
            for dir in self.data_dir[1:]:
                img_path = sorted(glob(os.path.join(dir, "*.*")))
                for path in img_path:
                    self.image_path.append(path)

        else:
            if not os.path.exists(data_dir):
                raise Exception(f"[!] {self.data_dir} not exitd")
            self.image_path = sorted(glob(os.path.join(self.data_dir, "*.*")))


    def __getitem__(self, item):
        image_ori = self.image_path[item]
        image = Image.open(image_ori).convert('RGB')
        transform = transforms.Compose([
            transforms.RandomCrop(self.image_size),
            transforms.RandomHorizontalFlip(),
            transforms.RandomVerticalFlip(),
            transforms.ToTensor(),
        ])
        return transform(image)

    def __len__(self):
        return len(self.image_path)


class ImageDatasetsValid(Dataset):
    def __init__(self, data_dir, image_size=256):
        self.data_dir = data_dir
        self.image_size = image_size

        if not os.path.exists(data_dir):
            raise Exception(f"[!] {self.data_dir} not exitd")

        self.image_path = sorted(glob(os.path.join(self.data_dir, "*.*")))

    def __getitem__(self, item):
        image_ori = self.image_path[item]
        image = Image.open(image_ori).convert('RGB')
        transform = transforms.Compose([
            transforms.ToTensor(),
        ])
        return transform(image)

    def __len__(self):
        return len(self.image_path)



def get_dataset(args, part='all'):
    training_set = ImageDatasets(args.dataset_root)
    if args.search:
        valid_set = ImageDatasetsValid(args.search_root)
    else:
        valid_set = ImageDatasetsValid(args.valid_root)
    if part == 'all':
        return training_set, valid_set
