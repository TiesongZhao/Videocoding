import os
from Base.base_utils import setup_logger, fix_random_seed, \
    AverageMeter, file_path_init, write_yaml, read_yaml
import torch
from tqdm import tqdm
from tensorboardX import SummaryWriter
from flexible_image_model import *
import json
import logging
from dataset import get_dataset
from torch.utils.data import DataLoader
import numpy as np
import random
from loss_ops import RateDistortionLoss, EvaluateLoss
import copy
import datetime


class Trainer(object):
    def __init__(self, args):
        # args
        args.cuda = torch.cuda.is_available()
        self.args = args
        fix_random_seed(args.seed)

        self.stage_step = [step for step in [800000, 1200000, 1600000, 2000000, 2400000]]
        self.grad_clip = 1.0

        # logs
        file_path_init(args)
        self.log_dir = args.log_dir
        os.makedirs(self.log_dir, exist_ok=True)

        self.checkpoints_dir = os.path.join(self.log_dir, "checkpoints")
        os.makedirs(self.checkpoints_dir, exist_ok=True)

        self.summary_dir = os.path.join(self.log_dir, "summary")
        os.makedirs(self.summary_dir, exist_ok=True)
        self.writer = SummaryWriter(logdir=self.summary_dir, comment='info')

        # logger
        setup_logger('base', self.log_dir, 'global', level=logging.INFO, screen=True, tofile=True)
        self.logger = logging.getLogger('base')
        self.logger.info(f'[*] Using GPU = {args.cuda}')
        self.logger.info(f'[*] Start Log To {self.log_dir}')

        # data
        self.frames = args.frames
        self.batch_size = args.batch_size
        self.Height, self.Width, self.Channel = self.args.image_size

        training_set, valid_set = get_dataset(args)
        self.training_set_loader = DataLoader(training_set,
                                              batch_size=self.batch_size,
                                              shuffle=True,
                                              drop_last=True,
                                              num_workers=args.num_workers,
                                              pin_memory=True,
                                              )
        if args.search:
            self.valid_set_loader = DataLoader(valid_set,
                                               batch_size=args.search_batch_size,
                                               shuffle=False,
                                               drop_last=False,
                                               num_workers=8,
                                               pin_memory=True,
                                               )
        else:
            self.valid_set_loader = DataLoader(valid_set,
                                               batch_size=1,
                                               shuffle=False,
                                               drop_last=False,
                                               num_workers=1,
                                               pin_memory=True,
                                               )
        self.logger.info(f'[*] Train File Account For {len(training_set)}, val {len(valid_set)}')

        # epoch
        self.num_epochs = args.epochs
        self.start_epoch = 0
        self.global_step = 0
        self.global_eval_step = 0
        self.global_epoch = 0
        self.stop_count = 0

        # model
        self.mode_type = args.mode_type
        self.rate_list = args.rate_list

        self.graph = GainCA(rate_point=len(self.rate_list)).cuda()

        # loss
        if self.mode_type == "PSNR":
            self.loss = RateDistortionLoss(target='mse')
        elif self.mode_type == "SSIM":
            self.loss = RateDistortionLoss(target='ssim')

        # device
        self.cuda = args.use_gpu
        self.device = next(self.graph.parameters()).device
        self.logger.info(
            f'[*] Total Parameters = {sum(p.numel() for p in self.graph.parameters() if p.requires_grad)}')

        self.configure_optimizers(args)

        self.lowest_val_loss = float("inf")

        if args.resume:
            self.resume()
        elif args.load_pretrain:
            self.pretrain()
        else:
            self.logger.info("[*] Train From Scratch")
        data = self.graph.cfg_candidates
        with open(os.path.join(self.log_dir, 'setting.json'), 'w') as f:
            flags_dict = {k: vars(args)[k] for k in vars(args)}
            json.dump(flags_dict, f, indent=4, sort_keys=True, ensure_ascii=False)

        with open(os.path.join(self.log_dir, 'supernet_space.json'), 'w') as f:
            json.dump(data, f, indent=4, sort_keys=False, ensure_ascii=False)

    def train(self):
        sample_list = ['random']  # the first stage
        # sample_list = ['largest', 'random', 'smallest'] # the second stage
        print(sample_list)
        state_list = ["train_bpp", 'train_loss', 'train_psnr', 'train_msssim', 'train_aux',
                      "train_z_bpp", "train_y_bpp"]
        for epoch in range(self.start_epoch, self.num_epochs):
            self.global_epoch = epoch
            log_state = {}
            for index in range(len(self.rate_list)):
                train_bpp, train_loss = [AverageMeter() for i in range(0, len(sample_list))], \
                                        [AverageMeter() for i in range(0, len(sample_list))]

                train_psnr, train_msssim = [AverageMeter() for i in range(0, len(sample_list))], \
                                           [AverageMeter() for i in range(0, len(sample_list))]

                train_z_bpp, train_y_bpp = [AverageMeter() for i in range(0, len(sample_list))], \
                                           [AverageMeter() for i in range(0, len(sample_list))]

                train_aux = [AverageMeter() for i in range(0, len(sample_list))]
                log_state[str(index)] = {}
                for name in state_list:
                    log_state[str(index)][name] = eval(name)

            self.adjust_lr()
            self.graph.train()
            train_bar = tqdm(self.training_set_loader)
            for kk, input in enumerate(train_bar):
                input = input.to(self.device)
                for sample_idx, model_mode in enumerate(sample_list):
                    if epoch > -1:
                        rate_index = random.randint(0, len(self.rate_list) - 1)
                        self.loss.lmbda = self.rate_list[rate_index]
                    else:
                        rate_index = len(self.rate_list) - 1
                        self.loss.lmbda = self.rate_list[-1]

                    self.graph.set_rate_level(rate_index, 1.0, isInterpolation=False)
                    self.graph.sample_active_subnet(model_mode)

                    result = self.graph(input)
                    dict = self.loss(result, input)
                    distortion = dict["mse_loss"]
                    loss = dict["loss"]
                    bpp, bpp_y, bpp_z = dict["bpp_loss"], dict["main_bpp_loss"], dict["hyper_bpp_loss"]

                    self.optimizer.zero_grad()
                    self.aux_optimizer.zero_grad()
                    loss.backward()
                    if self.grad_clip > 0:
                        torch.nn.utils.clip_grad_norm_(self.graph.parameters(), self.grad_clip)

                    self.optimizer.step()
                    aux_loss = self.graph.aux_loss()
                    aux_loss.backward()
                    self.aux_optimizer.step()

                    psnr = 10 * np.log10(1.0 / distortion.detach().mean().cpu())

                    log_state[str(rate_index)]['train_psnr'][sample_idx].update(psnr.mean().detach().item(),
                                                                                self.batch_size)
                    log_state[str(rate_index)]['train_loss'][sample_idx].update(loss.mean().detach().item(),
                                                                                self.batch_size)
                    log_state[str(rate_index)]['train_aux'][sample_idx].update(aux_loss.mean().detach().item(),
                                                                               self.batch_size)
                    log_state[str(rate_index)]['train_bpp'][sample_idx].update(bpp.mean().detach().item(),
                                                                               self.batch_size)
                    log_state[str(rate_index)]['train_z_bpp'][sample_idx].update(bpp_z.mean().detach().item(),
                                                                                 self.batch_size)
                    log_state[str(rate_index)]['train_y_bpp'][sample_idx].update(bpp_y.mean().detach().item(),
                                                                                 self.batch_size)
                    if self.global_step % 300 == 0:
                        self.writer.add_scalar(f'{self.rate_list[rate_index]}_{sample_idx}_train_psnr',
                                               psnr.detach().item(),
                                               self.global_step)
                        self.writer.add_scalar(f'{self.rate_list[rate_index]}_{sample_idx}_train_aux',
                                               aux_loss.detach().item(),
                                               self.global_step)
                        self.writer.add_scalar(f'{self.rate_list[rate_index]}_{sample_idx}_train_bpp',
                                               bpp.mean().detach().item(),
                                               self.global_step)
                        self.writer.add_scalar(f'{self.rate_list[rate_index]}_{sample_idx}_train_z_bpp',
                                               bpp_z.mean().detach().item(),
                                               self.global_step)
                        self.writer.add_scalar(f'{self.rate_list[rate_index]}_{sample_idx}_train_y_bpp',
                                               bpp_y.mean().detach().item(),
                                               self.global_step)
                        self.writer.add_scalar(f'{self.rate_list[rate_index]}_{sample_idx}_train_loss',
                                               loss.mean().detach().item(),
                                               self.global_step)

                    train_bar.desc = "lanmda:{}_T-ALL [{}|{}] LOSS[{:.4f}], PSNR[{:.3f}], " \
                                     "BPP[{:.3f}|{:.3f}|{:.3f}], AUX[{:.3f}]". \
                        format(self.rate_list[rate_index],
                               epoch + 1,
                               self.num_epochs,
                               loss.mean().detach().item(),
                               psnr,
                               bpp_z.mean().detach().item(),
                               bpp_y.mean().detach().item(),
                               bpp.mean().detach().item(),
                               aux_loss.mean().detach().item()
                               )
                    self.global_step += 1
            train_loss_avg = 0
            for rate_index in range(len(self.rate_list)):
                for sample_idx, model_mode in enumerate(sample_list):
                    self.logger.info("T-ALL-{}-{} [{}|{}] LOSS[{:.4f}], PSNR[{:.3f}], " \
                                     "BPP[{:.3f}|{:.3f}|{:.3f}], AUX[{:.3f}]". \
                        format(
                        self.rate_list[rate_index],
                        model_mode,
                        epoch + 1,
                        self.num_epochs,
                        log_state[str(rate_index)]['train_loss'][sample_idx].avg,
                        log_state[str(rate_index)]['train_psnr'][sample_idx].avg,
                        log_state[str(rate_index)]['train_z_bpp'][sample_idx].avg,
                        log_state[str(rate_index)]['train_y_bpp'][sample_idx].avg,
                        log_state[str(rate_index)]['train_bpp'][sample_idx].avg,
                        log_state[str(rate_index)]['train_aux'][sample_idx].avg
                    ))
                    train_loss_avg += log_state[str(rate_index)]['train_loss'][sample_idx].avg / len(sample_list)

            # Needs to be called once after training
            self.graph.update()
            if epoch % 5 == 0:
                self.save_checkpoint(train_loss_avg, f"checkpoint_{epoch}.pth")
            if epoch % self.args.val_freq == 0:
                self.validate()

    def validate(self):
        sample_list = ['largest', 'smallest']
        state_list = ["val_bpp", 'val_loss', 'val_y_bpp', 'val_z_bpp', 'val_psnr', 'val_msssim', 'val_aux']
        self.graph.eval()
        log_state = {}
        for index in range(len(self.rate_list)):
            val_bpp, val_loss = [AverageMeter() for i in range(0, len(sample_list))], \
                                [AverageMeter() for i in range(0, len(sample_list))]

            val_z_bpp, val_y_bpp = [AverageMeter() for i in range(0, len(sample_list))], \
                                   [AverageMeter() for i in range(0, len(sample_list))]

            val_psnr, val_msssim = [AverageMeter() for i in range(0, len(sample_list))], \
                                   [AverageMeter() for i in range(0, len(sample_list))]

            val_aux = [AverageMeter() for i in range(0, len(sample_list))]
            log_state[str(index)] = {}
            for name in state_list:
                log_state[str(index)][name] = eval(name)

        with torch.no_grad():
            valid_bar = tqdm(self.valid_set_loader)
            for k, input in enumerate(valid_bar):
                input = input.to(self.device)
                for rate_index in range(len(self.rate_list)):
                    self.graph.set_rate_level(rate_index)
                    for sample_idx, model_mode in enumerate(sample_list):
                        self.graph.sample_active_subnet(model_mode)
                        self.loss.lmbda = self.rate_list[rate_index]
                        result = self.graph(input)
                        dict = self.loss(result, input)

                        distortion = dict["mse_loss"]
                        loss = dict["loss"]
                        bpp, bpp_y, bpp_z = dict["bpp_loss"], dict["bpp_loss"], dict["bpp_loss"]
                        aux = self.graph.aux_loss()

                        psnr = 10 * np.log10(1.0 / distortion.detach().mean().cpu())
                        log_state[str(rate_index)]['val_loss'][sample_idx].update(loss.mean().detach().item(),
                                                                                  self.args.val_freq)
                        log_state[str(rate_index)]['val_bpp'][sample_idx].update(bpp.mean().detach().item(),
                                                                                 self.args.val_freq)
                        log_state[str(rate_index)]['val_z_bpp'][sample_idx].update(bpp_z.mean().detach().item(),
                                                                                   self.args.val_freq)
                        log_state[str(rate_index)]['val_y_bpp'][sample_idx].update(bpp_y.mean().detach().item(),
                                                                                   self.args.val_freq)
                        log_state[str(rate_index)]['val_psnr'][sample_idx].update(psnr.mean(), self.args.val_freq)

                        log_state[str(rate_index)]['val_aux'][sample_idx].update(aux.mean().detach().item(),
                                                                                 self.args.val_freq)

                        self.writer.add_scalar(f'{rate_index}_{model_mode}_val_aux', aux.detach().item(),
                                               self.global_eval_step)
                        self.writer.add_scalar(f'{rate_index}_{model_mode}_val_psnr', psnr.mean(),
                                               self.global_eval_step)
                        self.writer.add_scalar(f'{rate_index}_{model_mode}_val_loss', loss.mean().detach().item(),
                                               self.global_eval_step)
                        self.writer.add_scalar(f'{rate_index}_{model_mode}_val_bpp', bpp.mean().detach().item(),
                                               self.global_eval_step)
                        self.writer.add_scalar(f'{rate_index}_{model_mode}_val_z_bpp',
                                               bpp_z.mean().detach().item(),
                                               self.global_eval_step)
                        self.writer.add_scalar(f'{rate_index}_{model_mode}_val_y_bpp',
                                               bpp_y.mean().detach().item(),
                                               self.global_eval_step)
                        self.writer.add_scalar(f'{rate_index}_{model_mode}_val_psnr', psnr.mean(),
                                               self.global_eval_step)

                        valid_bar.desc = "VALID_{}: [{}|{}] LOSS[{:.4f}], PSNR[{:.3f}], BPP[{:.3f}|{:.3f}|{:.3f}] " \
                                         "AUX[{:.3f}]".format(
                            self.rate_list[rate_index],
                            self.global_epoch + 1,
                            self.num_epochs,
                            loss.mean().detach().item(),
                            psnr.mean(),
                            bpp_z.mean().detach().item(),
                            bpp_y.mean().detach().item(),
                            bpp.mean().detach().item(),
                            aux.detach().item(),
                        )

                self.global_eval_step += 1

        val_loss_avg = 0
        for rate_index in range(len(self.rate_list)):
            for sample_idx, model_mode in enumerate(sample_list):
                self.logger.info("VALID lanmda:{} mode:{} [{}|{}] LOSS[{:.4f}], "
                                 "PSNR[{:.3f}], BPP[{:.3f}|{:.3f}|{:.3f}] " \
                                 "AUX[{:.3f}]". \
                    format(
                    self.rate_list[rate_index],
                    model_mode,
                    self.global_epoch + 1,
                    self.num_epochs,
                    log_state[str(rate_index)]['val_loss'][sample_idx].avg,
                    log_state[str(rate_index)]['val_psnr'][sample_idx].avg,
                    log_state[str(rate_index)]['val_z_bpp'][sample_idx].avg,
                    log_state[str(rate_index)]['val_y_bpp'][sample_idx].avg,
                    log_state[str(rate_index)]['val_bpp'][sample_idx].avg,
                    log_state[str(rate_index)]['val_aux'][sample_idx].avg
                ))
                val_loss_avg += log_state[str(rate_index)]['val_loss'][sample_idx].avg / len(sample_list)

        is_best = bool(val_loss_avg < self.lowest_val_loss)
        self.lowest_val_loss = min(self.lowest_val_loss, val_loss_avg)
        self.save_checkpoint(val_loss_avg, "checkpoint_latest.pth")
        self.graph.train()

    def resume(self):
        self.logger.info(f"[*] Try Load Pretrained Model From {self.args.model_restore_path}...")
        checkpoint = torch.load(self.args.model_restore_path, map_location=self.device)
        last_epoch = checkpoint["epoch"] + 1
        self.logger.info(f"[*] Load Pretrained Model From Epoch {last_epoch}...")

        self.graph.load_state_dict(checkpoint["state_dict"])
        self.aux_optimizer.load_state_dict(checkpoint["aux_optimizer"])
        self.optimizer.load_state_dict(checkpoint["optimizer"])

        self.start_epoch = last_epoch
        self.global_step = checkpoint["global_step"] + 1
        del checkpoint

    def pretrain(self):
        self.logger.info(f"[*] Try Load Pretrained Model From {self.args.model_restore_path}...")
        checkpoint = torch.load(self.args.model_restore_path, map_location=self.device)
        self.logger.info("[*] Loading Pretrain Weights ")
        self.graph.load_state_dict(checkpoint["state_dict"], pretrain=True)
        del checkpoint

    def adjust_lr(self):
        if self.global_step < self.stage_step[0]:
            pass
        elif self.stage_step[0] <= self.global_step <= self.stage_step[1]:
            self.optimizer.param_groups[0]['lr'] = self.args.lr / 2.0
            self.aux_optimizer.param_groups[0]['lr'] = self.args.lr / 2.0
        elif self.stage_step[1] <= self.global_step <= self.stage_step[2]:
            self.optimizer.param_groups[0]['lr'] = self.args.lr / 10.0
            self.aux_optimizer.param_groups[0]['lr'] = self.args.lr / 10.0
        elif self.stage_step[2] <= self.global_step <= self.stage_step[3]:
            self.optimizer.param_groups[0]['lr'] = self.args.lr / 20.0
            self.aux_optimizer.param_groups[0]['lr'] = self.args.lr / 20.0
        elif self.stage_step[3] <= self.global_step <= self.stage_step[4]:
            self.optimizer.param_groups[0]['lr'] = self.args.lr / 40.0
            self.aux_optimizer.param_groups[0]['lr'] = self.args.lr / 40.0
        else:
            self.optimizer.param_groups[0]['lr'] = self.args.lr / 40.0
            self.aux_optimizer.param_groups[0]['lr'] = self.args.lr / 40.0

    def save_checkpoint(self, loss, name):
        state = {
            "epoch": self.global_epoch,
            "global_step": self.global_step,
            "state_dict": self.graph.state_dict(),
            "loss": loss,
            "optimizer": self.optimizer.state_dict(),
            "aux_optimizer": self.aux_optimizer.state_dict(),
        }
        torch.save(state, os.path.join(self.checkpoints_dir, name))

    def configure_optimizers(self, args):
        bp_parameters = list(p for n, p in self.graph.named_parameters() if not n.endswith(".quantiles"))
        aux_parameters = list(p for n, p in self.graph.named_parameters() if n.endswith(".quantiles"))
        self.optimizer = torch.optim.Adam(bp_parameters, lr=args.lr)
        self.aux_optimizer = torch.optim.Adam(aux_parameters, lr=args.aux_lr)
        return None

    def RDC_search_greedy(self):
        starttime = datetime.datetime.now()
        print(f"start time: {starttime}")
        search_result_name = 'CA_high_rate_gs.json'  # the file name of the search results.
        print("Init the model to the largest complexity")  # 贪心比例搜索。。。。
        cfg_candidates = self.graph.cfg_candidates
        optimate_target = np.zeros(cfg_candidates['g_s']['layer_num'])
        self.graph.sample_active_subnet(mode='smallest')
        min_flops = self.graph.compute_active_subnet_flops((256, 256))
        self.graph.sample_active_subnet(mode='largest')
        max_flops = self.graph.compute_active_subnet_flops((256, 256))
        print(f"complexity range :{round(min_flops / max_flops, 2)} ~ {1.0}")
        # target_flops = np.linspace(min_flops / max_flops, 1.0, 10, False).tolist()
        target_flops = [1.0, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6, 0.55, 0.5, 0.45, 0.4, 0.35, 0.30, 0.25, 0.20,
                        0.15, 0.10, 0.05]
        target_flops = sorted(target_flops)
        print('Totally {} layers of g_s to search.'.format(cfg_candidates['g_s']['layer_num']))

        target_flops_per = []
        for flops in target_flops:
            target_flops_per.append(flops)
        print(f"Target flops: {target_flops_per}, Max flops :{max_flops}, Min flops :{min_flops}")

        curr_cfg_index = {}
        curr_cfg = {}
        for k in ['g_a', 'h_a', 'g_s', 'h_mean_s', 'h_scale_s']:  # init the largest channels
            curr_cfg[k] = []
            curr_cfg_index[k] = []
            for layer_index in range(0, cfg_candidates[k]['layer_num']):
                if k == 'h_mean_s' or k == 'h_scale_s': #h_mean_s and h_scale_s are set the largest width
                    curr_cfg[k].append(cfg_candidates[k]["c"][layer_index][0])
                    curr_cfg_index[k].append(0)
                else:
                    curr_cfg[k].append(cfg_candidates[k]["c"][layer_index][-1])
                    curr_cfg_index[k].append(len(cfg_candidates[k]["c"][layer_index]) - 1)

        curr_target_flops = target_flops.pop()
        result = []
        all_search_process = []
        complexity = []
        print("start to search..")
        while True:
            curr_flops = self.graph.compute_active_subnet_flops((256, 256))
            flag = True
            if curr_flops / max_flops <= curr_target_flops:
                if len(target_flops) == 0:
                    break
                else:
                    complexity.append(round(curr_flops / max_flops * 100, 2))
                    print('Find autoslim net at flops {} %, target {} %'.format(round(curr_flops / max_flops * 100, 2),
                                                                                round(curr_target_flops * 100, 2)))
                    print(curr_cfg_index)
                    curr_cfg['complexity'] = round(curr_flops / max_flops * 100, 4)
                    result.append(copy.deepcopy(curr_cfg))
                    curr_target_flops = target_flops.pop()

            for i in range(cfg_candidates['g_s']['layer_num']):
                torch.cuda.empty_cache()
                optimate_target[i] = 0.
                if curr_cfg_index['g_s'][i] - 1 >= 0:
                    curr_cfg['g_s'][i] = cfg_candidates['g_s']["c"][i][curr_cfg_index['g_s'][i] - 1]
                    self.graph.set_active_subnet(curr_cfg)
                else:
                    optimate_target[i] += 0.
                    for i in curr_cfg_index['g_s']:
                        if i > 0:
                            flag = False
                    continue
                psnr, bpp = self.evaluate_all_rate_test()
                print(psnr, bpp)
                optimate_target[i] += psnr
                curr_cfg['g_s'][i] = cfg_candidates['g_s']["c"][i][curr_cfg_index['g_s'][i]]
            if flag:
                break
            best_index = np.argmax(optimate_target)
            print(*[f'{element:.4f}' for element in optimate_target])
            curr_cfg_index['g_s'][best_index] = curr_cfg_index['g_s'][best_index] - 1
            curr_cfg['g_s'][best_index] = cfg_candidates['g_s']["c"][best_index][curr_cfg_index['g_s'][best_index]]
            self.graph.set_active_subnet(curr_cfg)  # adjust channel num to the best result！
            curr_cfg['complexity'] = self.graph.compute_active_subnet_flops((256, 256)) / max_flops * 100
            all_search_process.append(copy.deepcopy(curr_cfg))  # record all search process ！
            print(
                'Adjust layer {} for {} to {}, error: {}.'.format(
                    best_index, cfg_candidates['g_s']["c"][best_index][curr_cfg_index['g_s'][best_index] + 1] -
                                cfg_candidates['g_s']["c"][best_index][curr_cfg_index['g_s'][best_index]],
                    cfg_candidates['g_s']["c"][best_index][curr_cfg_index['g_s'][best_index]],
                    optimate_target[best_index]))
            with open(os.path.join('./', search_result_name),
                      'w' if os.path.exists(os.path.join('./', search_result_name)) else 'w') as f:
                json.dump(result, f, indent=4, sort_keys=False, ensure_ascii=False)

            with open(os.path.join('./', 'all_result_' + search_result_name),
                      'w' if os.path.exists(os.path.join('./', 'all_result_' + search_result_name)) else 'w') as f:
                json.dump(all_search_process, f, indent=4, sort_keys=False, ensure_ascii=False)
        print(complexity)
        endtime = datetime.datetime.now()
        print(f"end time: {endtime}")
        print(f'the Search Time {(endtime - starttime).seconds / 3600} hours')

    def evaluate_all_rate_test(self):
        evaluate_loss = EvaluateLoss()
        self.graph.eval()
        average_bpp = []
        average_psnr = []
        val_bpp, val_loss = AverageMeter(), AverageMeter()
        val_z_bpp, val_y_bpp = AverageMeter(), AverageMeter()
        val_psnr, val_msssim = AverageMeter(), AverageMeter()
        with torch.no_grad():
            valid_bar = tqdm(self.valid_set_loader)
            for k, input in enumerate(valid_bar):
                input = input.to(self.device)
                result = self.graph.evaluate(x=input, all_cfg=None, min_rate_level=0,
                                             max_rate_level=5, rate_interpolation_coefficient=0)
                dict = evaluate_loss(result, input)
                distortion_list = dict["mse_loss"]
                bpp, bpp_y, bpp_z = sum(dict["bpp_loss"]) / len(dict["bpp_loss"]), \
                                    sum(dict["main_bpp_loss"]) / len(dict["main_bpp_loss"]), \
                                    sum(dict["hyper_bpp_loss"]) / len(dict["hyper_bpp_loss"])

                aux = self.graph.aux_loss()
                psnr = []
                for distortion in distortion_list:
                    psnr.append(10 * np.log10(1.0 / distortion.detach().mean().item()))
                psnr = sum(psnr) / len(psnr)
                val_loss.update(0, self.args.val_freq)
                val_bpp.update(bpp.mean().detach().item(), self.args.val_freq)
                val_z_bpp.update(bpp_z.mean().detach().item(), self.args.val_freq)
                val_y_bpp.update(bpp_y.mean().detach().item(), self.args.val_freq)
                val_psnr.update(psnr, self.args.val_freq)
                val_msssim.update(aux.mean().detach().item(), self.args.val_freq)
        average_psnr.append(val_psnr.avg)
        average_bpp.append(val_bpp.avg)
        print(f'psnr: {average_psnr}, bpp : {average_bpp}')
        return sum(average_psnr) / len(average_psnr), sum(average_bpp) / len(average_bpp)
