#ifndef _TIMER_H_WHL_
#define _TIMER_H_WHL_

#include <stdio.h>
#include <time.h>
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

#define __PROFILE__
#define __WIN__

#define TIMER_NUM 16

enum {	ENCODER, OTHER, MODE, SAD,
		DCT, iDCT, Q, iQ,
		ME, MC, RCRL, VLC, 
		TRANSFER, MY_DEBUG, INIT, FILT };

typedef struct 
{
	__int64 start;
	__int64 frame_sum;
	__int64 overall_sum;
	__int64 frame_counter;
	__int64 overall_counter;
} 
TIMER;

extern TIMER timer[TIMER_NUM];
extern double freq;

string int2str(int &i);

/* ========================================================================================== */

void init_timer();
__inline static void start_timer(int t);
__inline static void stop_timer(int t);

/* ========================================================================================== */

/*	RDTSC (Read Time Stamp Counter) reads a Pentium internal 64 bit register which is being incremented
	from 0000 0000 0000 0000 at every CPU internal clock cycle.
*/

#ifdef __WIN__

__inline static __int64 read_counter() 
{
	__int64 ts;
	unsigned int ts1, ts2;
	__asm 
	{
		rdtsc
		mov  ts1, eax
		mov  ts2, edx
	}
	ts = ((unsigned __int64) ts2 << 32) | ((unsigned __int64) ts1);
	return ts;
}

#else
static __inline __int64 read_counter() 
{
    __int64 ts;
    unsigned int ts1, ts2;

    __asm__ __volatile__("rdtsc\n\t":"=a"(ts1), "=d"(ts2));

    ts = ((unsigned __int64) ts2 << 32) | ((unsigned __int64) ts1);

    return ts;
}
#endif

__inline static double get_cpu_freq(int second)
{
    __int64 x,y;
    __int64 i;
	i = time(0);
    while(i == time(0))
	{
    }
    
	x = read_counter();
    i += 1 + second;

    while(i != time(0))
	{
	}

    y = read_counter();

    return (double) (y - x) / (second);
}
__inline static void start_timer(int t)
{
#ifdef __PROFILE__
	int i;
	#ifdef __RATE_ONLY__
		if (t!= ENCODER) 
		{
			return;
		}
	#endif
	timer[t].overall_counter++;
	timer[t].frame_counter++;
	timer[t].start = read_counter();
	if (t==ENCODER)
	{
		for(i=0; i<TIMER_NUM; i++)
		{
			timer[i].frame_sum = 0;
			timer[i].frame_counter = 0;
		}
	}
#endif
};

__inline static void stop_timer(int t)
{
#ifdef __PROFILE__
	unsigned __int64 now;
	#ifdef __RATE_ONLY__
		if (t!= ENCODER) 
		{
			return;
		}
	#endif
	now = read_counter() - timer[t].start;
	timer[t].frame_sum += now;
	timer[t].overall_sum += now;
#endif
}

#endif _TIMER_H_WHL_
