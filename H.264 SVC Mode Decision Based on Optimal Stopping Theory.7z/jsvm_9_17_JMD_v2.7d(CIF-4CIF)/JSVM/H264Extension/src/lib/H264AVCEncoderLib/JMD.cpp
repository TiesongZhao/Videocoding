#include "JMD.h"


#ifdef STAT_SONG
	FILE *fp_stat;
	int fileno_song_0;
	int fileno_song_1;
	int Qp_song_0;
	int Qp_song_1;
	double PSNR_song;
	double Bitrates_song;
#endif STAT_SONG

FMDAlg* MyAlg;

const double AllZeroThreshold4x4[52] = {
    0.0223, 0.0245, 0.0290, 0.0312, 0.0356, 0.0401, 0.0445, 0.0490, 0.0579, 0.0624, 0.0713, 0.0802, 0.0891, 
	0.0980, 0.1158, 0.1247, 0.1425, 0.1603, 0.1782, 0.1960, 0.2316, 0.2494, 0.2850, 0.3207, 0.3563, 0.3919,
	0.4632, 0.4988, 0.5701, 0.6413, 0.7126, 0.7839, 0.9264, 0.9977, 1.1402, 1.2827, 1.4253, 1.5677, 1.8529,
	1.9954, 2.2804, 2.5653, 2.8505, 3.1354, 3.7058, 3.9908, 4.5607, 5.1307, 5.7010, 6.2708, 7.4115, 7.9815 };

// E.T. condition: MAD2x2<epslon*Q(u,v)/(2*tao*K(u,v))  for u=0,1...3; v=0,1,...3
// Let MinAZTh=min(Q(u,v)/(2*tao*K(u,v))) for u=0,1...3; v=0,1,...3, it is just an array of Qp
// tao = 3.0; epslon = 1.0;

FMDAlg::FMDAlg()
{
	SubModeOpt =  false;
}

FMDAlg::~FMDAlg()
{
}

void FMDAlg::InitTransMatrix(int MaxTemporalLayer)
{
	MaxTLayer = MaxTemporalLayer;
	TransMatrixLayer = new TransMatrix[MaxTLayer];

	for(int k=0; k<MaxTLayer; k++)
	{
		TransMatrixLayer[k].init();
	}
}

void FMDAlg::SetEnhRatio(int H_Mb_BL, int H_Mb_EL)
{
	m_er = H_Mb_EL / H_Mb_BL;
}

bool FMDAlg::IsQualityScalability()
{
	return (m_er == 1);
}

void FMDAlg::SetTemporalLayer(int TemporalLayer)
{
	TLayerMinus1 = TemporalLayer - 1;
}

void FMDAlg::SetRefModes(char  M_u, char M_l, char M_bl)
{
	mode_upper = Mode2Num (M_u);
	mode_left = Mode2Num (M_l);
	mode_base = Mode2Num (M_bl);
}

void FMDAlg::InitCandModeList()
{
	int i, j;
	double prob_list[__CAND_MODE_NUM]={0,0,0,0,0,0};
	TransMatrixLayer[TLayerMinus1].pred(mode_upper, mode_left, mode_base, prob_list);
	for (i=0; i<__CAND_MODE_NUM; i++)
	{
		ModeList[i].mode = i;
		ModeList[i].prob = prob_list[i];
		ModeList[i].state = 0;
	}
	curr_mode_idx = -1;

	if (TransMatrixLayer[TLayerMinus1].IsFirstFrame())
	{
		//SubModeEnabled[0] = true;
		SubModeEnabled[1] = true;
		SubModeEnabled[2] = true;
		SubModeEnabled[3] = true;
		return;
	}
	
	CandMode temp;
	for(i=0; i<__CAND_MODE_NUM; i++)
	{
		for(j=__CAND_MODE_NUM-1; j>i; j--)
		{
			if(ModeList[i].prob < ModeList[j].prob)
			{
				temp = ModeList[i];
				ModeList[i] = ModeList[j];
				ModeList[j] = temp;
			}
		}
	}	
	SetOptStopMode();
	SetSubModes();
}


void FMDAlg::SetOptStopMode()		
	// method: 0, relatively-best choice problem
{
	// set Kn
	int k, j, r;
	double sump0, sump1;
	for(k=1; k<__CAND_MODE_NUM; k++)
	{
		sump0 = 0;
		for(j=k+1; j<=__CAND_MODE_NUM; j++)
		{
			sump1 = 0;
			for (r=1; r<=j; r++)
			{
				sump1 += ModeList[r-1].prob;
			}
			sump0 += 1/sump1;
		}
		if(sump0 * ModeList[k].prob <= 1)
			break;
	}
	int Kn = k;

	// calc. E(Tk)
	double ETk;
	for(k=Kn; k<__CAND_MODE_NUM; k++)
	{
		ETk = 0;
		for(r=1; r<=k; r++)
		{
			ETk += ModeList[r-1].prob;
		}
		sump0 = 0;
		for(j=k; j<=__CAND_MODE_NUM; j++)
		{
			sump1 = 0;
			for (r=1; r<=j; r++)
			{
				sump1 += ModeList[r-1].prob;
			}
			sump0 += 1/sump1;
		}
		ETk = k + ETk * sump0;
		if(ETk > __CAND_MODE_NUM + 0.5)
			break;
		ModeList[k-1].state = 1;
	}
	for(; k<=__CAND_MODE_NUM; k++)
	{
		ModeList[k-1].state = 2;
	}
}

void FMDAlg::SetSubModes()
{
	if(ModeList[0].mode < 2)
	{
		//SubModeEnabled[0]=true;
		SubModeEnabled[1]=false;
		SubModeEnabled[2]=false;
		SubModeEnabled[3]=false;
	}
	else if(ModeList[0].mode == 2)
	{
		//SubModeEnabled[0]=true;
		SubModeEnabled[1]=true;
		SubModeEnabled[2]=false;
		SubModeEnabled[3]=false;
	}
	else if(ModeList[0].mode == 3)
	{
		//SubModeEnabled[0]=true;
		SubModeEnabled[1]=false;
		SubModeEnabled[2]=true;
		SubModeEnabled[3]=false;
	}
	else
	{
		//SubModeEnabled[0]=true;
		SubModeEnabled[1]=true;
		SubModeEnabled[2]=true;
		SubModeEnabled[3]=true;
	}
}

char FMDAlg::GetModeInList()
{
	curr_mode_idx ++;
	if (curr_mode_idx < __CAND_MODE_NUM)
		return ModeList[curr_mode_idx].mode;
	return -1;
}

char FMDAlg::GetListState()
{
	if (curr_mode_idx < __CAND_MODE_NUM)
		return ModeList[curr_mode_idx].state;
	return false;
}

void FMDAlg::SetSubModeOpt(bool enabeld)
{
	SubModeOpt = enabeld;
}

bool FMDAlg::IsSubModeEnabled(char sub_mode)
{
	if (!SubModeOpt || sub_mode < 9 || sub_mode > 11)
		return true;
	return SubModeEnabled[sub_mode-8];
}

void FMDAlg::UpdateTransMatrix(char M_b)
{
	int k;
	double prob_list_2[__CAND_MODE_NUM]={0,0,0,0,0,0};
	best_mode = Mode2Num(M_b);
	for (k=0; k<=curr_mode_idx && k<__CAND_MODE_NUM; k++)
	{
		prob_list_2[best_mode] += ModeList[k].prob;
	}
	for (; k<__CAND_MODE_NUM; k++)
	{
		prob_list_2[ModeList[k].mode] = ModeList[k].prob;
	}

	TransMatrixLayer[TLayerMinus1].update(mode_upper, mode_left, mode_base, prob_list_2);
}


int FMDAlg::GetSADThforAllZero4x4ResidualMode(int Qp)
{
	return int(AllZeroThreshold4x4[Qp]);
}