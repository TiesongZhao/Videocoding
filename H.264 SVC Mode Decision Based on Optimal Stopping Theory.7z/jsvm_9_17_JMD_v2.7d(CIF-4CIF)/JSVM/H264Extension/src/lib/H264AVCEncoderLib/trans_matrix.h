#ifndef _TRANS_MATRIX_H_
#define _TRANS_MATRIX_H_

#include <math.h>
#include <stdio.h>

#define __CAND_MODE_NUM 6
#define __SPATIO_MODE_NUM 6
#define __BASE_MODE_NUM 5

class TransMatrix{

public:
	TransMatrix();
	~TransMatrix();
	//void init(char TLayer);	// initialize the matrix with parameters above
	void init();
	void pred(char mode_upper, char mode_left, char mode_base, double prob_p[__CAND_MODE_NUM]);		// six probabilities based on history
	void update(char mode_upper, char mode_left, char mode_base, double prob[__CAND_MODE_NUM]);	// update for each MB
	bool IsFirstFrame();

private:
	//char TemporalId;	// should not be 0 since only the non-key frames are optimized
	int FrameNo; 
	double w_prob;
	double trans_long[__CAND_MODE_NUM];
	double trans_upper[__SPATIO_MODE_NUM][__CAND_MODE_NUM];
	double trans_left[__SPATIO_MODE_NUM][__CAND_MODE_NUM];
	double trans_base[__BASE_MODE_NUM][__CAND_MODE_NUM];
};

#endif _TRANS_MATRIX_H_

