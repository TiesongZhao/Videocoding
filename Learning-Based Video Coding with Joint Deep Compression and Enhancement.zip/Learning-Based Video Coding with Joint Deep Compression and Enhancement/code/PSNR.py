import os
import cv2
import numpy as np
import tensorflow as tf
import math
path = "/media/user/f126fd00-4370-4fdf-9a0a-fc93e66106eb1/FWZ/data/test/CTC/ClassD/"
path_list = os.listdir(path)
psnr = []
for item in path_list:
    if "RaceHorses" in item:
        for i in range(15):
            CA_path = path + item  +  '/f' + str(14*i + 1).zfill(3)+'_CA_6' + '.png'
            raw_path = path + item  +  '/f' + str(14*i + 1).zfill(3)+ '.png'
            CA_img = cv2.imread(CA_path)
            raw_img = cv2.imread(raw_path)
            train_mse = np.mean((CA_img - raw_img)**2)
            quality = math.log10(255*255/train_mse)*10
            psnr.append(quality)
print(np.mean(psnr))
