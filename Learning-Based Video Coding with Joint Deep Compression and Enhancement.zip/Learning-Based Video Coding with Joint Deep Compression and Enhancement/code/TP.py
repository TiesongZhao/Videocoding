import numpy as np
import cv2
folder = np.load("folder.npy")
print(len(folder))
print(folder[0])
path = "/home/user/jnf/FWZ1/img"
for a in folder:

    save_path = a + "/im1_CA_6.png"
    b = a.split("vimeo_septuplet")[-1]
    print(b)
    img_path = path + b + "/im1_CA_6.png"
    img = cv2.imread(img_path)
    cv2.imwrite(save_path,img)
    

    
