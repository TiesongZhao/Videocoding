#include "H264AVCEncoderLibTest.h"
#include "H264AVCEncoderTest.h"
#include "H264AVCCommonLib/CommonBuffers.h"


int
main( int argc, char** argv)   
{
  printf("JMVC %s Encoder\n\n",_JMVC_VERSION_);

#ifdef STAT_ZTS
  init_timer();
  start_timer(ENCODER);
#endif STAT_ZTS

#ifdef ALG_ZTS
  MyAlg = new FMDModule;
#endif ALG_ZTS

  H264AVCEncoderTest*               pcH264AVCEncoderTest = NULL;
  RNOK( H264AVCEncoderTest::create( pcH264AVCEncoderTest ) );

  RNOKS( pcH264AVCEncoderTest->init   ( argc, argv ) );
  RNOK ( pcH264AVCEncoderTest->go     () );
  RNOK ( pcH264AVCEncoderTest->destroy() );

#ifdef ALG_ZTS
  MyAlg->StoreTrans();
#endif ALG_ZTS

#ifdef STAT_ZTS
  stop_timer(ENCODER);
  ofstream res("Proposedv2.txt", ios::out|ios::app);
  res<<fileno_stat<<"\t"<<view_stat<<"\t"<<Qp_stat<<"\t"<<timer[ENCODER].overall_sum/freq_whl<<"\t"<<PSNR_stat<<"\t"<<Bitrates_stat<<"\n";
  res.close();
#endif STAT_ZTS

  return 0;
}
