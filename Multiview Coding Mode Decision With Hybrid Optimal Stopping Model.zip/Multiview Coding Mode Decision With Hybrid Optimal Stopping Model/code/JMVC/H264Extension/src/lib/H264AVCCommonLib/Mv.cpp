#include "H264AVCCommonLib.h"
#include "H264AVCCommonLib/Mv.h"

H264AVC_NAMESPACE_BEGIN

const Mv Mv::m_cMvZero;


const Mv* Mv::m_cMvZero1;

H264AVC_NAMESPACE_END
