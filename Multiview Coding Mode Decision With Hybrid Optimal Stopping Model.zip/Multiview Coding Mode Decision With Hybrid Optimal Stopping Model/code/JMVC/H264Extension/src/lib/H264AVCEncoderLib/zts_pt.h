#ifndef __ZTS_PT_H_
#define __ZTS_PT_H_

#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <fstream>
#include <sys/stat.h>
using namespace std;

#define NUM_CANDIDATE_MODE 6
// fixed. (due to fixed parameters in time prediction)

enum ModeLabel{MD_SKIP_ZTS, MD_16x16_ZTS, MD_16x8_ZTS, MD_8x16_ZTS, MD_8x8_ZTS, MD_INTRA_ZTS};
enum OptModelLabel{OPT_MODEL_P, OPT_MODEL_P_T};

// #define PARA_OPT_TAU_A NUM_CANDIDATE_MODE+0.75
// #define PARA_OPT_TAU_B NUM_CANDIDATE_MODE+0.8
#define PARA_OPT_TAU NUM_CANDIDATE_MODE+0.8
#define PARA_MODE_ADAP_RATE 0.08

class ModePredModule{

public:
	ModePredModule();
	~ModePredModule();

	void InitAll(int MaxTLayer, int HeightInMbs, int WidthInMbs, bool FwdInterView, bool BwdInterView);
	void WriteModeTransMatrices(string outfile);	// !m_IsLastView
	void LoadModeTransMatrices(string infile);	//  m_IsFirstView
	void WriteCurrModes(string outfile);	
	void LoadInterViewModes(string fwd_in, string bwd_in);	// m_FwdInterView || m_FwdInterView

	// vector size = 6, for the six modes
	void StartTLayer(int TLayer);
	vector<double> GetModeProbList(int mb_y, int mb_x);
	void UpdateModeProb(int mb_y, int mb_x, char bmode_label, vector<double> prob_list);	// for B slice
	void UpdateBestModeOnly(int mb_y, int mb_x, char bmode_label);	// for I,P slice

private:

	int m_MaxTLayerPlus1;
	int m_HeightInMbs, m_WidthInMbs;
	bool m_FwdInterView, m_BwdInterView;
	double **trans_upper,**trans_left, **trans_fwd, **trans_bwd;
	int **fwd_mode, **bwd_mode;
	int **curr_mode;
	int matrix_height;
	int m_Start;
};

class TimePredModule{

public:
	TimePredModule();
	~TimePredModule();
	void SetView(bool IsSingleInterView);
	vector<double> GetTimeList(int TLayer, int Layer_Qp);
	// linear approxmiation, with Qp about 10~50
private:
	double p_skip[5][3];
	double p_16x16[5][2], p_16x8[5][2], p_8x16[5][2], p_8x8[5][2];
	vector<vector<double>> TimeMat;
	bool TimeListCalculated[5];
};

#endif __ZTS_PT_H_