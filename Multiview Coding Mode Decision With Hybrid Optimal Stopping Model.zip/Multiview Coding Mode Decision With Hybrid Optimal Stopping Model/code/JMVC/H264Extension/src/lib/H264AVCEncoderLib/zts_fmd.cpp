#include "zts_fmd.h"

#ifdef STAT_ZTS
	int fileno_stat;
	int view_stat;
	int Qp_stat;
	double PSNR_stat;
	double Bitrates_stat;
#endif STAT_ZTS

#ifdef ALG_ZTS
	FMDModule *MyAlg;
#endif ALG_ZTS


FMDModule::FMDModule()
{
	TempFolder = "temp";
	ModeTransMatricesFile = "\\ModeProbTrans.txt";
	InterViewModeFile[0] = "\\ModeView";
	InterViewModeFile[1] = "Frame";
	InterViewModeFile[2] = ".txt";
	m_tau = PARA_OPT_TAU;
}

FMDModule::~FMDModule()
{
}

void FMDModule::InitAll(int MaxTLayer, int HeightInMbs, int WidthInMbs, int ViewId)
{
	m_ViewId = ViewId;

	MyModePred = new ModePredModule;
	MyTimePred = new TimePredModule;
	// only for 0-2-1-4-3-6-5-7
	switch (m_ViewId)
	{
	case 0:
		m_IsAnchorView = m_IsFirstView = true;
		m_IsLastView = false;
		m_FwdViewId = m_BwdViewId = -1;	
		break;
	case 1:
		m_IsAnchorView = false;
		m_IsFirstView = false;
		m_IsLastView = false;
		m_FwdViewId = 0;
		m_BwdViewId = 2;
		break;			
	case 3:
		m_IsAnchorView = false;
		m_IsFirstView = false;
		m_IsLastView = false;
		m_FwdViewId = 2;
		m_BwdViewId = 4;
		break;	
	case 5:
		m_IsAnchorView = false;
		m_IsFirstView = false;
		m_IsLastView = false;
		m_FwdViewId = 4;
		m_BwdViewId = 6;
		break;
	case 7:
		m_IsAnchorView = false;
		m_IsFirstView = false;
		m_IsLastView = true;
		m_FwdViewId = 6;
		m_BwdViewId = -1;
		break;
	default:
		m_IsAnchorView = true;
		m_IsFirstView = false;
		m_IsLastView = false;
		m_FwdViewId = m_BwdViewId = -1;
	}

	//m_tau = (m_FwdViewId>=0 && m_BwdViewId>=0)? PARA_OPT_TAU_A:PARA_OPT_TAU_B;

	MyModePred->InitAll(MaxTLayer, HeightInMbs, WidthInMbs, m_FwdViewId>=0, m_BwdViewId>=0);	
	MyTimePred->SetView(m_IsLastView);  // only for 0-2-1-4-3-6-5-7

	if (m_IsFirstView)
	{
		struct stat stFileInfo;
		string zts_sys;
		// if there exits subfolder tmp, delete it
		if (!stat(TempFolder.c_str(),&stFileInfo))
		{
			zts_sys = "rd " + TempFolder + " /s/q";
			system(zts_sys.c_str());
			
		}
		// create a subfolder named as TempFolder
		zts_sys = "md " + TempFolder;
		system(zts_sys.c_str());
	}
	else
	{
		MyModePred->LoadModeTransMatrices(TempFolder+ModeTransMatricesFile);
	}
}

void FMDModule::StoreTrans()
{
	MyModePred->WriteModeTransMatrices(TempFolder+ModeTransMatricesFile);
}


void FMDModule::StartFrameEncoding(int TLayer, int Poc, int Layer_Qp)
{
	m_TLayer = TLayer;
	m_Poc = Poc;

	if (!m_IsAnchorView)
	{
		MyModePred->LoadInterViewModes( TempFolder + InterViewModeFile[0] + int2str(m_FwdViewId) + InterViewModeFile[1] + int2str(m_Poc) + InterViewModeFile[2],
			TempFolder + InterViewModeFile[0] + int2str(m_BwdViewId) + InterViewModeFile[1] + int2str(m_Poc) + InterViewModeFile[2]);
		time_list = MyTimePred->GetTimeList(m_TLayer, Layer_Qp);
	}	
	MyModePred->StartTLayer(m_TLayer);
}

void FMDModule::FinishFrameEncoding()
{
	if (m_IsAnchorView)
		MyModePred->WriteCurrModes( TempFolder + InterViewModeFile[0] + int2str(m_ViewId) + InterViewModeFile[1] + int2str(m_Poc) + InterViewModeFile[2]);
}


void FMDModule::StartMBEncoding(int MbY, int MbX)
{
	curr_mode_idx = 0;
	m_FMDEnabled_MB = !m_IsAnchorView;
	if (MbX==0 && MbY==0)
	{
		m_FMDEnabled_MB = false;
	}
	int __k = 0;
	
	// initialize candidate mode list	
	if (! m_FMDEnabled_MB)
	{
		m_Model = OPT_MODEL_P;
		for (__k=0; __k<NUM_CANDIDATE_MODE; __k++)
		{
			ModeList[OPT_MODEL_P][__k].mode = ModeLabel(__k);
			ModeList[OPT_MODEL_P][__k].p = 1.0/6;
		}
		m_Ks[m_Model] = NUM_CANDIDATE_MODE;
		//m_SubModeEnabled[0] = true;
		m_SubModeEnabled[1] = true;
		m_SubModeEnabled[2] = true;
		m_SubModeEnabled[3] = true;
		return;
	}
	prob_list = MyModePred->GetModeProbList(MbY, MbX);
	
	for (__k=0; __k<NUM_CANDIDATE_MODE; __k++)
	{
		ModeList[OPT_MODEL_P][__k].mode = ModeLabel(__k);
		ModeList[OPT_MODEL_P][__k].p = prob_list[__k];
		ModeList[OPT_MODEL_P][__k].t = time_list[__k];
		ModeList[OPT_MODEL_P_T][__k] = ModeList[OPT_MODEL_P][__k];
	}

	// bubble sort
	BubbleSortList(OPT_MODEL_P);
	BubbleSortList(OPT_MODEL_P_T);

	// hybrid model
	CalcOptStop();
	DecideOptModel();

	// set sub modes
	switch(ModeList[m_Model][0].mode)
	{
		case MD_SKIP_ZTS:
		case MD_16x16_ZTS:
			//m_SubModeEnabled[0] = true;
			m_SubModeEnabled[1] = false;
			m_SubModeEnabled[2] = false;
			m_SubModeEnabled[3] = false;
			break;
		case MD_16x8_ZTS:
			//m_SubModeEnabled[0] = true;
			m_SubModeEnabled[1] = true;
			m_SubModeEnabled[2] = false;
			m_SubModeEnabled[3] = false;
			break;
		case MD_8x16_ZTS:
			//m_SubModeEnabled[0] = true;
			m_SubModeEnabled[1] = false;
			m_SubModeEnabled[2] = true;
			m_SubModeEnabled[3] = false;
			break;
		default:
			//m_SubModeEnabled[0] = true;
			m_SubModeEnabled[1] = true;
			m_SubModeEnabled[2] = true;
			m_SubModeEnabled[3] = true;
	}
}

void FMDModule::CalcOptStop()
{
	double __tmp0; 
	int j, k, Ka, Kb;

	// OPT_MODEL_P
	for (k=1; k<NUM_CANDIDATE_MODE; k++)
	{
		__tmp0 = 0;
		for (j=k; j<=NUM_CANDIDATE_MODE; j++)
		{
			__tmp0 += 1.0/ModeList[OPT_MODEL_P][j-1].acc_p;
		}
		__tmp0 *= ModeList[OPT_MODEL_P][k-1].acc_p;
		__tmp0 += k;
		if (__tmp0 > m_tau)
			break;
	}
	Ka = k;
	for (k=1;k<NUM_CANDIDATE_MODE; k++)
	{
		__tmp0 = 0;
		for (j=k+1; j<=NUM_CANDIDATE_MODE; j++)
		{
			__tmp0 += 1.0/ModeList[OPT_MODEL_P][j-1].acc_p;
		}
		__tmp0 *= ModeList[OPT_MODEL_P][k].p;
		if (__tmp0 <= 1)
			break;
	}
	Kb = k;
	m_Ks[OPT_MODEL_P] = Ka > Kb ? Ka : Kb;

	// OPT_MODEL_P_T
	for (k=1; k<NUM_CANDIDATE_MODE; k++)
	{
		__tmp0 = 0;
		for (j=k; j<=NUM_CANDIDATE_MODE; j++)
		{
			__tmp0 += 1.0/ModeList[OPT_MODEL_P_T][j-1].acc_p;
		}
		__tmp0 *= ModeList[OPT_MODEL_P_T][k-1].acc_p;
		__tmp0 += k;
		if (__tmp0 > m_tau)
			break;
	}
	Ka = k;
	for (k=1; k<NUM_CANDIDATE_MODE; k++)
	{
		__tmp0 = 0;
		for (j=k+1; j<NUM_CANDIDATE_MODE; j++)
		{
			__tmp0 += ModeList[OPT_MODEL_P_T][j].t/ModeList[OPT_MODEL_P_T][j-1].acc_p;
		}
		__tmp0 += 1.0/NUM_CANDIDATE_MODE;
		__tmp0 *= ModeList[OPT_MODEL_P_T][k].p;
		if (__tmp0 <=  ModeList[OPT_MODEL_P_T][k].t)
			break;
	}
	Kb = k;
	m_Ks[OPT_MODEL_P_T] = Ka > Kb ? Ka : Kb;
}

void FMDModule::DecideOptModel ()
{
	double __tmp0;
	int j;
	//if (RuleNo == MAX_ETK)
	//{
	double ETK[2] = {0,0};
	__tmp0 = 0;
	for (j=m_Ks[OPT_MODEL_P]; j<=NUM_CANDIDATE_MODE; j++)
	{
		__tmp0 += 1.0/ModeList[OPT_MODEL_P][j-1].acc_p;
	}
	__tmp0 *= ModeList[OPT_MODEL_P][m_Ks[OPT_MODEL_P]-1].acc_p;
	ETK[OPT_MODEL_P] = m_Ks[OPT_MODEL_P] + __tmp0;
	__tmp0 = 0;
	for (j=m_Ks[OPT_MODEL_P_T]; j<=NUM_CANDIDATE_MODE; j++)
	{
		__tmp0 += 1.0/ModeList[OPT_MODEL_P_T][j-1].acc_p;
	}
	__tmp0 *= ModeList[OPT_MODEL_P_T][m_Ks[OPT_MODEL_P_T]-1].acc_p;
	ETK[OPT_MODEL_P_T] = m_Ks[OPT_MODEL_P_T] + __tmp0;
	if (ETK[OPT_MODEL_P] > ETK[OPT_MODEL_P_T])
		m_Model = OPT_MODEL_P;
	else
		m_Model = OPT_MODEL_P_T;
	//}
}

void FMDModule::FinishMBEncoding(int MbY, int MbX, char best_mode, bool isInterB)
{
	ModeLabel bmode_label = mode2label(best_mode);
	if (isInterB)
	{
		int __k;
		vector<double> prob_list;
		for (__k=0; __k<NUM_CANDIDATE_MODE; __k++)
		{
			prob_list.push_back(0.0);
		}
		for (__k=0; __k<m_Ks[m_Model]; __k++)
		{
			prob_list[bmode_label] += ModeList[m_Model][__k].p;
		}
		for (; __k<NUM_CANDIDATE_MODE; __k++)
		{
			prob_list[ModeList[m_Model][__k].mode] = ModeList[m_Model][__k].p;
		}
		MyModePred->UpdateModeProb(MbY, MbX, bmode_label, prob_list);
	}
	else
	{
		MyModePred->UpdateBestModeOnly(MbY, MbX, bmode_label);
	}
}

char FMDModule::PopModeInList()
{
	if (curr_mode_idx < m_Ks[m_Model])
		return char(ModeList[m_Model][curr_mode_idx++].mode);
	return -1;
}

bool FMDModule::IsSubModeNotSkipped(char sub_mode)
{
	if (sub_mode<9 || sub_mode>11)
		return true;
	return m_SubModeEnabled[sub_mode-8];
}