#include "timer_whl.h"

TIMER timer[TIMER_NUM];
double freq_whl;

void init_timer()
{
	TIMER zero = {0,0,0,0,0};
	int i;
	for(i=0; i<TIMER_NUM; i++)
	{
		timer[i] = zero;
	}
	freq_whl = get_cpu_freq(1);
}