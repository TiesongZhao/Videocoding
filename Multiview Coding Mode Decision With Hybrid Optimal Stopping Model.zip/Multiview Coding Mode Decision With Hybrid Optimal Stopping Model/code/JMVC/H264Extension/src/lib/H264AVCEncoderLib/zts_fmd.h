#ifndef _ALG_ZTS_H_
#define _ALG_ZTS_H_

#include "timer_whl.h"
#include "zts_pt.h"

#define ALG_ZTS
#define STAT_ZTS

class CandMode{
public:
	CandMode()
	{
		p=t=acc_p=0;
	}
	~CandMode(){;}
	CandMode & operator = (CandMode & in)
	{
		mode = in.mode;
		p = in.p;
		t = in.t;
		return *this;
	}
public:
	ModeLabel mode;
	double p;
	double t;
	double acc_p;
};

class FMDModule{
public:

	FMDModule();
	~FMDModule();

	void InitAll(int MaxTLayer, int HeightInMbs, int WidthInMbs, int ViewId); 
	void StoreTrans();

	void StartFrameEncoding(int TLayer, int Poc, int Layer_Qp);
	void FinishFrameEncoding();

	void StartMBEncoding(int MbY, int MbX);
	void FinishMBEncoding(int MbY, int MbX, char best_mode, bool isInterB);

	char PopModeInList();
	bool IsSubModeNotSkipped(char sub_mode);


private:
	string int2str(int &i)
	{
		string s;
		stringstream ss(s);
		ss<<i;
		return ss.str();
	}
	ModeLabel mode2label(char mode)
	{
		if(mode<5)
			return (ModeLabel(mode));
		if (mode==5)
			return MD_8x8_ZTS;
		return MD_INTRA_ZTS;
	}
	void BubbleSortList(OptModelLabel model)
	{
		int i,j;
		CandMode tmp;
		if (model == OPT_MODEL_P)
		{
			for(i=0; i<NUM_CANDIDATE_MODE; i++)
				for(j=NUM_CANDIDATE_MODE-1; j>i; j--)
				{
					if (ModeList[OPT_MODEL_P][i].p < ModeList[OPT_MODEL_P][j].p)
					{
						tmp = ModeList[OPT_MODEL_P][i];
						ModeList[OPT_MODEL_P][i] = ModeList[OPT_MODEL_P][j];
						ModeList[OPT_MODEL_P][j] = tmp;
					}
				}
		}
		else
		{
			for(i=0; i<NUM_CANDIDATE_MODE; i++)
				for(j=NUM_CANDIDATE_MODE-1; j>i; j--)
				{
					if(ModeList[OPT_MODEL_P_T][i].p/ModeList[OPT_MODEL_P_T][i].t < ModeList[OPT_MODEL_P_T][j].p/ModeList[OPT_MODEL_P_T][j].t)
					{
						tmp = ModeList[OPT_MODEL_P_T][i];
						ModeList[OPT_MODEL_P_T][i] = ModeList[OPT_MODEL_P_T][j];
						ModeList[OPT_MODEL_P_T][j] = tmp;
					}	
				}
		}
		ModeList[model][0].acc_p = ModeList[model][0].p;
		for (i=1; i<NUM_CANDIDATE_MODE; i++)
			ModeList[model][i].acc_p = ModeList[model][i-1].acc_p + ModeList[model][i].p;
	}
	void CalcOptStop();
	void DecideOptModel();

private:

	// for storing data
	double m_tau;
	string TempFolder;
	string ModeTransMatricesFile;
	string InterViewModeFile[3];

	// p & t
	ModePredModule *MyModePred;
	TimePredModule *MyTimePred;
	int m_FwdViewId, m_BwdViewId;
	int m_ViewId;
	bool m_IsAnchorView, m_IsFirstView, m_IsLastView;
	vector<double> prob_list, time_list;

	// mode decision
	int m_TLayer, m_Poc;
	bool m_FMDEnabled_MB;

	OptModelLabel m_Model;
	CandMode ModeList[2][NUM_CANDIDATE_MODE];
	int m_Ks[2];
	int curr_mode_idx;

	bool m_SubModeEnabled[4];
};


#ifdef ALG_ZTS
	extern FMDModule *MyAlg;
#endif ALG_ZTS

#ifdef STAT_ZTS
	extern int fileno_stat;
	extern int view_stat;
	extern int Qp_stat;
	extern double PSNR_stat;
	extern double Bitrates_stat;
#endif STAT_ZTS

#endif _ALG_ZTS_H_