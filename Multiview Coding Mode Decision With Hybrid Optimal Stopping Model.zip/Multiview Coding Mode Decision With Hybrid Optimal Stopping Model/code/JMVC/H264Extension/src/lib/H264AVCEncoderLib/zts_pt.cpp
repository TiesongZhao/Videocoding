#include "zts_pt.h"

ModePredModule::ModePredModule()
{	
}

ModePredModule::~ModePredModule()
{
	delete(curr_mode[0]);
	delete(curr_mode);
	delete(trans_upper[0]);
	delete(trans_upper);
	delete(trans_left[0]);
	delete(trans_left);
	if (m_FwdInterView)
	{
		delete(fwd_mode[0]);
		delete(fwd_mode);
		delete(trans_fwd[0]);
		delete(trans_fwd);
	}
	if (m_BwdInterView)
	{
		delete(bwd_mode[0]);
		delete(bwd_mode);
		delete(trans_bwd[0]);
		delete(trans_bwd);
	}
}

void ModePredModule::InitAll(int MaxTLayer, int HeightInMbs, int WidthInMbs, bool FwdInterView, bool BwdInterView)
{
	m_MaxTLayerPlus1 = ++MaxTLayer;
	m_HeightInMbs = HeightInMbs;
	m_WidthInMbs = WidthInMbs;
	m_FwdInterView = FwdInterView;
	m_BwdInterView = BwdInterView;
	matrix_height = m_MaxTLayerPlus1 * NUM_CANDIDATE_MODE;	// all layers & all reference modes

	int i,j;
	double init_value = 1.0/6;
	int matrix_alloc = matrix_height * NUM_CANDIDATE_MODE; 
	int mode_alloc = m_HeightInMbs * m_WidthInMbs;
	
	curr_mode = new int *[m_HeightInMbs];
	curr_mode[0] = new int [mode_alloc];
	for (j=1; j<m_HeightInMbs; j++)
	{
		curr_mode[j] = curr_mode[j-1] + m_WidthInMbs;
	}

	trans_upper = new double *[matrix_height];
	trans_upper[0] = new double [matrix_alloc];
	for(j=1; j<matrix_height; j++)
	{
		trans_upper[j] = trans_upper[j-1] + NUM_CANDIDATE_MODE; 
	}
	trans_left = new double *[matrix_height];
	trans_left[0] = new double [matrix_alloc];
	for(j=1; j<matrix_height; j++)
	{
		trans_left[j] = trans_left[j-1] + NUM_CANDIDATE_MODE; 
	}
	for (j=0; j<matrix_height; j++)
	{
		for (i=0; i<NUM_CANDIDATE_MODE; i++)
		{
			trans_upper[j][i] = trans_left[j][i] = init_value;
		}
	}

	if (m_FwdInterView)
	{
		trans_fwd = new double *[matrix_height];
		trans_fwd[0] = new double [matrix_alloc];
		for(j=1; j<matrix_height; j++)
		{
			trans_fwd[j] = trans_fwd[j-1] + NUM_CANDIDATE_MODE;
		}
		for (j=0; j<matrix_height; j++)
		{
			for (i=0; i<NUM_CANDIDATE_MODE; i++)
			{
				trans_fwd[j][i] = init_value;
			}
		}
		fwd_mode = new int *[m_HeightInMbs];
		fwd_mode[0] = new int [mode_alloc];
		for (j=1; j<m_HeightInMbs; j++)
		{
			fwd_mode[j] = fwd_mode[j-1] + m_WidthInMbs;
		}
	}

	if (m_BwdInterView)
	{
		trans_bwd = new double *[matrix_height];
		trans_bwd[0] = new double [matrix_alloc];
		for(j=1; j<matrix_height; j++)
		{
			trans_bwd[j] = trans_bwd[j-1] + NUM_CANDIDATE_MODE;
		}
		for (j=0; j<matrix_height; j++)
		{
			for (i=0; i<NUM_CANDIDATE_MODE; i++)
			{
				trans_bwd[j][i] = init_value;
			}
		}
		bwd_mode = new int *[m_HeightInMbs];
		bwd_mode[0] = new int [mode_alloc];
		for (j=1; j<m_HeightInMbs; j++)
		{
			bwd_mode[j] = bwd_mode[j-1] + m_WidthInMbs;
		}
	}
}

void ModePredModule::WriteModeTransMatrices(string outfile)
{
	ofstream out1(outfile.c_str());
	int i, j;
	double init_value = 1.0/6;

	for (j=0; j<matrix_height; j++)
	{
		for (i=0; i<NUM_CANDIDATE_MODE; i++)
		{
			out1 << trans_upper[j][i] << "\t";
		}
		out1 << endl;
	}
	for (j=0; j<matrix_height; j++)
	{
		for (i=0; i<NUM_CANDIDATE_MODE; i++)
		{
			out1 << trans_left[j][i] << "\t";
		}
		out1 << endl;
	}

	if (m_FwdInterView)
	{
		for (j=0; j<matrix_height; j++)
		{
			for (i=0; i<NUM_CANDIDATE_MODE; i++)
			{
				out1 << trans_fwd[j][i] << "\t";
			}
			out1 << endl;
		}
	}
	else
	{
		for (j=0; j<matrix_height; j++)
		{
			for (i=0; i<NUM_CANDIDATE_MODE; i++)
			{
				out1 << init_value << "\t";
			}
			out1 << endl;
		}
	}
	if (m_BwdInterView)
	{
		for (j=0; j<matrix_height; j++)
		{
			for (i=0; i<NUM_CANDIDATE_MODE; i++)
			{
				out1 << trans_bwd[j][i] << "\t";
			}
			out1 << endl;
		}
	}
	else
	{
		for (j=0; j<matrix_height; j++)
		{
			for (i=0; i<NUM_CANDIDATE_MODE; i++)
			{
				out1 << init_value << "\t";
			}
			out1 << endl;
		}
	}
	out1.close();
}


void ModePredModule::LoadModeTransMatrices(string infile)
{
	ifstream in1(infile.c_str());
	istringstream istr1;
	string str1;
	int i, j = 0;
	int j_quot, j_rem;
	while(getline(in1,str1))
	{
		j_quot = j / matrix_height;
		j_rem = j % matrix_height;

		istr1.str(str1);
		double tmp;
		i = 0;
		while(istr1>>tmp)
		{
			if (j_quot == 0)
			{
				trans_upper[j_rem][i++] = tmp; 
			}
			else if (j_quot==1)
			{
				trans_left[j_rem][i++] = tmp;
			}
			else if (j_quot==2)
			{
				if (m_FwdInterView)
					trans_fwd[j_rem][i++] = tmp;
			}
			else
			{
				if (m_BwdInterView)
					trans_bwd[j_rem][i++] = tmp;
			}		
		}
		j++;
		istr1.clear();
	}
	in1.close();
}

void ModePredModule::WriteCurrModes(string outfile)
{
	ofstream out1(outfile.c_str());
	int i,j;
	for (j=0; j<m_HeightInMbs; j++)
	{
		for (i=0; i<m_WidthInMbs; i++)
		{
			out1 << curr_mode[j][i] <<"\t";
		}
		out1 << endl;
	}
	out1.close();
}

void ModePredModule::LoadInterViewModes(string fwd_in, string bwd_in)
{
	int i, j;
	istringstream istr1;
	string str1;
	if (m_FwdInterView)
	{
		ifstream in1(fwd_in.c_str());
		j = 0;
		while(getline(in1,str1))
		{
			istr1.str(str1);
			int tmp;
			i = 0;
			while(istr1>>tmp)
			{
				fwd_mode[j][i++] = tmp;
			}
			j++;
			istr1.clear();
		}
		in1.close();
	}
	if (m_BwdInterView)
	{
		ifstream in2(bwd_in.c_str());
		j = 0;
		while(getline(in2,str1))
		{
			istr1.str(str1);
			int tmp;
			i = 0;
			while(istr1>>tmp)
			{
				bwd_mode[j][i++] = tmp;
			}
			j++;
			istr1.clear();
		}
		in2.close();
	}
}

void ModePredModule::StartTLayer(int TLayer)
{
	m_Start = TLayer * NUM_CANDIDATE_MODE;
}

vector<double> ModePredModule::GetModeProbList(int mb_y, int mb_x)
{
	int k; 
	double __sum = 0;
	vector<double> prob_list;

	for (k=0; k<NUM_CANDIDATE_MODE; k++)
	{
		double __p = 0;
		if (mb_y > 0)
			__p += trans_upper[ m_Start+curr_mode[mb_y-1][mb_x] ][k];
		if (mb_x > 0)
			__p += trans_left[ m_Start+curr_mode[mb_y][mb_x-1] ][k];
		if (m_FwdInterView)
			__p += trans_fwd[ m_Start+fwd_mode[mb_y][mb_x] ][k];
		if (m_BwdInterView)
			__p += trans_bwd[ m_Start+bwd_mode[mb_y][mb_x] ][k];
		prob_list.push_back(__p);
		__sum += __p;
	}
	for (k=0; k<NUM_CANDIDATE_MODE; k++)
	{
		prob_list[k] /= __sum;
	}
	return prob_list;
}

void ModePredModule::UpdateModeProb(int mb_y, int mb_x, char bmode_label, vector<double> prob_list)
{
	curr_mode[mb_y][mb_x] = bmode_label;
	for (int k=0; k<NUM_CANDIDATE_MODE; k++)
	{
		if (mb_y > 0)
		{
			trans_upper[ m_Start+curr_mode[mb_y-1][mb_x] ][k] *= (1-PARA_MODE_ADAP_RATE);
			trans_upper[ m_Start+curr_mode[mb_y-1][mb_x] ][k] += PARA_MODE_ADAP_RATE * prob_list[k];
		}
		if (mb_x > 0)
		{
			trans_left[ m_Start+curr_mode[mb_y][mb_x-1] ][k] *= (1-PARA_MODE_ADAP_RATE);
			trans_left[ m_Start+curr_mode[mb_y][mb_x-1] ][k] += PARA_MODE_ADAP_RATE * prob_list[k];
		}
		if (m_FwdInterView)
		{
			trans_fwd[ m_Start+fwd_mode[mb_y][mb_x] ][k] *= (1-PARA_MODE_ADAP_RATE);
			trans_fwd[ m_Start+fwd_mode[mb_y][mb_x] ][k] += PARA_MODE_ADAP_RATE * prob_list[k];
		}
		if (m_BwdInterView)
		{
			trans_bwd[ m_Start+bwd_mode[mb_y][mb_x] ][k] *= (1-PARA_MODE_ADAP_RATE);
			trans_bwd[ m_Start+bwd_mode[mb_y][mb_x] ][k] += PARA_MODE_ADAP_RATE * prob_list[k];
		}
	}
}

void ModePredModule::UpdateBestModeOnly(int mb_y, int mb_x, char bmode_label)
{
	curr_mode[mb_y][mb_x] = bmode_label;
}

TimePredModule::TimePredModule()
{
}

TimePredModule::~TimePredModule()
{
}

void TimePredModule::SetView(bool IsSingleInterView)
{
	if(!IsSingleInterView)
	{
		p_skip[0][0]=0.00010025;
		p_skip[0][1]=-0.001016;
		p_skip[0][2]=0.2453;
		p_skip[1][0]=0.00012103;
		p_skip[1][1]=-0.006105;
		p_skip[1][2]=0.1711;
		p_skip[2][0]=0.00012693;
		p_skip[2][1]=-0.006368;
		p_skip[2][2]=0.1759;
		p_skip[3][0]=0.00013532;
		p_skip[3][1]=-0.006860;
		p_skip[3][2]=0.1836;
		p_skip[4][0]=0.00013721;
		p_skip[4][1]=-0.006891;
		p_skip[4][2]=0.1823;

		p_16x16[0][0]=0.243543;
		p_16x16[0][1]=8.1051;
		p_16x16[1][0]=0.222750;
		p_16x16[1][1]=7.8153;
		p_16x16[2][0]=0.218970;
		p_16x16[2][1]=7.8822;
		p_16x16[3][0]=0.216474;
		p_16x16[3][1]=7.9010;
		p_16x16[4][0]=0.213065;
		p_16x16[4][1]=7.9693;

		p_16x8[0][0]=0.144894;
		p_16x8[0][1]=9.4384;
		p_16x8[1][0]=0.116749;
		p_16x8[1][1]=10.0898;
		p_16x8[2][0]=0.111868;
		p_16x8[2][1]=10.2707;
		p_16x8[3][0]=0.108002;
		p_16x8[3][1]=10.3982;
		p_16x8[4][0]=0.103674;
		p_16x8[4][1]=10.5359;

		p_8x16[0][0]=0.147609;
		p_8x16[0][1]=10.8238;
		p_8x16[1][0]=0.119566;
		p_8x16[1][1]=11.4149;
		p_8x16[2][0]=0.114254;
		p_8x16[2][1]=11.5925;
		p_8x16[3][0]=0.108749;
		p_8x16[3][1]=11.7583;
		p_8x16[4][0]=0.103860;
		p_8x16[4][1]=11.9195;

		p_8x8[0][0]=-0.555185;
		p_8x8[0][1]=70.1347;
		p_8x8[1][0]=-0.464823;
		p_8x8[1][1]=69.9930;
		p_8x8[2][0]=-0.453060;
		p_8x8[2][1]=69.5921;
		p_8x8[3][0]=-0.443024;
		p_8x8[3][1]=69.3031;
		p_8x8[4][0]=-0.432369;
		p_8x8[4][1]=68.9867;
	}
	else
	{
		p_skip[0][0]=-0.00001166;
		p_skip[0][1]=0.004321;
		p_skip[0][2]=-0.0004;
		p_skip[1][0]=0.00010073;
		p_skip[1][1]=-0.003985;
		p_skip[1][2]=0.4050;
		p_skip[2][0]=0.00008986;
		p_skip[2][1]=-0.004071;
		p_skip[2][2]=0.3024;
		p_skip[3][0]=0.00007336;
		p_skip[3][1]=-0.003407;
		p_skip[3][2]=0.2876;
		p_skip[4][0]=0.00006873;
		p_skip[4][1]=-0.003122;
		p_skip[4][2]=0.2840;
		
		p_16x16[0][0]=0.305714;
		p_16x16[0][1]=7.6914;
		p_16x16[1][0]=0.204859;
		p_16x16[1][1]=8.0195;
		p_16x16[2][0]=0.174389;
		p_16x16[2][1]=8.6904;
		p_16x16[3][0]=0.152929;
		p_16x16[3][1]=9.1889;
		p_16x16[4][0]=0.139383;
		p_16x16[4][1]=9.5897;
		
		p_16x8[0][0]=0.112014;
		p_16x8[0][1]=9.6160;
		p_16x8[1][0]=0.093149;
		p_16x8[1][1]=10.2685;
		p_16x8[2][0]=0.082579;
		p_16x8[2][1]=10.7760;
		p_16x8[3][0]=0.072906;
		p_16x8[3][1]=11.1619;
		p_16x8[4][0]=0.062856;
		p_16x8[4][1]=11.5462;
		
		p_8x16[0][0]=0.134294;
		p_8x16[0][1]=10.8865;
		p_8x16[1][0]=0.098108;
		p_8x16[1][1]=11.4466;
		p_8x16[2][0]=0.084726;
		p_8x16[2][1]=11.9984;
		p_8x16[3][0]=0.072895;
		p_8x16[3][1]=12.3674;
		p_8x16[4][0]=0.062999;
		p_8x16[4][1]=12.7120;
		
		p_8x8[0][0]=-0.624007;
		p_8x8[0][1]=69.2918;
		p_8x8[1][0]=-0.403297;
		p_8x8[1][1]=67.4762;
		p_8x8[2][0]=-0.346623;
		p_8x8[2][1]=66.5368;
		p_8x8[3][0]=-0.302304;
		p_8x8[3][1]=65.2971;
		p_8x8[4][0]=-0.268391;
		p_8x8[4][1]=64.1335;
	}
	TimeListCalculated[0] = TimeListCalculated[1] = TimeListCalculated[2] =
		TimeListCalculated[3] = TimeListCalculated[4] = false;  
}

vector<double> TimePredModule::GetTimeList(int TLayer, int Layer_Qp)
{
	TLayer = TLayer<5? TLayer : 4;
	if (TimeListCalculated[TLayer])
	{
		return TimeMat[TLayer];
	}
	vector <double> TimeList;
	double t, sumt=0;
	t = ((p_skip[TLayer][0]*Layer_Qp+p_skip[TLayer][1])*Layer_Qp+p_skip[TLayer][2])/100;
	sumt += t;
	TimeList.push_back(t);
	t = (p_16x16[TLayer][0]*Layer_Qp+p_16x16[TLayer][1])/100;
	sumt += t;
	TimeList.push_back(t);
	t = (p_16x8[TLayer][0]*Layer_Qp+p_16x8[TLayer][1])/100;
	sumt += t;
	TimeList.push_back(t);
	t = (p_8x16[TLayer][0]*Layer_Qp+p_8x16[TLayer][1])/100;
	sumt += t;
	TimeList.push_back(t);
	t = (p_8x8[TLayer][0]*Layer_Qp+p_8x8[TLayer][1])/100;
	sumt += t;
	TimeList.push_back(t);
	TimeList.push_back(1-sumt);
	TimeMat.push_back(TimeList);
	TimeListCalculated[TLayer] = true;
	return TimeList;
}