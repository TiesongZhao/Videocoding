#include "ZtsFPS.h"

#ifdef ZTS_ALG
	zFlexiblePartitionSlection *MyAlg;
#endif ZTS_ALG

#ifdef ZTS_STAT
	int zts_seqno;
	int zts_qp;
	double zts_cmpfctr;
	double zts_time;
	double zts_psnr;
	double zts_br;
#endif ZTS_STAT

#ifdef PART_LVL_CP_ALLOC
const double zts_deltaCF[4][4]={
        {0.0339,0.0196,-0.0122,-0.0412},
        {0.0044,0.0187,0.0044,-0.0274},
        {-0.0274,0.0044,0.0187,0.0044},
        {-0.0412,-0.0122,0.0196,0.0339}
};
#endif PART_LVL_CP_ALLOC

zImgFPS::zImgFPS()
{
	m_FrameCnt = 0;
	/*
#ifdef PART_LVL_CP_ALLOC
	double guassianweight[7];
	double adapt_para_a = 0.1;
	double adapt_para_b = 1.75;
	for (int k=0; k<7; k++)
	{
		guassianweight[k] = (k-3.0) / adapt_para_b;
		guassianweight[k] *= guassianweight[k];
		guassianweight[k] = adapt_para_a * exp(-guassianweight[k]/2);
	}
	for (int j=0; j<4; j++)
	{
		double aveweight = 0;
		for (int i=0; i<4; i++)
		{
			m_deltaCF[j][i] = guassianweight[i-j+3];
			aveweight += m_deltaCF[j][i];
		}
		aveweight /= 4;
		for (int i=0; i<4; i++)
		{
			m_deltaCF[j][i] -= aveweight;
		}
	}
#endif PART_LVL_CP_ALLOC
	*/
}
zImgFPS::~zImgFPS()
{
	delete(m_EPPredictor64[0]);
	delete(m_EPPredictor64);
	delete(m_EPPredictor32[0]);
	delete(m_EPPredictor32);
	delete(m_EPPredictor16[0]);
	delete(m_EPPredictor16);
	delete(m_EPPredictor8[0]);
	delete(m_EPPredictor8);
}

void zImgFPS::setImg(zImgFPS &TemporalImg, unsigned int ImgHeightInPels, unsigned int ImgWidthInPels)
{
	m_ImgWidth = ImgWidthInPels;
	m_ImgHeight = ImgHeightInPels;
	m_PredMatSize[0][0] = (ImgHeightInPels+63)>>6;
	m_PredMatSize[0][1] = (ImgWidthInPels+63)>>6;
	initEPPredictor (&m_EPPredictor64, &(TemporalImg.m_EPPredictor64), m_PredMatSize[0][0], m_PredMatSize[0][1]);
	m_PredMatSize[1][0] = (ImgHeightInPels+31)>>5;
	m_PredMatSize[1][1] = (ImgWidthInPels+31)>>5;
	initEPPredictor (&m_EPPredictor32, &(TemporalImg.m_EPPredictor32), m_PredMatSize[1][0], m_PredMatSize[1][1]);
	m_PredMatSize[2][0] = (ImgHeightInPels+15)>>4;
	m_PredMatSize[2][1] = (ImgWidthInPels+15)>>4;
	initEPPredictor (&m_EPPredictor16, &(TemporalImg.m_EPPredictor16), m_PredMatSize[2][0], m_PredMatSize[2][1]);
	m_PredMatSize[3][0] = (ImgHeightInPels+7)>>3;
	m_PredMatSize[3][1] = (ImgWidthInPels+7)>>3;
	initEPPredictor (&m_EPPredictor8, &(TemporalImg.m_EPPredictor8), m_PredMatSize[3][0], m_PredMatSize[3][1]);
#ifdef CU_LVL_CP_ALLOC
	m_PredictError = new double*[m_PredMatSize[0][0]];
	m_PredictError[0] = new double[m_PredMatSize[0][0]*m_PredMatSize[0][1]];
	for (unsigned int j=1; j<m_PredMatSize[0][0]; j++)
	{
		m_PredictError[j] = m_PredictError[j-1] + m_PredMatSize[0][1];
	}
#endif CU_LVL_CP_ALLOC
}

void zImgFPS::initEPPredictor(zEPPredictor ***EPPredictorMatPointer, zEPPredictor ***EPPredictorTemporalMatPointer, int height, int width)
{
	(*EPPredictorMatPointer) = new zEPPredictor*[height];
	(*EPPredictorMatPointer)[0] = new zEPPredictor[height*width];
	int i, j;
	for (j=1; j<height; j++)
	{
		(*EPPredictorMatPointer)[j] = (*EPPredictorMatPointer)[j-1] + width;
	}
	for (j=0; j<height; j++)
	{
		for (i=0; i<width; i++)
		{
			if (j > 0)
				(*EPPredictorMatPointer)[j][i].setUpperPredictor(&((*EPPredictorMatPointer)[j-1][i]));
			if (i > 0)
				(*EPPredictorMatPointer)[j][i].setLeftPredictor(&((*EPPredictorMatPointer)[j][i-1]));
			(*EPPredictorMatPointer)[j][i].setTemporalPredictor(&((*EPPredictorTemporalMatPointer)[j][i]));
		}
	}
}

void zImgFPS::setComplexFactor (double ImgComplexityFactor)
{
	m_ImgComplexFactor = ImgComplexityFactor;
}

void zImgFPS::StartCU (unsigned int CUPelY, unsigned int CUPelX, unsigned int CUDepth)
{
	if (CUDepth == 0 && CUPelY == 0 && CUPelX == 0)
	{
		m_FrameCnt ++;
	}

	for (int part_idx = 0; part_idx<8; part_idx++)
	{
		m_PartEnabled[part_idx] = true;
	}

	if (m_FrameCnt < 2)
		return;

#ifndef CU_LVL_CP_ALLOC
	m_CUComplexFactor = m_ImgComplexFactor;
#else
	double zts_cu_adapt_coeff = 0.05;
	if (CUPelY == 0 && CUPelX == 0 && CUDepth == 0)
	{
		m_AvePredictError = 0;
		for (unsigned int j = 0; j < m_PredMatSize[0][0]; j ++)
		{
			for (unsigned int i = 0; i < m_PredMatSize[0][1]; i ++)
			{
				m_AvePredictError += m_PredictError[j][i];
			}
		}
		m_AvePredictError /= (m_PredMatSize[0][0]*m_PredMatSize[0][1]);
	}
	if (CUDepth == 0)
	{
		m_CUComplexFactor = m_PredictError[CUPelY>>6][CUPelX>>6] / m_AvePredictError;
		m_CUComplexFactor = m_ImgComplexFactor * (1-zts_cu_adapt_coeff+zts_cu_adapt_coeff*m_CUComplexFactor);
	}
#endif CU_LVL_CP_ALLOC

	if (CUDepth == 0)
	{
		predictCU (&(m_EPPredictor64[CUPelY>>6][CUPelX>>6]), 0);
		// block in edge; must split
		if (CUPelY+64 > m_ImgHeight || CUPelX+64 > m_ImgWidth)
			m_PartEnabled[3] = true;
	}
	else if (CUDepth == 1)
	{
		predictCU (&(m_EPPredictor32[CUPelY>>5][CUPelX>>5]), 1);
		if (CUPelY+32 > m_ImgHeight || CUPelX+32 > m_ImgWidth)
			m_PartEnabled[3] = true;
	}
	else if (CUDepth == 2)
	{
		predictCU (&(m_EPPredictor16[CUPelY>>4][CUPelX>>4]), 2);
		if (CUPelY+16 > m_ImgHeight || CUPelX+16 > m_ImgWidth)
			m_PartEnabled[3] = true;
	}
	else
	{
		predictCU (&(m_EPPredictor8[CUPelY>>3][CUPelX>>3]), 3);
		if (CUPelY+8 > m_ImgHeight || CUPelX+8 > m_ImgWidth)
			m_PartEnabled[3] = true;
	}
}

void zImgFPS::predictCU (zEPPredictor *EPPredictorPointer, int CUDepth)
{
	int part_idx;
	double r_min = 200, r_max = 0;
	double r_list[8];
	zEuclideanPoint EstimatedEP = EPPredictorPointer->getEstimatedEP();
	zEuclideanPoint PartEP;
	for (part_idx = 0; part_idx<8; part_idx++)
	{
		PartEP.SetPartEP(CUDepth, part_idx);
		r_list[part_idx] = EstimatedEP.getDist(PartEP);
		if (part_idx > 3)
			continue;
		if (r_list[part_idx] < r_min)
			r_min = r_list[part_idx];
		if (r_list[part_idx] > r_max)
			r_max = r_list[part_idx];
	}
#ifndef PART_LVL_CP_ALLOC
	double r = r_min + m_CUComplexFactor * (r_max-r_min);
#else
	//double CurrCF = m_CUComplexFactor + m_deltaCF[EstimatedEP.getDepth()][CUDepth];
	double CurrCF = m_CUComplexFactor + zts_deltaCF[EstimatedEP.getDepth()][CUDepth];
	if (CurrCF < 0)
		CurrCF = 0;
	if (CurrCF > 1)
		CurrCF = 1;
	double r = r_min + CurrCF * (r_max-r_min);
#endif PART_LVL_CP_ALLOC
	for (part_idx = 0; part_idx<8; part_idx++)
	{
		if (r_list[part_idx] > r)
			m_PartEnabled[part_idx] = false;
	}
}

bool zImgFPS::IsPartSizeEnabled(int PartSize)
{
	return m_PartEnabled[PartSize];
}

bool zImgFPS::IsIntraEnabled()
{
	for (int PartSize = 0; PartSize<3; PartSize++)
	{
		if (m_PartEnabled[PartSize])
			return false;
	}
	return true;
}

void zImgFPS::setPartSize8x8(unsigned int BlkPelY, unsigned int BlkPelX, unsigned int CUDepth, unsigned int Depth, unsigned int PartSize)
{
	unsigned int blk8x8_y = BlkPelY>>3, blk8x8_x = BlkPelX>>3;
	if (blk8x8_y >= m_PredMatSize[3][0] || blk8x8_x >= m_PredMatSize[3][1] || PartSize > 7)
		return;
	zEuclideanPoint Block8EP;
	Block8EP.SetPartEP(Depth, PartSize);
	m_EPPredictor8[blk8x8_y][blk8x8_x].setBlockEP(Block8EP, CUDepth==0 && m_FrameCnt>1);
}

void zImgFPS::EndCU(unsigned int CUPelY, unsigned int CUPelX, unsigned int CUDepth)
{
	if (CUDepth > 2)
		return;

	bool UpdateWeight = (CUDepth == 0 && m_FrameCnt>1);

	// update 16x16
	int j, i, max_j, max_i;
	if (CUDepth == 0)
	{
		max_j = max_i = 16;
	}
	else if (CUDepth == 1)
	{
		max_j = max_i = 4;
	}
	else
	{
		max_j = max_i = 1;
	}
	unsigned int blk16x16_y, blk16x16_x, blk8x8_y, blk8x8_x;
	int num;
	zEuclideanPoint BlockEP;
	for (j=0, blk16x16_y=CUPelY>>4; j<max_j; j++, blk16x16_y++)
	{
		for (i=0, blk16x16_x=CUPelX>>4; i<max_i; i++, blk16x16_x++)
		{
			if (blk16x16_y >= m_PredMatSize[2][0] || blk16x16_x >= m_PredMatSize[2][1])
				continue;
			BlockEP.SetZero();
			num = 0;
			for (blk8x8_y=blk16x16_y<<1; blk8x8_y<(blk16x16_y<<1)+2; blk8x8_y++)
			{
				for (blk8x8_x=blk16x16_x<<1; blk8x8_x<(blk16x16_x<<1)+2; blk8x8_x++)
				{
					if (blk8x8_y >= m_PredMatSize[3][0] || blk8x8_x >= m_PredMatSize[3][1])
						continue;
					num ++;
					BlockEP += m_EPPredictor8[blk8x8_y][blk8x8_x].getBlockEP();
				}
			}
			BlockEP /= num;
			m_EPPredictor16[blk16x16_y][blk16x16_x].setBlockEP(BlockEP, UpdateWeight);
		}
	}
	if (CUDepth > 1)
		return;

	// update 32x32
	if (CUDepth == 0)
	{
		max_j = max_i = 4;
	}
	else
	{
		max_j = max_i = 1;
	}
	unsigned int blk32x32_y, blk32x32_x;
	for (j=0, blk32x32_y=CUPelY>>5; j<max_j; j++, blk32x32_y++)
	{
		for (i=0, blk32x32_x=CUPelX>>5; i<max_i; i++, blk32x32_x++)
		{
			if (blk32x32_y >= m_PredMatSize[1][0] || blk32x32_x >= m_PredMatSize[1][1])
				continue;
			BlockEP.SetZero();
			num = 0;
			for (blk16x16_y=blk32x32_y<<1; blk16x16_y<(blk32x32_y<<1)+2; blk16x16_y++)
			{
				for (blk16x16_x=blk32x32_x<<1; blk16x16_x<(blk32x32_x<<1)+2; blk16x16_x++)
				{
					if (blk16x16_y >= m_PredMatSize[2][0] || blk16x16_x >= m_PredMatSize[2][1])
						continue;
					num ++;
					BlockEP += m_EPPredictor16[blk16x16_y][blk16x16_x].getBlockEP();
				}
			}
			BlockEP /= num;
			m_EPPredictor32[blk32x32_y][blk32x32_x].setBlockEP(BlockEP, UpdateWeight);
		}
	}
	if (CUDepth > 0)
		return;

	unsigned int blk64x64_y = CUPelY>>6, blk64x64_x = CUPelX>>6;
	//if (blk64x64_y >= m_PredMatSize[0][0] || blk64x64_x >= m_PredMatSize[0][1])
	//	continue;
	BlockEP.SetZero();
	num = 0;
	for (blk32x32_y=blk64x64_y<<1; blk32x32_y<(blk64x64_y<<1)+2; blk32x32_y++)
	{
		for (blk32x32_x=blk64x64_x<<1; blk32x32_x<(blk64x64_x<<1)+2; blk32x32_x++)
		{
			if (blk32x32_y >= m_PredMatSize[1][0] || blk32x32_x >= m_PredMatSize[1][1])
				continue;
			num ++;
			BlockEP += m_EPPredictor32[blk32x32_y][blk32x32_x].getBlockEP();
		}
	}
	BlockEP /= num;
	m_EPPredictor64[blk64x64_y][blk64x64_x].setBlockEP(BlockEP, UpdateWeight);
#ifdef CU_LVL_CP_ALLOC
	m_PredictError[blk64x64_y][blk64x64_x] = m_EPPredictor64[blk64x64_y][blk64x64_x].getPredictionError(BlockEP);
#endif CU_LVL_CP_ALLOC
}

zFlexiblePartitionSlection::zFlexiblePartitionSlection()
{
}

zFlexiblePartitionSlection::~zFlexiblePartitionSlection()
{
	delete(m_ImgFPS);
}

void zFlexiblePartitionSlection::SetImgFPS (unsigned int NumPicDepths, unsigned int ImgHeightInPels, unsigned int ImgWidthInPels)
{
	m_NumPicDepths = NumPicDepths;
	m_CurrImgDepth = 0;
	m_ImgFPS = new zImgFPS[NumPicDepths];
	m_ImgFPS[0].setImg(m_ImgFPS[0], ImgHeightInPels, ImgWidthInPels);
	for (unsigned int k = 1; k < NumPicDepths; k++)
	{
		m_ImgFPS[k].setImg(m_ImgFPS[k-1], ImgHeightInPels, ImgWidthInPels);
	}
}

void zFlexiblePartitionSlection::SetComplexFactor(double GobalComplexityFactor)
{
#ifndef IMG_LVL_CP_ALLOC
	for (unsigned int k = 0; k < m_NumPicDepths; k++)
	{
		m_ImgFPS[k].setComplexFactor(GobalComplexityFactor);
	}
#else
	double HBPComplexityAllocationMat[101][5]={
                {0,0,0,0,0},
                {0.01,0.045,0.005,0.005,0.005},
                {0.02,0.09,0.01,0.01,0.01},
                {0.03,0.135,0.015,0.015,0.015},
                {0.04,0.18,0.02,0.02,0.02},
                {0.05,0.225,0.025,0.025,0.025},
                {0.06,0.27,0.03,0.03,0.03},
                {0.07,0.315,0.035,0.035,0.035},
                {0.08,0.36,0.04,0.04,0.04},
                {0.09,0.405,0.045,0.045,0.045},
                {0.1,0.45,0.05,0.05,0.05},
                {0.11,0.495,0.055,0.055,0.055},
                {0.12,0.54,0.06,0.06,0.06},
                {0.13,0.585,0.065,0.065,0.065},
                {0.14,0.63,0.07,0.07,0.07},
                {0.15,0.675,0.075,0.075,0.075},
                {0.16,0.72,0.08,0.08,0.08},
                {0.17,0.765,0.085,0.085,0.085},
                {0.18,0.81,0.09,0.09,0.09},
                {0.19,0.855,0.095,0.095,0.095},
                {0.2,0.9,0.1,0.1,0.1},
                {0.21,0.945,0.105,0.105,0.105},
                {0.22,0.99,0.11,0.11,0.11},
                {0.23,1,0.15,0.115,0.115},
                {0.24,1,0.2,0.12,0.12},
                {0.25,1,0.25,0.125,0.125},
                {0.26,1,0.3,0.13,0.13},
                {0.27,1,0.35,0.135,0.135},
                {0.28,1,0.4,0.14,0.14},
                {0.29,1,0.45,0.145,0.145},
                {0.3,1,0.5,0.15,0.15},
                {0.31,1,0.55,0.155,0.155},
                {0.32,1,0.6,0.16,0.16},
                {0.33,1,0.65,0.165,0.165},
                {0.34,1,0.7,0.17,0.17},
                {0.35,1,0.75,0.175,0.175},
                {0.36,1,0.8,0.18,0.18},
                {0.37,1,0.85,0.185,0.185},
                {0.38,1,0.9,0.19,0.19},
                {0.39,1,0.95,0.195,0.195},
                {0.4,1,1,0.2,0.2},
                {0.41,1,1,0.23,0.205},
                {0.42,1,1,0.26,0.21},
                {0.43,1,1,0.29,0.215},
                {0.44,1,1,0.32,0.22},
                {0.45,1,1,0.35,0.225},
                {0.46,1,1,0.38,0.23},
                {0.47,1,1,0.41,0.235},
                {0.48,1,1,0.44,0.24},
                {0.49,1,1,0.47,0.245},
                {0.5,1,1,0.5,0.25},
                {0.51,1,1,0.53,0.255},
                {0.52,1,1,0.56,0.26},
                {0.53,1,1,0.59,0.265},
                {0.54,1,1,0.62,0.27},
                {0.55,1,1,0.65,0.275},
                {0.56,1,1,0.68,0.28},
                {0.57,1,1,0.71,0.285},
                {0.58,1,1,0.74,0.29},
                {0.59,1,1,0.77,0.295},
                {0.6,1,1,0.8,0.3},
                {0.61,1,1,0.83,0.305},
                {0.62,1,1,0.86,0.31},
                {0.63,1,1,0.89,0.315},
                {0.64,1,1,0.92,0.32},
                {0.65,1,1,0.95,0.325},
                {0.66,1,1,0.98,0.33},
                {0.67,1,1,1,0.34},
                {0.68,1,1,1,0.36},
                {0.69,1,1,1,0.38},
                {0.7,1,1,1,0.4},
                {0.71,1,1,1,0.42},
                {0.72,1,1,1,0.44},
                {0.73,1,1,1,0.46},
                {0.74,1,1,1,0.48},
                {0.75,1,1,1,0.5},
                {0.76,1,1,1,0.52},
                {0.77,1,1,1,0.54},
                {0.78,1,1,1,0.56},
                {0.79,1,1,1,0.58},
                {0.8,1,1,1,0.6},
                {0.81,1,1,1,0.62},
                {0.82,1,1,1,0.64},
                {0.83,1,1,1,0.66},
                {0.84,1,1,1,0.68},
                {0.85,1,1,1,0.7},
                {0.86,1,1,1,0.72},
                {0.87,1,1,1,0.74},
                {0.88,1,1,1,0.76},
                {0.89,1,1,1,0.78},
                {0.9,1,1,1,0.8},
                {0.91,1,1,1,0.82},
                {0.92,1,1,1,0.84},
                {0.93,1,1,1,0.86},
                {0.94,1,1,1,0.88},
                {0.95,1,1,1,0.9},
                {0.96,1,1,1,0.92},
                {0.97,1,1,1,0.94},
                {0.98,1,1,1,0.96},
                {0.99,1,1,1,0.98},
                {1,1,1,1,1}
	};
	int idx = int(floor(GobalComplexityFactor/0.01+0.5));
	if (idx < 0) idx = 0;
	if (idx > 100) idx = 100;
	// only for m_NumPicDepths = 4;
	for (unsigned int k = 0; k < m_NumPicDepths; k++)
	{
		m_ImgFPS[k].setComplexFactor(HBPComplexityAllocationMat[idx][k+1]);
	}
#endif IMG_LVL_CP_ALLOC
}

void zFlexiblePartitionSlection::StartImg (unsigned int ImgDepth)
{
	m_CurrImgDepth = ImgDepth;
}

void zFlexiblePartitionSlection::StartCU (unsigned int CUPelY, unsigned int CUPelX, unsigned int CUDepth)
{
	m_ImgFPS[m_CurrImgDepth].StartCU(CUPelY, CUPelX, CUDepth);
}

bool zFlexiblePartitionSlection::IsPartSizeEnabled (int PartSize)
{
	return m_ImgFPS[m_CurrImgDepth].IsPartSizeEnabled(PartSize);
}

bool zFlexiblePartitionSlection::IsIntraEnabled()
{
	return m_ImgFPS[m_CurrImgDepth].IsIntraEnabled();
}

void zFlexiblePartitionSlection::setPartSize8x8 (unsigned int BlkPelY, unsigned int BlkPelX, unsigned int CUDepth, unsigned int Depth, unsigned int PartSize)
{
	m_ImgFPS[m_CurrImgDepth].setPartSize8x8(BlkPelY, BlkPelX, CUDepth, Depth, PartSize);
}

void zFlexiblePartitionSlection::EndCU (unsigned int CUPelY, unsigned int CUPelX, unsigned int CUDepth)
{
	m_ImgFPS[m_CurrImgDepth].EndCU (CUPelY, CUPelX, CUDepth);
}