#include "ZtsEP.h"

/*
static const double zEPyList[4][8] = 
{
	{  0,  0, 54, 54,  0,  0, 27, 27},
	{ 54, 54, 90, 90, 54, 54, 72, 72},
	{ 90, 90,114,114, 90, 90,102,102},
	{114,114,130,130,114,114,122,122}
};
static const double zEPxList[4][8] = 
{
	{  0, 54,  0, 54, 27, 27,  0,  0},
	{ 54, 90, 54, 90, 72, 72, 54, 54},
	{ 90,114, 90,114,102,102, 90, 90},
	{114,130,114,130,122,122,114,114}
};
*/
// rotated by -45 degrees, multiplied by sqrt(2)
static const double zEPyList[4][8] = 
{
	{  0, 54, 54,108, 27, 27, 27, 27},
	{108,144,144,180,126,126,126,126},
	{180,204,204,228,192,192,192,192},
	{228,244,244,260,236,236,236,236}
};
static const double zEPxList[4][8] = 
{
	{  0, 54,-54,  0, 27, 27,-27,-27},
	{  0, 36,-36,  0, 18, 18,-18,-18},
	{  0, 24,-24,  0, 12, 12,-12,-12},
	{  0, 16,-16,  0,  8,  8, -8, -8}
};

void zEuclideanPoint::SetPartEP(unsigned int depth, unsigned int part)
{
	if (depth > 3 || part > 7)
	{
		EPy = EPx = 0;
	}
	else
	{
		EPy = zEPyList[depth][part];
		EPx = zEPxList[depth][part];
	}
}

unsigned int zEuclideanPoint::getDepth()
{
	if (EPx < zEPxList[1][0])
		return 0;
	if (EPx < zEPxList[2][0])
		return 1;
	if (EPx < zEPxList[3][0])
		return 2;
	return 3;
}

zEPPredictor::zEPPredictor()
{
	m_CurrEP.SetZero(); 
	m_SpatialEP.SetZero(); 
	m_TemporalEP.SetZero(); 
	m_weight = 0;
	m_adaptfactor = 0.1;
	m_UpperExist = m_LeftExist = false;
}

void zEPPredictor::setUpperPredictor (zEPPredictor *UpperPredictor)
{
	m_UpperPredictor = UpperPredictor;
	m_UpperExist = true;
	m_weight = 0.8;
}
void zEPPredictor::setLeftPredictor (zEPPredictor *LeftPredictor)
{
	m_LeftPredictor = LeftPredictor;
	m_LeftExist = true;
	m_weight = 0.8;
}
void zEPPredictor::setTemporalPredictor (zEPPredictor *TemporalPredictor)
{
	m_TemporalPredictor = TemporalPredictor;
}

void zEPPredictor::setBlockEP (zEuclideanPoint EP, bool UpdateWeight)
{
	m_CurrEP = EP;
	if (! UpdateWeight)
		return;
	zEuclideanPoint tmp = m_SpatialEP - m_TemporalEP;
	if (tmp.IsZero())
		return;
	double WeightNow = ((m_CurrEP - m_TemporalEP) * tmp) / (tmp * tmp);
	m_weight *= (1.0 - m_adaptfactor);
	m_weight += m_adaptfactor * WeightNow;
	if (m_weight < 0)
		m_weight = 0;
	if (m_weight > 1)
		m_weight = 1;
}

zEuclideanPoint zEPPredictor::getEstimatedEP ()
{
	m_SpatialEP.SetZero();
	if (m_UpperExist)
		m_SpatialEP += m_UpperPredictor->getBlockEP();
	if (m_LeftExist)
		m_SpatialEP += m_LeftPredictor->getBlockEP();
	if (m_UpperExist && m_LeftExist)
		m_SpatialEP *= 0.5;
		
	m_TemporalEP = m_TemporalPredictor->getBlockEP();
	//zEuclideanPoint EstimatedEP = m_SpatialEP * m_weight + m_TemporalEP * (1.0 - m_weight);
	EstimatedEP = m_SpatialEP * m_weight + m_TemporalEP * (1.0 - m_weight);
	return EstimatedEP;
}
	
zEuclideanPoint zEPPredictor::getBlockEP ()
{
	return m_CurrEP;
}