#ifndef __ZTS_EP_H__
#define __ZTS_EP_H__

#include <math.h>

class zEuclideanPoint{
public:
	zEuclideanPoint () {EPy = 0; EPx = 0;}
	zEuclideanPoint (double y, double x)	{EPy = y; EPx = x;}
	~zEuclideanPoint () {;}
	void SetZero () {EPy = 0; EPx = 0;}
	bool IsZero () { return (EPy==0 && EPx==0);}
	void SetPartEP (unsigned int depth, unsigned int part);
	zEuclideanPoint operator + (const zEuclideanPoint &in)	{return zEuclideanPoint(EPy+in.EPy, EPx+in.EPx);}
	zEuclideanPoint & operator += (const zEuclideanPoint &in)	{EPy += in.EPy; EPx += in.EPx; return *this;}
	zEuclideanPoint operator - (const zEuclideanPoint &in)	{return zEuclideanPoint(EPy-in.EPy, EPx-in.EPx);}
	double operator * (const zEuclideanPoint &in)	{return (EPy*in.EPy+EPx*in.EPx);}
	zEuclideanPoint operator * (double in)	{return zEuclideanPoint(EPy*in, EPx*in);}
	zEuclideanPoint & operator *= (double in)	{EPy *= in; EPx *= in; return *this;} 
	zEuclideanPoint operator / (double in)	{return zEuclideanPoint(EPy/in, EPx/in);}
	zEuclideanPoint & operator /= (double in)	{EPy /= in; EPx /= in; return *this;} 
	zEuclideanPoint & operator = (const zEuclideanPoint &in)	{this->EPy = in.EPy; this->EPx = in.EPx; return *this;}
	double getDist (const zEuclideanPoint &in) {zEuclideanPoint diff(EPy-in.EPy, EPx-in.EPx); return sqrt(diff*diff);}
	// bool operator != (const zEuclideanPoint &in)	{return (EPy!=in.EPy || EPx!=in.EPx);}
	unsigned int getDepth(); 

private:
	double EPy;
	double EPx;
};


class zEPPredictor{
public:
	zEPPredictor();
	~zEPPredictor() {;}
	void setTemporalPredictor (zEPPredictor *TemporalPredictor);
	void setUpperPredictor (zEPPredictor *UpperPredictor);
	void setLeftPredictor (zEPPredictor *LeftPredictor);
	// if (!UpperPredictor && !LeftPredictor) m_weight = 0;
	void setBlockEP (zEuclideanPoint EP, bool UpdateWeight=true);
	// m_CurrEp = EP; update m_weight;
	zEuclideanPoint getEstimatedEP ();
	zEuclideanPoint getBlockEP ();
	double getPredictionError (zEuclideanPoint CurrEP) { return EstimatedEP.getDist(CurrEP);}

private:
	zEuclideanPoint m_SpatialEP, m_TemporalEP;
	zEuclideanPoint m_CurrEP;
	zEuclideanPoint EstimatedEP;
	double m_weight;
	double m_adaptfactor;
	zEPPredictor *m_UpperPredictor, *m_LeftPredictor;
	zEPPredictor *m_TemporalPredictor;
	bool m_UpperExist, m_LeftExist;
};

#endif __ZTS_EP_H__