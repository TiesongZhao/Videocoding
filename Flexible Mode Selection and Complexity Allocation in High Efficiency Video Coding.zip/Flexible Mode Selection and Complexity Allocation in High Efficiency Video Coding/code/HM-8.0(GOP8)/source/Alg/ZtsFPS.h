#ifndef __ZTS_FPS_H__
#define __ZTS_FPS_H__

#include "ZtsEP.h"
#include "stdio.h"

#define ZTS_ALG
#define ZTS_STAT

#ifdef ZTS_ALG
	#define IMG_LVL_CP_ALLOC	// complexity allocation in image level
//	#define CU_LVL_CP_ALLOC		// complexity allocation in CU level
//	#define PART_LVL_CP_ALLOC	// complexity allocation in Sub-CU/Partition level
#endif ZTS_ALG

class zImgFPS{
public:
	zImgFPS ();
	~zImgFPS ();
	void setImg (zImgFPS &TemporalImg, unsigned int ImgHeightInPels, unsigned int ImgWidthInPels);
	// set predictor; set upper/left predictor
	void setComplexFactor (double ImgComplexityFactor);

	void StartCU (unsigned int CUPelY, unsigned int CUPelX, unsigned int CUDepth);
	// TopLeftPel[depth][1,2] = CUPelY,X
	// if (0,0,0) FrameCnt++; 
	// if (FrameCnt>1) predict EstimatedCU, calculate partitions.

	bool IsPartSizeEnabled (int PartSize);
	bool IsIntraEnabled ();

	void setPartSize8x8 (unsigned int BlkPelY, unsigned int BlkPelX, unsigned int CUDepth, unsigned int Depth, unsigned int PartSize);

	void EndCU (unsigned int CUPelY, unsigned int CUPelX, unsigned int CUDepth);

private:
	void initEPPredictor (zEPPredictor ***EPPredictorMatPointer, zEPPredictor ***EPPredictorTemporalMatPointer, int height, int width);
	void predictCU (zEPPredictor *EPPredictorPointer, int CUDepth);

private:
	unsigned int m_ImgWidth, m_ImgHeight;
	unsigned int m_PredMatSize[4][2];
	zEPPredictor **m_EPPredictor64;
	zEPPredictor **m_EPPredictor32;
	zEPPredictor **m_EPPredictor16;
	zEPPredictor **m_EPPredictor8;
	double m_ImgComplexFactor;
	double m_CUComplexFactor;

	unsigned int m_FrameCnt;	// start from 1;
	bool m_PartEnabled[8];
#ifdef CU_LVL_CP_ALLOC
	double **m_PredictError;
	double m_AvePredictError;	
#endif CU_LVL_CP_ALLOC
	/*
#ifdef PART_LVL_CP_ALLOC
	double m_deltaCF[4][4];
#endif PART_LVL_CP_ALLOC
	*/
};

class zFlexiblePartitionSlection{
public:
	zFlexiblePartitionSlection ();
	~zFlexiblePartitionSlection ();
	void SetImgFPS (unsigned int NumPicDepths, unsigned int ImgHeightInPels, unsigned int ImgWidthInPels);
	void SetComplexFactor (double GobalComplexityFactor);
	void StartImg (unsigned int ImgDepth);
	void StartCU (unsigned int CUPelY, unsigned int CUPelX, unsigned int CUDepth);
	bool IsPartSizeEnabled (int PartSize);
	bool IsIntraEnabled ();
	void setPartSize8x8 (unsigned int BlkPelY, unsigned int BlkPelX, unsigned int CUDepth, unsigned int Depth, unsigned int PartSize);
	void EndCU (unsigned int CUPelY, unsigned int CUPelX, unsigned int CUDepth);

private:
	unsigned int m_NumPicDepths;
	zImgFPS *m_ImgFPS;
	unsigned int m_CurrImgDepth;
};

#ifdef ZTS_ALG
	extern zFlexiblePartitionSlection *MyAlg;
#endif ZTS_ALG

#ifdef ZTS_STAT
	extern int zts_seqno;
	extern int zts_qp;
	extern double zts_cmpfctr;
	extern double zts_time;
	extern double zts_psnr;
	extern double zts_br;
#endif ZTS_STAT

#endif __ZTS_FPS_H__