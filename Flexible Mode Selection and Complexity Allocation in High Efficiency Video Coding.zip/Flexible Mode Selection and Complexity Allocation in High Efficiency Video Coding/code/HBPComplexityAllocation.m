function [ ComplexityFactorList ] = HBPComplexityAllocation( GolobalComplexityFactor, GOPSize, RDCSlopeCoefficient )
% Input: GolobalComplexityFactor(1x1)
%        GOPSize(1x1): must be 2^x
%        RDCSlopeCoefficient(1x1), usually 0~0.5

if nargin < 3
    RDCSlopeCoefficient = 0.3;
    disp('HBPComplexityAllocation: nargin<3; set RDCSlopeCoefficient = 0.3');
    if nargin < 2
        GOPSize = 8;
        disp('HBPComplexityAllocation: nargin<2. set GOPSize = 8');
        if nargin < 1
            error('HBPComplexityAllocation: nargin<1.');
        end
    end
end
    
if GolobalComplexityFactor < 0 || GolobalComplexityFactor > 1
    error('HBPComplexityAllocation: GolobalComplexityFactor must be between 0 and 1');
end
if log2(GOPSize) ~= round(log2(GOPSize))
    error('HBPComplexityAllocation: GOPSize must be the power of 2');
end
if RDCSlopeCoefficient < 0 || RDCSlopeCoefficient > 0.5
    error('HBPComplexityAllocation: RDCSlopeCoefficient should be between 0 and 0.5');
end

N = log2(GOPSize)+1;
AlphaList = zeros(N, 1);
BetaList = zeros(N, 1);
AlphaList(1) = ((1+2*RDCSlopeCoefficient)^(N-1))/(1-RDCSlopeCoefficient);
BetaList(1) = 2^(1-N);
for k = 1 : N-1
    AlphaList(k+1) = (1+2*RDCSlopeCoefficient)^(N-1-k);
    BetaList(k+1) = 2^(k-N);
end

f = -AlphaList;
A = diag(diag(ones(N,N)));
b = ones(N,1);
Aeq = BetaList';
beq = GolobalComplexityFactor;
%lb = zeros(N,1);
lb = zeros(N,1) + GolobalComplexityFactor/2;
ub = ones(N,1);

x0 = zeros(N,1)+GolobalComplexityFactor;

options = optimset('LargeScale','off','Simplex','on');

ComplexityFactorList = linprog(f,A,b,Aeq,beq,lb,ub,x0, options);

end

