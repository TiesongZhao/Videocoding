#include "trans_matrix.h"


TransMatrix::TransMatrix()
{
}

TransMatrix::~TransMatrix()
{
}

//void TransMatrix::init(char TLayer)
void TransMatrix::init()
{
	//TemporalId = TLayer;
	FrameNo = -1;
	w_prob = 0.08;

	int __x, __y;
	for (__x=0; __x<6; __x++)
	{
		trans_long[__x] = 0.16667;
		for (__y=1; __y<7; __y++)
			trans_upper[__y-1][__x] = 0.16667;
		for (__y=7; __y<13; __y++)
			trans_left[__y-7][__x] = 0.16667;
		for (__y=13; __y<18; __y++)
			trans_base[__y-13][__x] = 0.16667;
	}
}

void TransMatrix::update(char mode_upper, char mode_left, char mode_base, double prob[__CAND_MODE_NUM])
{	
	int __x;
	for (__x=0; __x<__CAND_MODE_NUM; __x++)
	{
		trans_long[__x] *= (1-w_prob);
		trans_long[__x] += w_prob * prob[__x];
		if (mode_upper >=0)
		{
			trans_upper[mode_upper][__x] *= (1-w_prob);
			trans_upper[mode_upper][__x] += w_prob * prob[__x];
		}
		if (mode_left >=0)
		{
			trans_left[mode_left][__x] *= (1-w_prob);
			trans_left[mode_left][__x] += w_prob * prob[__x];
		}
		trans_base[mode_base-1][__x] *= (1-w_prob);
		trans_base[mode_base-1][__x] += w_prob * prob[__x];
	}
}

void TransMatrix::pred(char mode_upper, char mode_left, char mode_base, double prob_p[__CAND_MODE_NUM])
{
	if (mode_upper < 0 && mode_left < 0)
		FrameNo ++;

	int cand_mode;
	double __sum = 0;

	if (mode_upper >= 0 && mode_left >=0)
	{
		for (cand_mode=0; cand_mode<__CAND_MODE_NUM; cand_mode++)
		{
			prob_p[cand_mode] = trans_upper[mode_upper][cand_mode] + trans_left[mode_left][cand_mode];
			__sum += prob_p[cand_mode];
		}
	}
	else
	{				
		for (cand_mode=0; cand_mode<__CAND_MODE_NUM; cand_mode++)
		{
			prob_p[cand_mode] = (trans_long[cand_mode]  + trans_base[mode_base-1][cand_mode])/2;
			if (mode_upper >= 0)
			prob_p[cand_mode] += trans_upper[mode_upper][cand_mode];
			if (mode_left >= 0)
			prob_p[cand_mode] += trans_left[mode_left][cand_mode];
			__sum += prob_p[cand_mode];
		}		
	}
	for (cand_mode=0; cand_mode<__CAND_MODE_NUM; cand_mode++)
	{
		prob_p[cand_mode] /= __sum;
	}
}

bool TransMatrix::IsFirstFrame()
{
	return (FrameNo<=0);
}