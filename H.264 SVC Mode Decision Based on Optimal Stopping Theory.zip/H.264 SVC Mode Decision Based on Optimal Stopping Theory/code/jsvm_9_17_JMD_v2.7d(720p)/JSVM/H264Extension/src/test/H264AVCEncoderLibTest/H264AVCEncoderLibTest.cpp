
#include "H264AVCEncoderLibTest.h"
#include "H264AVCEncoderTest.h"
#include "H264AVCCommonLib/CommonBuffers.h"


int
main( int argc, char** argv)
{

#ifdef STAT_SONG
	{
	fp_stat=fopen("Proposedv27d1.txt","a");
	init_timer();
	start_timer(ENCODER);
	}
#endif STAT_SONG

  printf("JSVM %s Encoder\n\n",_JSVM_VERSION_);

  H264AVCEncoderTest*               pcH264AVCEncoderTest = NULL;
  RNOK( H264AVCEncoderTest::create( pcH264AVCEncoderTest ) );

#ifdef JOINT_FMD
  MyAlg=new FMDAlg;
#endif JOINT_FMD

  RNOKS( pcH264AVCEncoderTest->init   ( argc, argv ) );

  RNOK ( pcH264AVCEncoderTest->go     () );


  RNOK ( pcH264AVCEncoderTest->destroy() );

#ifdef STAT_SONG
	{
	stop_timer(ENCODER);
	fprintf(fp_stat,"%d\t%d\t%d\t%d\t%f\t%f\t%f\t%f\n",
		fileno_song_0,fileno_song_1,Qp_song_0, Qp_song_1,timer[ENCODER].overall_sum/freq,timer[MODE].overall_sum/freq, PSNR_song,Bitrates_song);
	fclose(fp_stat);
	}
#endif STAT_SONG
  return 0;
}
