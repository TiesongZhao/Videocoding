#include "timer_whl.h"

TIMER timer[TIMER_NUM];
double freq;

void init_timer()
{
	TIMER zero = {0,0,0,0,0};
	int i;
	for(i=0; i<TIMER_NUM; i++)
	{
		timer[i] = zero;
	}
	freq = get_cpu_freq(1);
}


string int2str(int &i)
{
	string s;
	stringstream ss(s);
	ss<<i;
	return ss.str();
}

/*

Reference Index for all modes:
set n=NumberReferenceFrames

For each sub-block of MODE_SKIP, MODE_16x16, MODE_16x8, MODE_8x16, MODE_8x8, MODE_8x8ref0:
    P_SLICE: 1..n for ref0, 0 for ref1
	B_SLICE: -1 or 1..n for ref0 & ref1, where -1 means the list is not used.
	         Of course, (-1, -1) is not allowed.
For each sub-block of INTRA_4x4, INTRA4x4+1...etc
    I_SLICE & P_SLICE: -1 for ref0, 0 for ref1
	B_SLICE: -1 for ref0, -1 for ref1

*/