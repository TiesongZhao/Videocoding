#ifndef _JMD_H_
#define _JMD_H_

#include "timer_whl.h"
#include "trans_matrix.h"

#define JOINT_FMD
#define STAT_SONG

class CandMode{
public:
	char mode;
	char state;
	double prob;
};

class FMDAlg{

public:

	// global
	FMDAlg();
	~FMDAlg();
	void InitTransMatrix(int MaxTemporalLayer);
	void SetEnhRatio(int H_Mb_BL, int H_Mb_EL);
	bool IsQualityScalability();

	// image level
	void SetTemporalLayer(int TemporalLayer);	// only for non-key frames

	// MB level
	void SetRefModes(char  M_u, char M_l, char M_bl);
	void InitCandModeList();	// probabilities prediction & sort
	void SetOptStopMode();	
	// method: 0, relatively-best choice problem;
	void SetSubModes();			// enable or disable sub inter-modes
	char GetModeInList();		// pop mode sequencially
	char GetListState();
	void SetSubModeOpt(bool enabeld);  // only when SubModeOpt=true, IsSubModeEnabled() is valid
	bool IsSubModeEnabled(char sub_mode);	
	void UpdateTransMatrix(char M_b);	// set best mode & update trans_matrix

	int GetSADThforAllZero4x4ResidualMode(int Qp);

private:
	
	int MaxTLayer;
	int m_er; 
	// int HeightInMb, WidthInMb;
	TransMatrix *TransMatrixLayer;

	int TLayerMinus1;

	char mode_upper,mode_left,mode_base;
	char best_mode;
	CandMode ModeList[__CAND_MODE_NUM];
	char curr_mode_idx;

	bool SubModeOpt;
	bool SubModeEnabled[4];

protected:

	char Mode2Num(char mode_in)
		//input: MODE_SKIP, MODE_16x16, etc.
		//output: index in TransMatrix, 0~5; -1: no exist
	{
		if(mode_in<4)	//skip, 16x16, 16x8, 8x16
			return mode_in;
		else if(mode_in<6)	//8x8
			return 4;
		else			// intra
			return 5;
	}
};
extern FMDAlg* MyAlg;
extern const double AllZeroThreshold4x4[52];


#ifdef STAT_SONG
	extern FILE *fp_stat;
	extern int fileno_song_0;
	extern int fileno_song_1;
	extern int Qp_song_0;
	extern int Qp_song_1;
	extern double PSNR_song;
	extern double Bitrates_song;
#endif STAT_SONG

#endif _JMD_H_