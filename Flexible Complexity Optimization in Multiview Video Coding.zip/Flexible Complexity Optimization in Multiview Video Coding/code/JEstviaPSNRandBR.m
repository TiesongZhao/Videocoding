function [ J ] = JEstviaPSNRandBR( Qp, PSNR, BR, PixPerSec)

dLambda = 0.85 * (2^((Qp-12)/3.0));
MSE = 255^2 / (10^(PSNR/10));
Bits = BR*1000/PixPerSec;

J = MSE + dLambda * Bits;

end

