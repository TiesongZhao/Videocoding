
theta_mat = zeros(19, 3, 4);
for k = 1 : 19
    F = ComplexityAllocation3Views(0.05 + k*0.05, 4, 0.5, 0.5);
    for i = 1 : 3
        for j =  1 : 4
            theta_mat(k,i,j) = F(i,j);
        end
    end
end
    

str1 = 'double theta_mat[19][3][4]={';
disp(str1);
for k = 1 : 19
    str1 = '{ ';
    for i = 1 : 3
        str1 = [str1, '{'];
        for j = 1 : 3
            str1 = [str1, num2str(theta_mat(k,i,j)), ', '];
        end
        if i ~= 3
            str1 = [str1, num2str(theta_mat(k,i,4)), '}, '];
        else
            if k ~= 19 
                str1 = [str1, num2str(theta_mat(k,3,4)), '} }, '];
            else
                str1 = [str1, num2str(theta_mat(k,3,4)), '} } };'];
            end
        end
    end
    disp(str1);
end


% latex_theta_mat = zeros(11, 12);
% for k = 1 : 11
%     F = ComplexityAllocation3Views(k*0.1-0.1, 4, 0.5, 0.5);
%     for i = 1 : 3
%         for j =  1 : 4
%             latex_theta_mat(k,(i-1)*4+j) = F(i,j);
%         end
%     end
% end
% for k = 1 : 11
%     str1 = mynum2str(k*0.1-0.1, 3);
%     for i =  1 : 12
%         str1 = [str1, ' & ', mynum2str(latex_theta_mat(k,i),3)];
%     end
%     str1 = [str1, ' \\'];
%     disp(str1);
% end

