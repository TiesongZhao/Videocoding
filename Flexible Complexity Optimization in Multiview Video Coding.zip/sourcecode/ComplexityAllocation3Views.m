function [ F ] = ComplexityAllocation3Views( Theta, N, epsilon_1, epsilon_2)

if nargin < 1
    error('ComplexityAllocation: nargin<1.');
elseif nargin < 2
    N = 4;
    epsilon_1 = 0.7;
    epsilon_2 = 0.3;
elseif nargin < 3
    epsilon_1 = 0.7;
    epsilon_2 = 0.3;
elseif nargin < 4
    epsilon_2 = 0.3;
end
        
if Theta < 0 || Theta > 1
    error('ComplexityAllocation: GolobalComplexityFactor must be between 0 and 1');
end
if N <= 0  || N~=round(N)
    error('ComplexityAllocation: K must be a positive integer');
end
if epsilon_1 <= 0 || epsilon_1 >= 1
    error('ComplexityAllocation: Inter-view error propagation must be between 0 and 1');
end
if epsilon_2 <= 0 || epsilon_2 >= 1
    error('ComplexityAllocation: Intra-view error propagation must be between 0 and 1');
end

K = 2;
alpha = [1+epsilon_1*2, 1];
beta = zeros(N,1);
gamma = zeros(K,N);
beta(1) = ((1+2*epsilon_2)^(N-1))/(1-epsilon_2);
for n = 1 : N-1
    beta(n+1) = (1+2*epsilon_2)^(N-1-n);
end
for k = 1 : K
    for n = 1 : N
        if k == 1
            gamma(k,n) = 1/3;
        else
            gamma(k,n) = 2/3;
        end
        if n == 1
            gamma(k,n) = gamma(k,n)/(2^(N-1));
        else
            gamma(k,n) = gamma(k,n)/(2^(N-n+1));
        end
    end
end

A = zeros(K, N);
B = zeros(K, N);

for k = 1 : K
    for n =  1 : N
        A(k,n) = - alpha(k)* beta(n)*gamma(k,n);
        B(k,n) = gamma(k,n);
    end
end

F = matlinprog(A, B, Theta);  

F(K+1,:) = F(K,:);
         

end

