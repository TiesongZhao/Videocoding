function [ X ] = matlinprog( Alpha, Beta, Theta )

% min {Alpha(:)'*X(:)}, s.t. Beta(:)'*X(:) = theta 

[M, N] = size(Alpha);
if size(Beta,1)~=M || size(Beta,2)~=N || size(Theta,2)>1
    X = 0;
    return;
end
K = M*N;

f = Alpha(:)';
A = diag(diag(ones(K,K)));
b = ones(K,1);
Aeq = Beta(:)';
beq = Theta;
lb = zeros(K,1) + Theta/2;
ub = ones(K,1);
% if Theta * 1.5 < 1
%     ub = ub * Theta * 1.5;
% end
x0 = zeros(K,1) + Theta;
options = optimset('LargeScale','off','Simplex','on');

x_list = linprog(f,A,b,Aeq,beq,lb,ub,x0, options);

X = zeros(M,N);
for m = 1 : M
    for n = 1 : N
        X(m,n) = x_list((n-1)*M+m);
    end
end

end

