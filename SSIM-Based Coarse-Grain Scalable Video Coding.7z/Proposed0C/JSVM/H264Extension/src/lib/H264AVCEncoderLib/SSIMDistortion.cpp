
#include "SSIMDistortion.h"

//H264AVC_NAMESPACE_BEGIN

#if defined SSIM_DISTORTION || defined SSIM_OUTPUT
xSSIMDistortion *z_SSIMDistortion;
#endif 

xSSIMDistortion::xSSIMDistortion(UInt ImgMaxHeightInPixels, UInt ImgMaxWidthInPixels)
{
	m_MaxLumaHeightInPixels = m_MaxChromaHeightInPixels = ImgMaxHeightInPixels;
	m_MaxLumaWidthInPixels = m_MaxChromaWidthInPixels = ImgMaxWidthInPixels;
	m_MaxChromaHeightInPixels >>= 1;
	m_MaxChromaWidthInPixels >>= 1;

	Allocate2DXPel(&m_OrgImgY, m_MaxLumaHeightInPixels, m_MaxLumaWidthInPixels);
	Allocate2DXPel(&m_RecImgY, m_MaxLumaHeightInPixels, m_MaxLumaWidthInPixels);
    Allocate2DXPel(&m_OrgImgCb, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DXPel(&m_RecImgCb, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DXPel(&m_OrgImgCr, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DXPel(&m_RecImgCr, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);

	Allocate2DInt32(&t_OrgY_NMu, m_MaxLumaHeightInPixels, m_MaxLumaWidthInPixels);
	Allocate2DInt32(&t_OrgY_NSigma_sq, m_MaxLumaHeightInPixels, m_MaxLumaWidthInPixels);
	Allocate2DInt32(&t_OrgCb_NMu, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DInt32(&t_OrgCb_NSigma_sq, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DInt32(&t_OrgCr_NMu, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DInt32(&t_OrgCr_NSigma_sq, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);

	Allocate2DInt32(&t_OrgY_sq, m_MaxLumaHeightInPixels, m_MaxLumaWidthInPixels);
	Allocate2DInt32(&t_RecY_sq, m_MaxLumaHeightInPixels, m_MaxLumaWidthInPixels);
	Allocate2DInt32(&t_CovY, m_MaxLumaHeightInPixels, m_MaxLumaWidthInPixels);
	Allocate2DInt32(&t_OrgCb_sq, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DInt32(&t_RecCb_sq, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DInt32(&t_CovCb, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DInt32(&t_OrgCr_sq, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DInt32(&t_RecCr_sq, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
	Allocate2DInt32(&t_CovCr, m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels);
}

void xSSIMDistortion::Allocate2DXPel(XPel ***mat, int height, int width)
{
	(*mat) = new XPel*[height];
	(*mat)[0] = new XPel[height*width];
	for (int j=1; j<height; j++)
	{
		(*mat)[j] = (*mat)[j-1] + width;
	}
}

void xSSIMDistortion::Allocate2DInt32(int ***mat, int height, int width)
{
	(*mat) = new int*[height];
	(*mat)[0] = new int[height*width];
	for (int j=1; j<height; j++)
	{
		(*mat)[j] = (*mat)[j-1] + width;
	}
}

xSSIMDistortion::~xSSIMDistortion()
{
	Delete2DXPel(&m_OrgImgY);
	Delete2DXPel(&m_RecImgY);
	Delete2DXPel(&m_OrgImgCb);
	Delete2DXPel(&m_RecImgCb);
	Delete2DXPel(&m_OrgImgCr);
	Delete2DXPel(&m_RecImgCr);

	Delete2DInt32(&t_OrgY_NMu);
	Delete2DInt32(&t_OrgY_NSigma_sq);
	Delete2DInt32(&t_OrgCb_NMu);
	Delete2DInt32(&t_OrgCb_NSigma_sq);
	Delete2DInt32(&t_OrgCr_NMu);
	Delete2DInt32(&t_OrgCr_NSigma_sq);

	Delete2DInt32(&t_OrgY_sq);
	Delete2DInt32(&t_RecY_sq);
	Delete2DInt32(&t_CovY);
	Delete2DInt32(&t_OrgCb_sq);
	Delete2DInt32(&t_RecCb_sq);
	Delete2DInt32(&t_CovCb);
	Delete2DInt32(&t_OrgCr_sq);
	Delete2DInt32(&t_RecCr_sq);
	Delete2DInt32(&t_CovCr);
}

void xSSIMDistortion::Delete2DXPel(XPel ***mat)
{
	delete((*mat)[0]);
	delete(*mat);
}

void xSSIMDistortion::Delete2DInt32(int ***mat)
{
	delete((*mat)[0]);
	delete(*mat);
}

void xSSIMDistortion::LoadOriginalImage(XPel *LumAddr, XPel *CbAddr, XPel *CrAddr, UInt LHeight, UInt LWidth, UInt LStride)
{
	m_ImgLumaHeight = m_ImgChromaHeight = LHeight;
	m_ImgLumaWidth = m_ImgChromaWidth = LWidth;
	m_ImgChromaHeight >>= 1;
	m_ImgChromaWidth >>= 1;

	// store original image
	UInt y, x;
	for (y=0; y<m_ImgLumaHeight; y++)
	{
		for (x=0; x<m_ImgLumaWidth; x++)
		{
			m_OrgImgY[y][x] = LumAddr[x];
			t_OrgY_sq[y][x] = LumAddr[x]*LumAddr[x];
		}
		LumAddr += LStride;
	}
	LStride >>= 1;
	for (y=0; y<m_ImgChromaHeight; y++)
	{
		for (x=0; x<m_ImgChromaWidth; x++)
		{
			m_OrgImgCb[y][x] = CbAddr[x];
			m_OrgImgCr[y][x] = CrAddr[x];
			t_OrgCb_sq[y][x] = CbAddr[x]*CbAddr[x];
			t_OrgCr_sq[y][x] = CrAddr[x]*CrAddr[x];
		}
		CbAddr += LStride;
		CrAddr += LStride;
	}

	// compute original mu & sigma
	UInt j, i;
	int *NMu_p, *NSigmasq_p, *NMu2_p, *NSigmasq2_p;
	for (y=0; y<m_ImgLumaHeight-3; y++)
	{
		for (x=0; x<m_ImgLumaWidth-3; x++)
		{
			NMu_p = & (t_OrgY_NMu[y][x]);
			NSigmasq_p = & (t_OrgY_NSigma_sq[y][x]);
			*NMu_p = 0;
			*NSigmasq_p = 0;
			for (j=y; j<y+4; j++)
			{
				for (i=x; i<x+4; i++)
				{
					*NMu_p += m_OrgImgY[j][i];
					*NSigmasq_p += t_OrgY_sq[j][i];
				}
			}
			*NSigmasq_p <<= 4;
			*NSigmasq_p -= (*NMu_p)*(*NMu_p);
		}
	}
	for (y=0; y<m_ImgChromaHeight-3; y++)
	{
		for (x=0; x< m_ImgChromaWidth-3; x++)
		{
			NMu_p = &(t_OrgCb_NMu[y][x]);
			NSigmasq_p = &(t_OrgCb_NSigma_sq[y][x]);
			NMu2_p = &(t_OrgCr_NMu[y][x]);
			NSigmasq2_p = &(t_OrgCr_NSigma_sq[y][x]);
			*NMu_p = 0;
			*NSigmasq_p = 0;
			*NMu2_p = 0;
			*NSigmasq2_p = 0;
			for (j=y; j<y+4; j++)
			{
				for (i=x; i<x+4; i++)
				{
					*NMu_p += m_OrgImgCb[j][i];
					*NSigmasq_p += t_OrgCb_sq[j][i];
					*NMu2_p += m_OrgImgCr[j][i];
					*NSigmasq2_p += t_OrgCr_sq[j][i];
				}
			}
			*NSigmasq_p <<= 4;
			*NSigmasq_p -= (*NMu_p)*(*NMu_p);
			*NSigmasq2_p <<= 4;
			*NSigmasq2_p -= (*NMu2_p)*(*NMu2_p);			
		}
	}
}

void xSSIMDistortion::ComputeRecPara(XPel **OrgImg, XPel **RecImg, int **Rec_sq, int **CovImg, UInt ImageWidth, 
		XPel *RecAddr, UInt iStride, UInt topleft_y, UInt topleft_x, UInt size_y, UInt size_x)
{
	UInt y, x;
	XPel *OrgImg_py, *OrgImg_px, *RecImg_py, *RecImg_px, *RecAddr_px;
	int *Rec_sq_py, *Rec_sq_px, *Cov_py, *Cov_px;
	OrgImg_py = OrgImg[topleft_y] + topleft_x;
	RecImg_py = RecImg[topleft_y] + topleft_x;
	Rec_sq_py = Rec_sq[topleft_y] + topleft_x;
	Cov_py = CovImg[topleft_y] + topleft_x;
	for (y=0; y<size_y; y++)
	{
		OrgImg_px = OrgImg_py;		
		RecImg_px = RecImg_py;		
		Rec_sq_px = Rec_sq_py;		
		Cov_px = Cov_py;		
		RecAddr_px = RecAddr;
		
		for (x=0; x<size_x; x++)
		{
			*RecImg_px = *RecAddr_px;
			*Rec_sq_px = (*RecAddr_px) * (*RecAddr_px);
			*Cov_px = (*OrgImg_px) * (*RecAddr_px);
			OrgImg_px++;
			RecImg_px++;
			Rec_sq_px++;
			Cov_px++;			
			RecAddr_px++;
		}

		OrgImg_py += ImageWidth;
		RecImg_py += ImageWidth;
		Rec_sq_py += ImageWidth;
		Cov_py += ImageWidth;
		RecAddr += iStride;
	}
}

UInt xSSIMDistortion::GetDistLum16x16(XPel *RecLumAddr, UInt LStride, UInt topleft_pix_y, UInt topleft_pix_x)
{
	ComputeRecPara(m_OrgImgY, m_RecImgY, t_RecY_sq, t_CovY, m_MaxLumaWidthInPixels,
		RecLumAddr, LStride, topleft_pix_y, topleft_pix_x, 16, 16);
#ifndef SHIQI_SSIM
	Double BlockSSIM = ComputeSSIM(t_OrgY_NMu, t_OrgY_NSigma_sq, m_RecImgY, t_RecY_sq, t_CovY, 
		topleft_pix_y != 0 ? topleft_pix_y-1 : 0, topleft_pix_y + 13, 
		topleft_pix_x != 0 ? topleft_pix_x-1 : 0, topleft_pix_x + 13,
		m_MaxLumaWidthInPixels);
#else
	Double BlockSSIM;
	if (topleft_pix_y==0 || topleft_pix_y + 16 == m_ImgLumaHeight || topleft_pix_x == 0 || topleft_pix_x + 16 == m_ImgLumaWidth)
	{
		BlockSSIM = 0;
		for (UInt j = topleft_pix_y; j < topleft_pix_y + 16; j += 4)
		{
			for (UInt i = topleft_pix_x; i < topleft_pix_x + 16; i += 4)
			{
				BlockSSIM += ComputeSSIM(m_OrgImgY,t_OrgY_NMu, t_OrgY_NSigma_sq, m_RecImgY, t_RecY_sq, t_CovY, j, j+1, i, i+1, m_MaxLumaWidthInPixels);
			}
		}
		BlockSSIM /= 16.0;
	}
	else
	{
		for (UInt j = topleft_pix_y-3; j<= topleft_pix_y+18; j++)
		{
			for (UInt i = topleft_pix_x-3; i<= topleft_pix_x+18; i++)
			{
				if (j>=topleft_pix_y && j<topleft_pix_y+16 && i>=topleft_pix_x && i<topleft_pix_x+16)
					continue;
				m_RecImgY[j][i] = m_OrgImgY[j][i];
				t_RecY_sq[j][i] = t_CovY[j][i] = t_OrgY_sq[j][i];
			}
		}
		BlockSSIM = ComputeSSIM(m_OrgImgY,t_OrgY_NMu, t_OrgY_NSigma_sq, m_RecImgY, t_RecY_sq, t_CovY, 
			topleft_pix_y-3, topleft_pix_y+16, topleft_pix_x-3, topleft_pix_x+16, m_MaxLumaWidthInPixels);
	}	
#endif SHIQI_SSIM
	return UInt(floor(SSIMDIST_EXT*256*(1-BlockSSIM)));
}

UInt xSSIMDistortion::GetDistLum8x8(XPel *RecLumAddr, UInt LStride, UInt topleft_pix_y, UInt topleft_pix_x)
{
	ComputeRecPara(m_OrgImgY, m_RecImgY, t_RecY_sq, t_CovY, m_MaxLumaWidthInPixels,
		RecLumAddr, LStride, topleft_pix_y, topleft_pix_x, 8, 8);
#ifndef SHIQI_SSIM
	Double BlockSSIM = ComputeSSIM(t_OrgY_NMu, t_OrgY_NSigma_sq, m_RecImgY, t_RecY_sq, t_CovY, 
		topleft_pix_y != 0 ? topleft_pix_y-1 : 0, topleft_pix_y + 5, 
		topleft_pix_x != 0 ? topleft_pix_x-1 : 0, topleft_pix_x + 5,
		m_MaxLumaWidthInPixels);
#else
	Double BlockSSIM = 0;
	for (UInt j = topleft_pix_y; j < topleft_pix_y + 8; j += 4)
	{
		for (UInt i = topleft_pix_x; i < topleft_pix_x + 8; i += 4)
		{
			BlockSSIM += ComputeSSIM(m_OrgImgY, t_OrgY_NMu, t_OrgY_NSigma_sq, m_RecImgY, t_RecY_sq, t_CovY, j, j+1, i, i+1, m_MaxLumaWidthInPixels);
		}
	}
	BlockSSIM /= 4.0;
#endif SHIQI_SSIM
	return UInt(floor(SSIMDIST_EXT*64*(1-BlockSSIM)));
}

#ifdef INTRA_MODE_DIST
UInt xSSIMDistortion::GetDistLum4x4(XPel *RecLumAddr, UInt LStride, UInt topleft_pix_y, UInt topleft_pix_x)
	// with luma clip, may be 0 points calculated!
	// still use 4x4 window
{
	UInt y, x;
	int N_MuA = 0, N_MuB = 0;
	int N_SigmaA_sq = 0, N_SigmaB_sq = 0, Nsq_SigmaAB = 0;
	for (y=topleft_pix_y; y<topleft_pix_y+4; y++)
	{
		for (x=topleft_pix_x; x<topleft_pix_x+4; x++)
		{
			N_MuA += m_OrgImgY[y][x];
			N_SigmaA_sq += t_OrgY_sq[y][x];
			N_MuB += RecLumAddr[x];
			N_SigmaB_sq += RecLumAddr[x]*RecLumAddr[x];
			Nsq_SigmaAB += RecLumAddr[x]*m_OrgImgY[y][x];
		}
		RecLumAddr += LStride;
	}
	
	int N_MuA_sq = N_MuA * N_MuA;
	int N_MuB_sq = N_MuB * N_MuB;
	int Nsq_MuA_MuB = N_MuA* N_MuB;
	N_SigmaA_sq <<= 4;
	N_SigmaA_sq -= N_MuA_sq;
	N_SigmaB_sq <<= 4;
	N_SigmaB_sq -= N_MuB_sq;
	Nsq_SigmaAB <<= 4;
	Nsq_SigmaAB -= Nsq_MuA_MuB;
	
	Double BlockSSIM = ((Nsq_MuA_MuB<<1) + N_SQ_C1) / (N_MuA_sq + N_MuB_sq + N_SQ_C1);
	BlockSSIM *= ((Nsq_SigmaAB<<1) + N_SQ_C2);
	BlockSSIM /= (N_SigmaA_sq + N_SigmaB_sq + N_SQ_C2);
	return UInt(floor(SSIMDIST_EXT*16*(1-BlockSSIM)));
}
#endif INTRA_MODE_DIST

UInt xSSIMDistortion::GetDistCb8x8(XPel *RecCbAddr, UInt CStride, UInt topleft_pix_y, UInt topleft_pix_x)
{
	ComputeRecPara(m_OrgImgCb, m_RecImgCb, t_RecCb_sq, t_CovCb, m_MaxChromaWidthInPixels,
		RecCbAddr, CStride, topleft_pix_y, topleft_pix_x, 8, 8);
#ifndef SHIQI_SSIM
	Double BlockSSIM = ComputeSSIM(t_OrgCb_NMu, t_OrgCb_NSigma_sq, m_RecImgCb, t_RecCb_sq, t_CovCb,
		topleft_pix_y != 0 ? topleft_pix_y-1 : 0, topleft_pix_y + 5, 
		topleft_pix_x != 0 ? topleft_pix_x-1 : 0, topleft_pix_x + 5,
		m_MaxChromaWidthInPixels);
#else
	Double BlockSSIM;
	if (topleft_pix_y==0 || topleft_pix_y + 8 == m_ImgChromaHeight || topleft_pix_x == 0 || topleft_pix_x + 8 == m_ImgChromaWidth)
	{
		BlockSSIM = 0;
		for (UInt j = topleft_pix_y; j < topleft_pix_y + 8; j += 4)
		{
			for (UInt i = topleft_pix_x; i < topleft_pix_x + 8; i += 4)
			{
				BlockSSIM += ComputeSSIM(m_OrgImgCb,t_OrgCb_NMu, t_OrgCb_NSigma_sq, m_RecImgCb, t_RecCb_sq, t_CovCb, j, j+1, i, i+1, m_MaxChromaWidthInPixels);
			}
		}
		BlockSSIM /= 4.0;
	}
	else
	{
		for (UInt j = topleft_pix_y-3; j<= topleft_pix_y+10; j++)
		{
			for (UInt i = topleft_pix_x-3; i<= topleft_pix_x+10; i++)
			{
				if (j>=topleft_pix_y && j<topleft_pix_y+8 && i>=topleft_pix_x && i<topleft_pix_x+8)
					continue;
				m_RecImgCb[j][i] = m_OrgImgCb[j][i];
				t_RecCb_sq[j][i] = t_CovCb[j][i] = t_OrgCb_sq[j][i];
			}
		}
		BlockSSIM = ComputeSSIM(m_OrgImgCb, t_OrgCb_NMu, t_OrgCb_NSigma_sq, m_RecImgCb, t_RecCb_sq, t_CovCb, 
			topleft_pix_y-3, topleft_pix_y+8, topleft_pix_x-3, topleft_pix_x+8, m_MaxChromaWidthInPixels);
	}
#endif SHIQI_SSIM
	return UInt(floor(SSIMDIST_EXT*64*(1-BlockSSIM)));
}

UInt xSSIMDistortion::GetDistCr8x8(XPel *RecCrAddr, UInt CStride, UInt topleft_pix_y, UInt topleft_pix_x)
{
	ComputeRecPara(m_OrgImgCr, m_RecImgCr, t_RecCr_sq, t_CovCr, m_MaxChromaWidthInPixels,
		RecCrAddr, CStride, topleft_pix_y, topleft_pix_x, 8, 8);
#ifndef SHIQI_SSIM
	Double BlockSSIM = ComputeSSIM(t_OrgCr_NMu, t_OrgCr_NSigma_sq, m_RecImgCr, t_RecCr_sq, t_CovCr,
		topleft_pix_y != 0 ? topleft_pix_y-1 : 0, topleft_pix_y + 5, 
		topleft_pix_x != 0 ? topleft_pix_x-1 : 0, topleft_pix_x + 5,
		m_MaxChromaWidthInPixels);
#else
	Double BlockSSIM;
	if (topleft_pix_y==0 || topleft_pix_y + 8 == m_ImgChromaHeight || topleft_pix_x == 0 || topleft_pix_x + 8 == m_ImgChromaWidth)
	{
		BlockSSIM = 0;
		for (UInt j = topleft_pix_y; j < topleft_pix_y + 8; j += 4)
		{
			for (UInt i = topleft_pix_x; i < topleft_pix_x + 8; i += 4)
			{
				BlockSSIM += ComputeSSIM(m_OrgImgCr,t_OrgCr_NMu, t_OrgCr_NSigma_sq, m_RecImgCr, t_RecCr_sq, t_CovCr, j, j+1, i, i+1, m_MaxChromaWidthInPixels);
			}
		}
		BlockSSIM /= 4.0;
	}
	else
	{
		for (UInt j = topleft_pix_y-3; j<= topleft_pix_y+10; j++)
		{
			for (UInt i = topleft_pix_x-3; i<= topleft_pix_x+10; i++)
			{
				if (j>=topleft_pix_y && j<topleft_pix_y+8 && i>=topleft_pix_x && i<topleft_pix_x+8)
					continue;
				m_RecImgCr[j][i] = m_OrgImgCr[j][i];
				t_RecCr_sq[j][i] = t_CovCr[j][i] = t_OrgCr_sq[j][i];
			}
		}
		BlockSSIM = ComputeSSIM(m_OrgImgCr,t_OrgCr_NMu, t_OrgCr_NSigma_sq, m_RecImgCr, t_RecCr_sq, t_CovCr, 
			topleft_pix_y-3, topleft_pix_y+8, topleft_pix_x-3, topleft_pix_x+8, m_MaxChromaWidthInPixels);
	}
#endif SHIQI_SSIM

	return UInt(floor(SSIMDIST_EXT*64*(1-BlockSSIM)));
}	

Double xSSIMDistortion::GetImageLumSSIM(XPel *RecLumAddr, UInt LStride)
{
	ComputeRecPara(m_OrgImgY, m_RecImgY, t_RecY_sq, t_CovY, m_MaxLumaWidthInPixels,
		RecLumAddr, LStride, 0, 0, m_ImgLumaHeight, m_ImgLumaWidth);
#ifndef SHIQI_SSIM
	Double YSSIM = ComputeSSIM(t_OrgY_NMu, t_OrgY_NSigma_sq, m_RecImgY, t_RecY_sq, t_CovY, 
		0, m_ImgLumaHeight-3, 0, m_ImgLumaWidth-3, m_MaxLumaWidthInPixels);
#else
	Double YSSIM = 0;
	for (UInt j = 0; j < m_ImgLumaHeight; j += 4)
	{
		for (UInt i = 0; i < m_ImgLumaWidth; i += 4)
		{
			YSSIM += ComputeSSIM(m_OrgImgY,t_OrgY_NMu, t_OrgY_NSigma_sq, m_RecImgY, t_RecY_sq, t_CovY, j, j+1, i, i+1, m_MaxLumaWidthInPixels);
		}
	}
	YSSIM /= (m_ImgLumaHeight*m_ImgLumaWidth/16);
#endif SHIQI_SSIM
	return YSSIM;
}

Double xSSIMDistortion::GetImageCbSSIM(XPel *RecCbAddr, UInt CStride)
{
	ComputeRecPara(m_OrgImgCb, m_RecImgCb, t_RecCb_sq, t_CovCb, m_MaxChromaWidthInPixels,
		RecCbAddr, CStride, 0, 0, m_ImgChromaHeight, m_ImgChromaWidth);
#ifndef SHIQI_SSIM
	Double USSIM = ComputeSSIM(t_OrgCb_NMu, t_OrgCb_NSigma_sq, m_RecImgCb, t_RecCb_sq, t_CovCb, 
		0, m_ImgChromaHeight-3, 0, m_ImgChromaWidth-3, m_MaxChromaWidthInPixels);
#else
	Double USSIM = 0;
	for (UInt j = 0; j < m_ImgChromaHeight; j += 4)
	{
		for (UInt i = 0; i < m_ImgChromaWidth; i += 4)
		{
			USSIM += ComputeSSIM(m_OrgImgCb, t_OrgCb_NMu, t_OrgCb_NSigma_sq, m_RecImgCb, t_RecCb_sq, t_CovCb, j, j+1, i, i+1, m_MaxChromaWidthInPixels);
		}
	}
	USSIM /= (m_ImgChromaHeight*m_ImgChromaWidth/16);
#endif SHIQI_SSIM
	return USSIM;
}

Double xSSIMDistortion::GetImageCrSSIM(XPel *RecCrAddr, UInt CStride)
{
	ComputeRecPara(m_OrgImgCr, m_RecImgCr, t_RecCr_sq, t_CovCr, m_MaxChromaWidthInPixels,
		RecCrAddr, CStride, 0, 0, m_ImgChromaHeight, m_ImgChromaWidth);
#ifndef SHIQI_SSIM
	Double VSSIM = ComputeSSIM(t_OrgCr_NMu, t_OrgCr_NSigma_sq, m_RecImgCr, t_RecCr_sq, t_CovCr, 
		0, m_ImgChromaHeight-3, 0, m_ImgChromaWidth-3, m_MaxChromaWidthInPixels);
#else
	Double VSSIM = 0;
	for (UInt j = 0; j < m_ImgChromaHeight; j += 4)
	{
		for (UInt i = 0; i < m_ImgChromaWidth; i += 4)
		{
			VSSIM += ComputeSSIM(m_OrgImgCr, t_OrgCr_NMu, t_OrgCr_NSigma_sq, m_RecImgCr, t_RecCr_sq, t_CovCr, j, j+1, i, i+1, m_MaxChromaWidthInPixels);
		}
	}
	VSSIM /= (m_ImgChromaHeight*m_ImgChromaWidth/16);
#endif SHIQI_SSIM
	return VSSIM;
}

Double xSSIMDistortion::ComputeSSIM(XPel **OrgImg, 
									int **Org_NMu,
									int **Org_NSigma_sq, 
									XPel **RecImg, 
									int **Rec_sq, 
									int **CovImg, 
									UInt y_min, 
									UInt y_max_plus1, 
									UInt x_min, 
									UInt x_max_plus1,
									UInt ImageWidth)
{
	UInt y, x, j, i;
	Double MSSIM, PixelSSIM;
	MSSIM = 0;
	int N_MuA, N_MuB, N_MuA_sq, N_MuB_sq, Nsq_MuA_MuB;
	int N_SigmaA_sq, N_SigmaB_sq, Nsq_SigmaAB;

	float aaa, bbb;
	XPel *RecImg_py, *RecImg_px;
	int *Org_NMu_py, *Org_NSigma_sq_py, *Rec_sq_py, *CovImg_py;
	int *Org_NMu_px, *Org_NSigma_sq_px, *Rec_sq_px, *CovImg_px;
	Org_NMu_py = Org_NMu[y_min] + x_min;
	Org_NSigma_sq_py = Org_NSigma_sq[y_min] + x_min;
	for (y=y_min; y<y_max_plus1; y++)
	{
		Org_NMu_px = Org_NMu_py;
		Org_NSigma_sq_px = Org_NSigma_sq_py;
		Org_NMu_py += ImageWidth;
		Org_NSigma_sq_py += ImageWidth;
		
		for (x=x_min; x<x_max_plus1; x++)
		{
			PixelSSIM = 0;
			N_MuA = *Org_NMu_px++;
			N_MuA_sq = N_MuA * N_MuA;
			N_SigmaA_sq = *Org_NSigma_sq_px++;

			N_MuB = N_SigmaB_sq = Nsq_SigmaAB = 0;
			RecImg_py = RecImg[y] + x;
			Rec_sq_py = Rec_sq[y] + x;
			CovImg_py = CovImg[y] + x;
			for (j=0; j<4; j++)
			{
				RecImg_px = RecImg_py;
				Rec_sq_px = Rec_sq_py;
				CovImg_px = CovImg_py;
				for (i=0; i<4; i++)
				{
					N_MuB += *RecImg_px++;
					N_SigmaB_sq += *Rec_sq_px++;
					Nsq_SigmaAB += *CovImg_px++;
				}
				RecImg_py += ImageWidth;
				Rec_sq_py += ImageWidth;
				CovImg_py += ImageWidth;
			}

			N_MuB_sq = N_MuB * N_MuB;
			Nsq_MuA_MuB = N_MuA * N_MuB;
			N_SigmaB_sq <<= 4;
			N_SigmaB_sq -= N_MuB_sq;
			Nsq_SigmaAB <<= 4;
			Nsq_SigmaAB -= Nsq_MuA_MuB;

			aaa = float(((Nsq_MuA_MuB<<1) + N_SQ_C1) / (N_MuA_sq + N_MuB_sq + N_SQ_C1));
			bbb = float(((Nsq_SigmaAB<<1) + N_SQ_C2) / (N_SigmaA_sq + N_SigmaB_sq + N_SQ_C2));
			PixelSSIM = aaa * bbb;

			MSSIM += PixelSSIM;
		}
	}
	MSSIM /= ((y_max_plus1-y_min) * (x_max_plus1-x_min));
	return MSSIM;
}

void xSSIMDistortion::SetLambda(Double lambda)
{
	m_dLambda = lambda;
}

Double xSSIMDistortion::GetRDCost(UInt uiBits, UInt Dist)
{
	UInt cost = UInt(floor(Dist + m_dLambda * uiBits + 0.5));
	return (Double)cost;
}

#ifdef INTRA_MODE_DIST
Double xSSIMDistortion::GetFRDCost(UInt uiBits, UInt Dist)
{
	Double cost = Dist + m_dLambda * uiBits;
	return cost;
}
#endif INTRA_MODE_DIST

//H264AVC_NAMESPACE_END
