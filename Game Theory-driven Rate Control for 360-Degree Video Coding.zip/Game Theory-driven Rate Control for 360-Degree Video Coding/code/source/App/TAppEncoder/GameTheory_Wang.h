#pragma once
/*!
  *@file   GameTheory_Wang.h
  *@brief  reproduce the paper "Applying Game Theory to Rate Control Optimization for Hierarchical B-Pictures"
  *@author Lin jielian
  *@date   2021/01/01
  */

#define Wang
#define Wang_Debug
class GameTheory_Wang
{
public:
	GameTheory_Wang();
	~GameTheory_Wang();
	void init_parameter(void);
	void init_mse(int nband);
	double QP2Qstep(int iQP);
	double level_weight(int level);
	bool m_frame_isFirstGop;
//private:

	//general rate contron info
	double m_frame_BitRate;
	double m_frame_FrameRate;
	int m_frame_GOPSize;
	int m_frame_MaxLevel;
	int m_frame_initQp;

	int m_frame_RemainBits;

	double m_frame_m_HeaderBits;
	double m_frame_m_HeaderCount[5];//w.x.


	int m_frame_GOPNumb;
	//number of coded frame in every layer
	int m_frame_CodeNum[5];  //encode frame num in every layer
	int m_frame_Ni[5];//non-encode frame num in every layer
	bool m_frame_FirstFrame[5];

	//Qp and Qstep for every layer
	double m_frame_Qstep[5];
	int m_frame_iQc[5]; //QP current
	int m_frame_iPrevQc[5];//QP Previous
	int m_frame_tempgopremain;

	//R-Q model parameter
	double m_frame_kList[5];	//init Kappa parameter  row: level col: the nth frame in layer
	float m_frame_R[5];
	double m_frame_rcount[5];
	double m_frame_kcount[5];
	float m_frame_dPRgQp_R[5][21];
	float m_frame_dQstep_R[5][21];
	float m_frame_dPRgRp[5][21];
	float m_frame_dR[5][21];

	int m_frame_iWindowSize_R;

	//D-Q model parameter
	double m_frame_rList[5];	//init Gamma parameter  row: level col: the nth frame in layer
	double m_frame_eList[5]; //init distortion of  row: level col: the nth frame in layer
	double m_frame_ecount[5]; //the num of encoded frame in every layer
	double m_frame_d[5];
	float m_frame_dPRgQp_D[5][21];
	float m_frame_dQstep_D[5][21];
	float m_frame_dPRgDist[5][21];
	float m_frame_dD[5][21];
	int m_frame_iWindowSize_D;


	double m_frame_vs[5][600];
	double m_frame_vt[5][600];
	double m_frame_u[5][600];
	double m_frame_wl;
	double m_frame_wo;
	double m_frame_ws;
	double m_frame_alpaL;
	int m_frame_w_index[5];


	double m_frame_hList[5];	//init headerbits of  row: level col: the nth frame in layer
	double m_frame_MADList[5];	//init MAD  
	double m_frame_previousMADList[5];	//init previous MAD  


	double m_frame_Xi;  //the parament of Xi in paper
	double m_frame_c_unity;
	int m_frame_level;
	double m_frame_BudgetBit;
	double m_frame_alpa_para;
	double m_frame_m_para;
	double m_frame_k_para;
	double m_frame_r_para;
	double m_frame_e_para;
};

#ifdef Wang
extern GameTheory_Wang *WangGT;
#endif