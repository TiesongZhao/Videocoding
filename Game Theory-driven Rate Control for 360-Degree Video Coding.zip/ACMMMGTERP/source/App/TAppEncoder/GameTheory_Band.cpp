#include "GameTheory_Band.h"
#include <stdio.h>
#include <iostream>
using namespace std;
/*!
  *@file   GameTheory_Band.cpp
  *@brief  proposed the Game theory for frame in band
  *@author Lin jielian
  *@date   2021/01/05
  */
#ifdef Band
GameTheory_Band *BandGT;
#endif

GameTheory_Band::GameTheory_Band()
{

}


GameTheory_Band::~GameTheory_Band()
{
}
void GameTheory_Band::init_Band()
{
	m_band_Num = 0;
	m_band_VideoWidth = 0;
	m_band_VideoHeight = 0;
	m_band_FrameLeftbit = 0;
	m_band_FrameStorebit = 0;
	m_band_w_para = 0.9;
	m_band_m_para = 0.9;
	m_band_k_para = 0.9;
	m_band_r_para = 0.8;
	m_band_bitleft = 0;
	m_band_kexi = 0.4;
	//double m_band_m_para;
	//m_band_k_para;
	//m_band_r_para;
	m_band_theta_unity = 0.5;
	for (int i = 0; i < 32; i++)
	{

		m_band_targetbit[i] = 0;

		m_band_SSDList[i] = 0;
		m_band_SADList[i] = 0;
		m_band_LastTimeSSDTemp[i] = 0;
		m_band_LastTimeSADTemp[i] = 0;
		m_band_TempDisagreement[i] = 0;
		m_band_YLCUValue[i] = i * 64 + 63;

		m_band_weight[i] = 0;
		m_band_estimateqp[i] = 0;
		m_band_BUweighted[i] = 0;
		m_band_estimateLambda[i] = 0;
	}
	for (int j = 0; j < 5; j++)
	{
		for (int i = 0; i < 32; i++)
		{
			m_band_kList[j][i] = 0;
			m_band_R[j][i] = 0;
			m_band_rList[j][i] = 0;
			m_band_eList[j][i] = 0;
			m_band_ecount[j][i] = 0;
			m_band_MADList[j][i] = 0;
			m_band_PreviousQP[j][i] = 0;
			m_band_PreviousQPCount[j][i] = 0;
			m_band_previousMADList[j][i] = 0;
			m_band_FirstFrame[j][i] = true;
			m_band_rcount[j][i] = 0;
			m_band_kcount[j][i] = 0;
		}
	}

	m_band_disagreementMinimum = 0;
	m_band_TempMiddleFormula = 0;
	m_band_isPOC0 = true;
}
void GameTheory_Band::init_Band_parameter(int N_Band)
{
	for (int i = 0; i < N_Band; i++)
	{
		m_band_eList[4][i] = 192.55303 / N_Band;
	}
	for (int i = 0; i < N_Band; i++)
	{
		m_band_eList[3][i] = 201.1277955 / N_Band;
	}
	for (int i = 0; i < N_Band; i++)
	{
		m_band_eList[2][i] = 203.4182028 / N_Band;
	}
	for (int i = 0; i < N_Band; i++)
	{
		m_band_eList[1][i] = 181.7097372 / N_Band;
	}
	for (int i = 0; i < N_Band; i++)
	{
		m_band_eList[0][i] = 167.8204212 / N_Band;
	}
	//if (N_Band==26)
	//{
	//	for (int i = 0; i < N_Band; i++)
	//	{
	//		m_band_eList[4][i] = 217.6294687/ N_Band;
	//	}
	//	for (int i = 0; i < N_Band; i++)
	//	{
	//		m_band_eList[3][i] = 229.7638067/ N_Band;
	//	}
	//	for (int i = 0; i < N_Band; i++)
	//	{
	//		m_band_eList[2][i] = 233.335638/ N_Band;
	//	}
	//	for (int i = 0; i < N_Band; i++)
	//	{
	//		m_band_eList[1][i] = 203.3512309/ N_Band;
	//	}
	//	for (int i = 0; i < N_Band; i++)
	//	{
	//		m_band_eList[0][i] = 177.2336928/ N_Band;
	//	}
	//} 
	//if (N_Band == 32)
	//{
	//	for (int i = 0; i < N_Band; i++)
	//	{
	//		m_band_eList[4][i] = 161.5449068/ N_Band;
	//	}
	//	for (int i = 0; i < N_Band; i++)
	//	{
	//		m_band_eList[3][i] = 167.2820748/ N_Band;
	//	}
	//	for (int i = 0; i < N_Band; i++)
	//	{
	//		m_band_eList[2][i] = 183.4732459/ N_Band;
	//	}
	//	for (int i = 0; i < N_Band; i++)
	//	{
	//		m_band_eList[1][i] = 182.0371214/ N_Band;
	//	}
	//	for (int i = 0; i < N_Band; i++)
	//	{
	//		m_band_eList[0][i] = 175.8354042/ N_Band;
	//	}
	//}

	//for (int i = 0; i < N_Band; i++)
	//{
	//	m_band_eList[4][i] = 191.7453/N_Band;
	//}
	//for (int i = 0; i < N_Band; i++)
	//{
	//	m_band_eList[3][i] = 200.4345 / N_Band;
	//}
	//for (int i = 0; i < N_Band; i++)
	//{
	//	m_band_eList[2][i] = 203.4182 / N_Band;
	//}
	//for (int i = 0; i < N_Band; i++)
	//{
	//	m_band_eList[1][i] = 181.7097 / N_Band;
	//}
	//for (int i = 0; i < N_Band; i++)
	//{
	//	m_band_eList[0][i] = 167.8204 / N_Band;
	//}

}

double GameTheory_Band::MiddleFormula(int n,int level)
{
	cout << "m_band_FrameLeftbit: " << m_band_FrameLeftbit << endl;
	for (int i = n; i < BandGT->m_band_Num; i++)
	{
		double tempvalueS = (m_band_theta_unity * m_band_FrameLeftbit) / m_band_disagreementMinimum;
		
		if (tempvalueS > 1)
		{
			tempvalueS = 1;
		}

		m_band_TempDisagreement[i] = tempvalueS * 1.0/ (m_band_eList[level][i]);
		/*if (tempDisagreement[j] > 1)
			tempDisagreement[j] = 1;*/

		m_band_TempMiddleFormula += (m_band_kList[level][i] * m_band_MADList[level][i] * m_band_rList[level][i] * m_band_weight[i] * m_band_TempDisagreement[i]);
		//tempDisagreement = 0;
	}
	/*if (tempMiddleFormula > 1)
		tempMiddleFormula = 1;*/
	return m_band_TempMiddleFormula;
}
void GameTheory_Band::ClearTempMiddle()
{
	m_band_TempMiddleFormula = 0;
}

void GameTheory_Band::ClearTempDis()
{
	for (int i = 0; i < BandGT->m_band_Num; i++)
	{
		m_band_TempDisagreement[i] = 0.0;
	}
}

double GameTheory_Band::DenoDisagreement(int n,int level)
{
	for (int i =n ; i < BandGT->m_band_Num; i++)
	{
		m_band_disagreementMinimum += m_band_weight[i] *m_band_kList[level][i] * m_band_MADList[level][i] * m_band_rList[level][i] / m_band_eList[level][i]; //20190704 �ֽ��� proposed0703
		//cout<<"disagreementMinimum: "<<m_band_kList[level][i] * m_band_MADList[level][i] * m_band_rList[level][i] / m_band_eList[level][i] <<endl;
	}

	return m_band_disagreementMinimum;
}

double GameTheory_Band::GetMiddleValue()
{
	return m_band_TempMiddleFormula;
}

double GameTheory_Band::GetDisagreement()
{
	return m_band_disagreementMinimum;
}

void GameTheory_Band::ClearDisagreement()
{
	m_band_disagreementMinimum = 0;
}