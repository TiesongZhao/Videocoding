#pragma once
/*!
  *@file   GameTheory_Band.h
  *@brief  proposed the Game theory for frame in band
  *@author Lin jielian
  *@date   2021/01/05
  */
#define Band
//#define Band_Debug
class GameTheory_Band
{
public:
	GameTheory_Band();
	~GameTheory_Band();
	void init_Band();
	void init_Band_parameter(int N_Band);
	double MiddleFormula(int n,int level);
	void ClearTempMiddle();
	void ClearTempDis();
	double DenoDisagreement(int n,int level);
	double GetMiddleValue();
	double GetDisagreement();
	void ClearDisagreement();
	bool m_band_isFirstGop;
	//private:
	// video info
	int m_band_Num;
	int m_band_VideoWidth;
	int m_band_VideoHeight;
	int m_band_FrameLeftbit;
	int m_band_FrameStorebit;
	double m_band_weight[32];
	double m_band_kexi;

	//general rate contron info
	int m_band_GOPSize;
	int m_band_MaxLevel;
	int m_band_initQp;

	int m_band_RemainBits;


	//number of coded frame in every layer
	int m_band_CodeNum[32];  //encode frame num in every layer
	int m_band_Ni[32];//non-encode frame num in every layer
	bool m_band_FirstFrame[5][32];

	//Qp and Qstep for every layer
	double m_band_Qstep[32];
	int m_band_iQc[32]; //QP current
	int m_band_iPrevQc[5][32];//QP Previous
	double m_band_estimateqp[32];
	double m_band_BUweighted[32];
	double m_band_estimateLambda[32];
	//R-Q model parameter
	double m_band_kList[5][32];	//init Kappa parameter  row: level col: the nth frame in layer
	double m_band_kcount[5][32]; //the num of encoded frame in every layer
	double m_band_rcount[5][32]; //the num of encoded frame in every layer
	double m_band_R[5][32];        // 
	double m_band_targetbit[32];
	double m_band_bitleft;
	//D-Q model parameter
	double m_band_rList[5][32];	//init Gamma parameter  row: level col: the nth frame in layer
	double m_band_eList[5][32]; //init distortion of  row: level col: the nth frame in layer
	double m_band_ecount[5][32]; //the num of encoded frame in every layer


	double m_band_hList[5][32];	//init headerbits of  row: level col: the nth frame in layer
	double m_band_MADList[5][32];	//init MAD  
	double m_band_previousMADList[5][32];	//init previous MAD  
	double m_band_SSDList[32];
	double m_band_SADList[32];
	double m_band_LastTimeSSDTemp[32];
	double m_band_LastTimeSADTemp[32];
	int m_band_PreviousQP[5][32];
	double m_band_PreviousQPCount[5][32];

	double m_band_theta_unity;
	int m_band_level;
	double m_band_BudgetBit;
	double m_band_w_para;
	double m_band_m_para;
	double m_band_k_para;
	double m_band_r_para;
	//formular middle parameters
	double m_band_disagreementMinimum;
	double m_band_TempDisagreement[32];
	double m_band_TempMiddleFormula;

	double m_band_YLCUValue[32];
	bool m_band_isPOC0;
};

#ifdef Band
extern GameTheory_Band *BandGT;
#endif