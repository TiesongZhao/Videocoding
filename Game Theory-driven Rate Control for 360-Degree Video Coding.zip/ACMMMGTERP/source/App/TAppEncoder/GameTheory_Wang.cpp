#include "GameTheory_Wang.h"
#include<math.h>
/*!
  *@file   GameTheory_Wang.cpp
  *@brief  reproduce the paper "Applying Game Theory to Rate Control Optimization for Hierarchical B-Pictures"
  *@author Lin jielian
  *@date   2021/01/01
  */
#ifdef Wang
GameTheory_Wang *WangGT;
#endif

GameTheory_Wang::GameTheory_Wang()
{

	
}


GameTheory_Wang::~GameTheory_Wang()
{
}

void GameTheory_Wang::init_parameter(void)
{
	m_frame_MaxLevel = 4;
	m_frame_GOPNumb = 0;
	m_frame_c_unity = 0.5;
	m_frame_Xi = 0.60;
	m_frame_level = 0;
	m_frame_BudgetBit = 0;
	m_frame_alpa_para = 0.2;
	m_frame_m_para = 0.6;
	m_frame_k_para = 0.7;
	m_frame_r_para = 0.6;
	m_frame_e_para = 1;
	m_frame_iWindowSize_R = 0;
	m_frame_iWindowSize_D = 0;
	m_frame_RemainBits = 0;

	for (int i=0;i<5;i++)
	{

		m_frame_wl=0;
		m_frame_wo=0;
		m_frame_ws=0;
		m_frame_alpaL=0;
		m_frame_w_index[i] = 0;
		m_frame_rcount[i] = 0;
		m_frame_kcount[i] = 0;
		for (int j=0;j<600;j++)
		{
			m_frame_vs[i][j] = 0;
			m_frame_vt[i][j] = 0;
			m_frame_u[i][j] = 0;
		}
	}
	for (int i = 0; i <= m_frame_MaxLevel; i++)
	{
		m_frame_m_HeaderCount[i] = 0;
		m_frame_Ni[i] = 0;
		m_frame_FirstFrame[i] = true;
		m_frame_R[i] = 0;
		m_frame_Qstep[i]=0;

		m_frame_CodeNum[i] = 0;

		m_frame_kList[i] = 0;
		m_frame_rList[i] = 10;
		m_frame_ecount[i] = 0;
		m_frame_d[i] = 0;
		m_frame_hList[i] = 0;
		m_frame_MADList[i]=0;
		m_frame_iQc[i] = 0;
		m_frame_iPrevQc[i] = 0;
		m_frame_previousMADList[i]=0;
		for (int j = 0; j < 21; j++)
		{
			m_frame_dPRgQp_D[i][j] = 0;
			m_frame_dQstep_D[i][j] = 0;
			m_frame_dPRgDist[i][j] = 0;
			m_frame_dD[i][j] = 0;
			m_frame_dPRgQp_R[i][j] = 0;
			m_frame_dQstep_R[i][j] = 0;
			m_frame_dPRgRp[i][j] = 0;
			m_frame_dR[i][j] = 0;
		}

	}
	m_frame_iWindowSize_R = 0;
	m_frame_isFirstGop = true;
}
void GameTheory_Wang::init_mse(int nband)
{
	//if (nband==26)
	//{
	m_frame_eList[4] = 192.55303;
	m_frame_eList[3] = 201.1277955;
	m_frame_eList[2] = 203.4182028;
	m_frame_eList[1] = 181.7097372;
	m_frame_eList[0] = 167.8204212;
	//} 
	//else
	//{
	//	m_frame_eList[4] = 175.8354042
	//		;
	//	m_frame_eList[3] = 182.0371214
	//		;
	//	m_frame_eList[2] = 183.4732459
	//		;
	//	m_frame_eList[1] = 167.2820748
	//		;
	//	m_frame_eList[0] = 161.5449068
	//		;
	//}
}
/*!
 *************************************************************************************
 * \brief
 *    map QP to dQstep
 *
 *************************************************************************************
*/
double GameTheory_Wang::QP2Qstep(int iQP)
{
	int i;
	double dQstep;
	static const double dQP2QSTEP[6] = { 0.625, 0.6875, 0.8125, 0.875, 1.0, 1.125 };

	dQstep = dQP2QSTEP[iQP % 6];
	for (i = 0; i < (iQP / 6); i++)
		dQstep *= 2;

	return dQstep;
}
double GameTheory_Wang::level_weight(int level)
{
	double levelWeight = 0;
	switch (level)
	{
	case 0:
		levelWeight = (1 + m_frame_Xi)*(1 + m_frame_Xi + 2 * pow(m_frame_Xi, 2) + 4 * pow(m_frame_Xi, 3) + 8 * pow(m_frame_Xi, 4));
		break;
	case 1:
		levelWeight = 1 + 2 * pow(m_frame_Xi, 1) + 4 * pow(m_frame_Xi, 2) + 8 * pow(m_frame_Xi, 3);
		break;
	case 2:
		levelWeight = 1 + 2 * m_frame_Xi + 4 * pow(m_frame_Xi, 2);
		break;
	case 3:
		levelWeight = 1 + 2 * m_frame_Xi;
		break;
	case 4:
		levelWeight = 1;
		break;
	}
	return levelWeight;
}