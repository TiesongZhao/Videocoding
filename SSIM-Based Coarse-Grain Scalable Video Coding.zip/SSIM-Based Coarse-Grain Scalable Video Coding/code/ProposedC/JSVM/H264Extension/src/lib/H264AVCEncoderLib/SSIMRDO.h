#ifndef __SSIM_RDO_H__
#define __SSIM_RDO_H__

#include "SSIMDistortion.h"

#define SSIM_C1 6.5025
#define SSIM_C2 58.5225
#ifdef SSIM_DISTORTION
	#define SSIM_RDO
	// ssim rdo, only can be used if ssim_distortion enabled
#endif SSIM_DISTORTION

#ifdef SSIM_RDO
//	#define MB_LEVEL_SSIM_RDO
//	#define INTRA_LAYER_ADJ
	#define INTER_LAYER_ADJ
#endif SSIM_RDO

#define LAYER_SSIM_STAT

#ifdef LAYER_SSIM_STAT
extern int zts_NumLayers;
extern int zts_GOPSize;
extern int * zts_LayerFile;
extern int * zts_LayerQp;
extern double * zts_LayerWeight;
extern double * zts_LayerSSIM;
extern double * zts_LayerBR;
#endif LAYER_SSIM_STAT

class xSSIMImgRDOPara{
public:
	xSSIMImgRDOPara()
	{	
		SetZeroLap();
		Omega = 0;
		Phi = 1.33;
	}
	~xSSIMImgRDOPara() {;}
	void SetZeroLap()
	{
		for (int k=0; k<16; k++)
		{
			SSIMSubLap[k] = 0;
		}
		BRLap = 0;
	}
public:
	double SSIMSubLap[16];
	double BRLap;
	double Omega;
	double Phi;
};

class xSSIMImgRDO{
public:
	xSSIMImgRDO();
	// init: m_FrameCnt(-1), curr_para_idx(-1), m_gamma, m_Quant4x4
	~xSSIMImgRDO();

	void SetImg(int ImgHeight, int ImgWidth, int TLevel, int GOPSize);

	int GetFrameCnt();
	void SetQstep(int Qp, double Qstep); // if GetFrameCnt()<0 then SetQstep;

	double CalculateLambda(int TemporalLevel, int frame_type, XPel *ImgLumAddr, UInt LStride);
	// m_FrameCnt++; curr_para_idx++; if m_FrameCnt<3 return lambda_hr 
	// number_skip = 0;
	// predict m_SubLap, m_omega
	// calculate m_var
	// calculate mse_dev, ssim_dev, r_dev
	// return lambda

	double GetLambda();

	void UpdateSkipMode(bool IsSkip);

	void StoreOrgImg(XPel *OrgLum, UInt Stride);
	void StorePredImg(XPel *PredLum, UInt Stride);
	void StoreRecImg(XPel *RecLum, UInt Stride);
	
	
	void UpdateSSIMRate(double SSIM, double Rates);
	// calculate parameters
	// store them

#ifdef MB_LEVEL_SSIM_RDO
	double GetLambdaMultiplier(int MbY, int MbX);	// before coding an MB
	// if (m_FrameCnt>2) calculate Eata and return;
	void UpdateLambdaMultiplier(int MbY, int MbX, double MB_MV_y[4][4], double MB_MV_x[4][4], XPel *MB_Lum, int iStride); // after coding an MB, mv_y[4][4], mv_x[4][4]
	// if (m_FrameCnt<1) return;
	// Load mvs; if (IsLastMB) calculate m_MV_g;
	// if (m_FrameCnt<2) return;
	// compute v_r, c
	// compute m_weight and store
	// update m_ave_weight
#endif MB_LEVEL_SSIM_RDO

private:	

	double CalculateLambdaHR(bool IsIFrame);
	static void Transform4x4(XPel *Input, int iStride, int *Output);
	// Output[16]
#ifdef MB_LEVEL_SSIM_RDO
	double CalculateGlobalMV(double **MV, double MV_min, double MV_max);
#endif MB_LEVEL_SSIM_RDO
	
private:
	int m_FrameCnt;
	unsigned int curr_para_idx;
	xSSIMImgRDOPara m_Para[2];

	double m_Lambda;
	
	double m_var[16];
	double m_gamma;
	int m_Qp;
	double m_Qstep;
	double m_Quant4x4[16];
	int m_NumberSkip;

	int m_ImgWidth;
	int m_ImgHeight;
	int m_ImgH_inblocks, m_ImgW_inblocks;
	int m_ImgH_inMBs, m_ImgW_inMBs;
	double m_Number_4x4blocks, m_Number_MBs;
	
	bool m_IsIFrame;
	double m_Mu, m_Nu;

	XPel *m_Img, *m_Pred, *m_Rec;

#ifdef MB_LEVEL_SSIM_RDO
	double **m_MV_y, **m_MV_x;
	double m_MV_g[2]; // 0:y, 1:x
	double m_MV_min[2], m_MV_max[2]; // 0:y, 1:x
	double **m_weight;
	double m_ave_weight;
#endif MB_LEVEL_SSIM_RDO
};

class xSSIMRDO{
public:
	xSSIMRDO(int NumLayers, int NumTemporalLevels, int *LayerHeight, int *LayerWidth, double *alpha, double *beta, int *Layer_Qp);
	~xSSIMRDO();

	Double CalculateLambda(UInt Layer, UInt TemporalLevel, int Qp, int frame_type, XPel *ImgLumAddr, UInt LStride);

	void UpdateSkipMode(bool IsSkip);

	void StoreOrgImg(XPel *OrgLum, UInt Stride);

	void StorePredImg(XPel *PredLum, UInt Stride);

	void StoreRecImg(XPel *RecLum, UInt Stride);
	
	
	void UpdateSSIMRate(double SSIM, double Rates);

#ifdef MB_LEVEL_SSIM_RDO
	double GetMBLambda(int MbY, int MbX);
	void UpdateMBLambda(int MbY, int MbX, double MB_MV_y[4][4], double MB_MV_x[4][4], XPel *MB_Lum, int iStride);
#endif MB_LEVEL_SSIM_RDO

private:
	static Double GetQstep(int Qp);

private:
	// layers
	int m_NumLayers, m_Layer;
	//double *m_alpha, *m_beta;
	//double *m_LayerQstep;

	Double *m_LayerFactor;
	Double *m_TLevelFactor;

	// temporal levels
	int m_NumTLevels, m_TLevel;
	xSSIMImgRDO **m_ImgRDO;
};

#ifdef SSIM_RDO
	extern xSSIMRDO* z_SSIMRDO;
#endif SSIM_RDO

#endif __SSIM_RDO_H__