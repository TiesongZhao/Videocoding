#include "SSIMRDO.h"

#ifdef SSIM_RDO
	xSSIMRDO* z_SSIMRDO;
#endif SSIM_RDO

#ifdef LAYER_SSIM_STAT
int zts_NumLayers;
int zts_GOPSize;
int * zts_LayerFile;
int * zts_LayerQp;
double * zts_LayerWeight;
double * zts_LayerSSIM;
double * zts_LayerBR;
#endif LAYER_SSIM_STAT

xSSIMImgRDO::xSSIMImgRDO()
{
	m_FrameCnt = -1;
	curr_para_idx = 1;
	m_gamma = 1.0/6;
	m_Quant4x4 [0] = m_Quant4x4 [2] = m_Quant4x4 [8] = m_Quant4x4 [10] = 0.25;
	m_Quant4x4 [5] = m_Quant4x4 [7] = m_Quant4x4 [13] = m_Quant4x4 [15] = 0.1;
	m_Quant4x4 [1] = m_Quant4x4 [3] = m_Quant4x4 [4] = m_Quant4x4 [6] = m_Quant4x4 [9] = m_Quant4x4 [11] = m_Quant4x4 [12] = m_Quant4x4 [14] = 0.158113883;	
}

xSSIMImgRDO::~xSSIMImgRDO()
{
	delete(m_Img);
	delete(m_Pred);
	delete(m_Rec);
}

void xSSIMImgRDO::SetImg(int ImgHeight, int ImgWidth, int TLevel, int GOPSize)
{
	m_ImgHeight = ImgHeight;
	m_ImgWidth = ImgWidth;
	m_ImgH_inblocks = ImgHeight/4;
	m_ImgW_inblocks = ImgWidth/4;
	m_ImgH_inMBs = ImgHeight/16;
	m_ImgW_inMBs = ImgWidth/16;
	m_Number_4x4blocks = m_ImgH_inblocks * m_ImgW_inblocks;
	m_Number_MBs = m_Number_4x4blocks/16;
	
	/*
	m_Mu = 0.05*TLevel - 0.32;
	m_Nu = 0.07*GOPSize - 0.42*TLevel - 1.37;
	*/
	m_Mu = 0.05*TLevel - 0.25;
	m_Nu = 0.08*GOPSize - 0.50*TLevel - 1.35;

	m_Img = new XPel[m_ImgHeight*m_ImgWidth];
	m_Pred = new XPel[m_ImgHeight*m_ImgWidth];
	m_Rec = new XPel[m_ImgHeight*m_ImgWidth];

#ifdef MB_LEVEL_SSIM_RDO
	int i, j;
	m_MV_y = new double*[m_ImgH_inblocks];
	m_MV_y[0] = new double[m_ImgH_inblocks*m_ImgW_inblocks];
	for (j=1; j<m_ImgH_inblocks; j++)
	{
		m_MV_y[j] = m_MV_y[j-1] + m_ImgW_inblocks;
	}
	m_MV_x = new double*[m_ImgH_inblocks];
	m_MV_x[0] = new double[m_ImgH_inblocks*m_ImgW_inblocks];
	for (j=1; j<m_ImgH_inblocks; j++)
	{
		m_MV_x[j] = m_MV_x[j-1] + m_ImgW_inblocks;
	}
	m_weight = new double*[m_ImgH_inMBs];
	m_weight[0] = new double[m_ImgH_inMBs*m_ImgW_inMBs];
	for (j=1; j<m_ImgH_inMBs; j++)
	{
		m_weight[j] = m_weight[j-1] + m_ImgW_inMBs;
	}
	for (j=0; j<m_ImgH_inblocks; j++)
	{
		for (i=0; i<m_ImgW_inblocks; i++)
		{
			m_MV_y[j][i] = m_MV_x[j][i] = 0;
		}
	}
	for (j=0; j<m_ImgH_inMBs; j++)
	{
		for (i=0; i<m_ImgW_inMBs; i++)
		{
			m_weight[j][i] = 1.0;
		}
	}
	m_MV_g[0] = m_MV_g[1] = 0;
	m_ave_weight = 1.0;
#endif MB_LEVEL_SSIM_RDO
}

int xSSIMImgRDO::GetFrameCnt()
{
	return m_FrameCnt;
}

void xSSIMImgRDO::SetQstep(int Qp, double Qstep)
{
	m_Qp = Qp;
	m_Qstep = Qstep;
}

void xSSIMImgRDO::Transform4x4(XPel *Input, int iStride, int *Output)
{
	Int aai[4][4];
	Int tmp1, tmp2;
	Int x, y;
	Int *piPredCoeff = Output;
	for( y = 0; y < 4; y++ )
	{
		tmp1 = Input[0] + Input[3];
		tmp2 = Input[1] + Input[2];

		aai[0][y] = tmp1 + tmp2;
		aai[2][y] = tmp1 - tmp2;

		tmp1 = Input[0] - Input[3];
		tmp2 = Input[1] - Input[2];

		aai[1][y] = tmp1 * 2 + tmp2 ;
		aai[3][y] = tmp1  - tmp2 * 2;
		Input += iStride;
	}
	for( x = 0; x < 4; x++, piPredCoeff++ )
	{
		tmp1 = aai[x][0] + aai[x][3];
		tmp2 = aai[x][1] + aai[x][2];
		
		piPredCoeff[0] = tmp1 + tmp2;
		piPredCoeff[8] = tmp1 - tmp2;
		
		tmp1 = aai[x][0] - aai[x][3];
		tmp2 = aai[x][1] - aai[x][2];
		
		piPredCoeff[4]  = tmp1 * 2 + tmp2;
		piPredCoeff[12] = tmp1 - tmp2 * 2;
	}
}

double xSSIMImgRDO::CalculateLambdaHR(bool IsIFrame)
{
	double Lambda = 0.00007*m_Qstep*m_Qstep-0.0000000005*m_Qstep*m_Qstep*m_Qstep*m_Qstep;
	if (!IsIFrame)
	{
		Lambda *= 3.0;
	}
	return Lambda;
}

double xSSIMImgRDO::CalculateLambda(int TemporalLevel, int frame_type, XPel *ImgLumAddr, UInt LStride)
{
	m_IsIFrame = (frame_type == 2); // I_SLICE = 2
	double m_LambdaHR = CalculateLambdaHR(m_IsIFrame);
	m_Lambda = m_LambdaHR;

	if (TemporalLevel == 0)
	{
		return m_Lambda;
	}

	m_FrameCnt ++;
	curr_para_idx = 1 - curr_para_idx;
	m_NumberSkip = 0;

	// compute m_var[16]
	Int k, n, x;
	Int iOffset = 0;
	Int MBTrans[16];
	Double ave_x_sq[16], ave_x[16];
	for (k=0; k<16; k++)
	{
		ave_x_sq[k] = ave_x[k] = 0;
	}
	for (n = 0; n < m_ImgH_inblocks; n ++)
	{
		for (x = 0; x < m_ImgW_inblocks; x++)
		{
			Int iOffsetBlk = iOffset + (x << 2);
			Transform4x4(ImgLumAddr+iOffsetBlk, LStride, MBTrans);
			for (k=0; k<16; k++)
			{
				Double IntDCTCoeff = MBTrans[k]*m_Quant4x4[k];
				ave_x_sq[k] += IntDCTCoeff*IntDCTCoeff;
				ave_x[k] += IntDCTCoeff;
			}
		}
		iOffset += (LStride<<2);
	}
	for (k=0; k<16; k++)
	{
		ave_x_sq[k] /= m_Number_4x4blocks; 
		ave_x[k] /= m_Number_4x4blocks; 
		m_var[k] = ave_x_sq[k] - ave_x[k]*ave_x[k];
	}

	if (m_FrameCnt < 2 ) 
	{
		m_Para[curr_para_idx].SetZeroLap();
		return m_LambdaHR;
	}

	// predict SubLap, omega, etc
	int prev_para_idx = 1 - curr_para_idx;
	double Pred_SubLap[16], Pred_Lap, Pred_omega, Pred_Phi;
	for (k=0; k<16; k++)
	{
		Pred_SubLap[k] = (m_Para[0].SSIMSubLap[k]+m_Para[1].SSIMSubLap[k])/2.0;
	}
	Pred_Lap = m_Para[prev_para_idx].BRLap;
	m_Para[curr_para_idx].SetZeroLap();
	Pred_omega = (m_Para[0].Omega + m_Para[1].Omega)/2.0;
	Pred_Phi = (m_Para[0].Phi + m_Para[1].Phi)/2.0;

	// R-Q
	double  R_1, R_2, R_3, R_4, R_5, R_6, R_7, R_8, R_3_dev, R_4_dev;
	R_1 = m_Mu * Pred_Lap;
	R_2 = exp(R_1 * m_Qstep + m_Nu);
	R_2 /= log(2.0);
	R_3 = 1 - exp((m_gamma-1) * Pred_Lap * m_Qstep);
	R_3_dev = (1-m_gamma) * Pred_Lap * (1-R_3);
	R_4 = 1 - exp(-Pred_Lap * m_Qstep);
	R_4_dev = Pred_Lap * (1-R_4);
	R_5 = log(1-Pred_omega*R_3);
	R_6 = log((1-Pred_omega)*R_3);
	R_7 = log(2.0/R_4);
	R_8 = Pred_Lap*(1.0/R_4-m_gamma);

	double R_dev = R_1 * ( (1-Pred_omega*R_3) * R_5 - (1-Pred_omega)*R_3 * R_6 + (1-R_3) * (R_7+ m_Qstep * R_8) );
	R_dev -= R_3_dev * ( Pred_omega * R_5 + (1-Pred_omega) * R_6 + R_7 + m_Qstep * R_8 + 1 );
	R_dev += (1-R_3) * ( R_8 - R_4_dev * (1.0/R_4+Pred_Lap*m_Qstep/R_4/R_4) );
	R_dev *= R_2;

	if (R_dev == 0)
		return m_LambdaHR;

	// D-Q
	double MSE[16], MSE_dev[16];
	for (k=0; k<16; k++)
	{
		double erlq = exp(m_gamma*Pred_SubLap[k]*m_Qstep);
		double elq = exp(Pred_SubLap[k]*m_Qstep);
		double twobs = 2/Pred_SubLap[k]/Pred_SubLap[k];
		MSE[k] =  twobs + ((1-2*m_gamma)*m_Qstep+2/Pred_SubLap[k]) * m_Qstep * erlq / (1-elq);
		MSE_dev[k] = ((1-m_gamma)*(1-2*m_gamma)*m_Qstep*m_Qstep + 2*m_gamma*m_Qstep/Pred_SubLap[k] - twobs) * elq;
		MSE_dev[k] += m_gamma*(1-2*m_gamma)*m_Qstep*m_Qstep + 2*(1-m_gamma)*m_Qstep/Pred_SubLap[k] + twobs;
		MSE_dev[k] *= Pred_SubLap[k] * erlq / (1-elq) / (1-elq);
	}
	double MRR_1 = 1 - MSE[0]/(2*m_var[0]+SSIM_C1);
	double  MRR_2 = 0, MRR_3 = 0;
	for (k=1; k<16; k++)
	{
		MRR_2 += MSE[k]/(2*m_var[k]+SSIM_C2);
		MRR_3 += MSE_dev[k]/(2*m_var[k]+SSIM_C2);
	}
	MRR_2 = 1 - MRR_2 / 15;
	MRR_3 /= 15;
	double  SSIM_dev = MSE_dev[0] * MRR_2 / (2*m_var[0]+SSIM_C1) + MRR_1 * MRR_3;
	SSIM_dev *= -Pred_Phi;

	m_Lambda = SSIM_dev/R_dev;

	if (m_Lambda > 7.39 * m_LambdaHR || m_Lambda < 0.135 * m_LambdaHR)
		m_Lambda = m_LambdaHR;

	return m_Lambda;
}

double xSSIMImgRDO::GetLambda()
{
	return m_Lambda;
}

void xSSIMImgRDO::UpdateSkipMode(bool IsSkip)
{
#ifndef COEFF_STAT
	if (m_IsIFrame) return;
#endif COEFF_STAT

	if (IsSkip) m_NumberSkip ++;
}

void xSSIMImgRDO::StoreOrgImg(XPel *OrgLum, UInt Stride)
{
	int x, y;
	XPel *OrgSrc = OrgLum;
	XPel *OrgDes = m_Img;
	for (y=0; y<m_ImgHeight; y++)
	{
		for (x=0; x<m_ImgWidth; x++)
		{
			OrgDes[x] = OrgSrc[x];
		}
		OrgSrc += Stride;
		OrgDes += m_ImgWidth;
	}
}

void xSSIMImgRDO::StorePredImg(XPel *PredLum, UInt Stride)
{
	int x, y, k;
	XPel *Org = m_Img;
	XPel *PredSrc = PredLum;
	XPel *PredDes = m_Pred;
	for (y=0; y<m_ImgHeight; y++)
	{
		for (x=0; x<m_ImgWidth; x++)
		{
			PredDes[x] = Org[x] - PredSrc[x];
		}
		Org += m_ImgWidth;
		PredSrc += Stride;
		PredDes += m_ImgWidth;
	}

	Int Trans4x4[16];
	PredDes = m_Pred;
	for (y=0; y<m_ImgHeight; y+= 4)
	{
		for (x=0; x<m_ImgWidth; x+=4)
		{
			Transform4x4(PredDes+x, m_ImgWidth, Trans4x4);
			for (k=0; k<16; k++)
			{
				if (Trans4x4[k] < 0)
					Trans4x4[k] = - Trans4x4[k];
				m_Para[curr_para_idx].BRLap += Trans4x4[k] * m_Quant4x4[k];
			}
		}
		PredDes += (m_ImgWidth<<2);
	}		
}

void xSSIMImgRDO::StoreRecImg(XPel *RecLum, UInt Stride)
{
	int x, y, k;
	XPel *Org = m_Img;
	XPel *RecSrc = RecLum;
	XPel *RecDes = m_Rec;
	for (y=0; y<m_ImgHeight; y++)
	{
		for (x=0; x<m_ImgWidth; x++)
		{
			RecDes[x] = Org[x] - RecSrc[x];
		}
		Org += m_ImgWidth;
		RecSrc += Stride;
		RecDes += m_ImgWidth;
	}

	Int Trans4x4[16];
	RecDes = m_Rec;
	for (y=0; y<m_ImgHeight; y+= 4)
	{
		for (x=0; x<m_ImgWidth; x+=4)
		{
			Transform4x4(RecDes+x, m_ImgWidth, Trans4x4);
			for (k=0; k<16; k++)
			{
				if (Trans4x4[k] < 0)
					Trans4x4[k] = - Trans4x4[k];
				m_Para[curr_para_idx].SSIMSubLap[k] += Trans4x4[k];
			}
		}
		RecDes += (m_ImgWidth<<2);
	}	
}

void xSSIMImgRDO::UpdateSSIMRate(double SSIM, double Rates)
{
	if (m_IsIFrame) return;

	Int k;
	for (k=0; k<16; k++)
	{
		m_Para[curr_para_idx].SSIMSubLap[k] /= m_Number_4x4blocks;
		m_Para[curr_para_idx].SSIMSubLap[k] *= m_Quant4x4[k];
		m_Para[curr_para_idx].SSIMSubLap[k] = 1.0 / m_Para[curr_para_idx].SSIMSubLap[k];
	}
	m_Para[curr_para_idx].BRLap /= (m_Number_4x4blocks*16);
	m_Para[curr_para_idx].BRLap = 1.0 / m_Para[curr_para_idx].BRLap;
	m_Para[curr_para_idx].Omega = m_NumberSkip / m_Number_MBs / (1 - exp((m_gamma-1)*m_Para[curr_para_idx].BRLap*m_Qstep));

	if (m_Para[curr_para_idx].Omega >= 1)
		m_Para[curr_para_idx].Omega = 0.99;

	double MSE[16];
	for (k=0; k<16; k++)
	{
		double erlq = exp(m_gamma*m_Para[curr_para_idx].SSIMSubLap[k]*m_Qstep);
		double elq = exp(m_Para[curr_para_idx].SSIMSubLap[k]*m_Qstep);
		double twobs = 2/m_Para[curr_para_idx].SSIMSubLap[k]/m_Para[curr_para_idx].SSIMSubLap[k];
		MSE[k] =  twobs + ((1-2*m_gamma)*m_Qstep+2/m_Para[curr_para_idx].SSIMSubLap[k]) * m_Qstep * erlq / (1-elq);
	}
	double MRR_1 = 1 - MSE[0]/(2*m_var[0]+SSIM_C1);
	double MRR_2 = 0;
	for (k=1; k<16; k++)
	{
		MRR_2 += MSE[k]/(2*m_var[k]+SSIM_C2);
	}
	MRR_2 = 1 - MRR_2 / 15;
	double zts_MRR = MRR_1 * MRR_2;

	if (zts_MRR != 1.0)
	{
		m_Para[curr_para_idx].Phi = (1.0-SSIM) / (1.0-zts_MRR);
	}
}

#ifdef MB_LEVEL_SSIM_RDO

double xSSIMImgRDO::GetLambdaMultiplier(int MbY, int MbX)
{
	double Eta = 1.0;
	if (m_FrameCnt > 2)
	{
		Eta = pow(m_ave_weight/m_weight[MbY][MbX], 0.25);
		if (Eta > 2)
			Eta = 2;
		if (Eta < 0.5)
			Eta = 0.5;
	}
	return Eta;	
}	

double xSSIMImgRDO::CalculateGlobalMV(double **MV, double MV_min, double MV_max)
{
	int k;
	int histo_num = int((MV_max-MV_min)/4 + 1);
	int *histo = new int[histo_num];
	for (k=0; k<histo_num; k++)
	{
		histo[k] = 0;
	}

	int i, j;
	for (j=0; j<m_ImgH_inblocks; j++)
	{
		for (i=0; i<m_ImgW_inblocks; i++)
		{
			k = int((MV[j][i] - MV_min)/4);
			if (k < 0)	k = 0;
			if (k >= histo_num) k = histo_num-1;
			histo[k] ++;
		}
	}
	
	int MV_idx = 0;
	for (k=1; k<histo_num; k++)
	{
		if (histo[k] > histo[MV_idx])
			MV_idx = k;
	}

	return (MV_min+MV_idx*4);
}

void xSSIMImgRDO::UpdateLambdaMultiplier(int MbY, int MbX, double MB_MV_y[4][4], double MB_MV_x[4][4], XPel *MB_Lum, int iStride)
{
	if (m_FrameCnt < 1)
		return;

	if (MbY == 0 && MbX == 0)
	{
		m_MV_min[0] = m_ImgHeight* 4;
		m_MV_min[1] = m_ImgWidth * 4;
		m_MV_max[0] = -m_MV_min[0];
		m_MV_max[1] = -m_MV_min[1];
	}

	int j, i;
	int topleft_blk_y = MbY * 4;
	int topleft_blk_x = MbX * 4;
	// loop all 4x4 blocks
	for (j=0; j<4; j++)
	{
		for (i=0; i<4; i++)
		{
			m_MV_y[topleft_blk_y+j][topleft_blk_x+i] = MB_MV_y[j][i];
			m_MV_x[topleft_blk_y+j][topleft_blk_x+i] = MB_MV_x[j][i];
			if (MB_MV_y[j][i] < m_MV_min[0])
				m_MV_min[0] = MB_MV_y[j][i];
			if (MB_MV_y[j][i] > m_MV_max[0])
				m_MV_max[0] = MB_MV_y[j][i];
			if (MB_MV_x[j][i] < m_MV_min[1])
				m_MV_min[1] = MB_MV_x[j][i];
			if (MB_MV_x[j][i] > m_MV_max[1])
				m_MV_max[1] = MB_MV_x[j][i];
		}
	}

	if (MbY+1 == m_ImgH_inMBs && MbX+1 == m_ImgW_inMBs)
	{
		m_MV_g[0] = CalculateGlobalMV(m_MV_y, m_MV_min[0], m_MV_max[0]);
		m_MV_g[1] = CalculateGlobalMV(m_MV_x, m_MV_min[1], m_MV_max[1]);
	}

	if (m_FrameCnt<2)
		return;

	double weight = 0;
	int iOffset = 0;
	// loop all 8x8 blocks
	for (j=0; j<2; j++)
	{
		for (i=0; i<2; i++)
		{
			// rMV
			double MV_r[2];
			topleft_blk_y = j * 2;
			topleft_blk_x = i * 2;
			MV_r[0] = (MB_MV_y[topleft_blk_y][topleft_blk_x] + MB_MV_y[topleft_blk_y][topleft_blk_x+1] + 
				MB_MV_y[topleft_blk_y+1][topleft_blk_x] + MB_MV_y[topleft_blk_y+1][topleft_blk_x+1])/4.0;
			MV_r[1] = (MB_MV_x[topleft_blk_y][topleft_blk_x] + MB_MV_x[topleft_blk_y][topleft_blk_x+1] + 
				MB_MV_x[topleft_blk_y+1][topleft_blk_x] + MB_MV_x[topleft_blk_y+1][topleft_blk_x+1])/4.0;
			MV_r[0] -= m_MV_g[0];
			MV_r[1] -= m_MV_g[1];
			double rMV = sqrt(MV_r[0]*MV_r[0] + MV_r[1]*MV_r[1]);

			// contrast
			double blk_mean = 0, blk_sigma = 0;
			XPel *pCur = MB_Lum + iOffset + (i << 3);
			int m, n;
			for (m=0; m<8; m++)
			{
				for (n=0; n<8; n++)
				{
					blk_mean += pCur[n];
					blk_sigma += pCur[n] * pCur[n];
				}
				pCur += iStride;
			}
			blk_mean /= 64;
			blk_sigma /= 64;
			blk_sigma -= blk_mean * blk_mean;
			blk_sigma = sqrt(blk_sigma);

			double contrast = pow( blk_sigma / (blk_mean+6) / 0.05, 2);
			contrast = 1 - exp(-contrast);
			weight += log(1+rMV/0.32) + log(1+contrast/0.7);
		}
		iOffset += (iStride << 3);
	}
	weight /= 4.0;

	m_ave_weight += (weight-m_weight[MbY][MbX])/m_Number_MBs; 
	m_weight[MbY][MbX] = weight;
}
#endif MB_LEVEL_SSIM_RDO

xSSIMRDO::xSSIMRDO(int NumLayers, int NumTemporalLevels, int *LayerHeight, int *LayerWidth, double *alpha, double *beta, int *Layer_Qp)
{
	int i, j, k;
	m_NumLayers = NumLayers;
	m_NumTLevels = NumTemporalLevels;
	m_ImgRDO = new xSSIMImgRDO *[m_NumLayers];
	m_ImgRDO[0] = new xSSIMImgRDO[m_NumLayers*m_NumTLevels];
	for (k=1; k<m_NumLayers; k++)
	{
		m_ImgRDO[k] = m_ImgRDO[k-1] + m_NumTLevels;
	}
	for (k=0; k<m_NumLayers; k++)
	{
		for (j=0; j<m_NumTLevels; j++)
		{
			m_ImgRDO[k][j].SetImg(LayerHeight[k], LayerWidth[k], j, 1<<(NumTemporalLevels-1));
		}
	}

#ifdef INTER_LAYER_ADJ
	m_LayerFactor = new Double[m_NumLayers];
	if (m_NumLayers>1)
	{
		Double *D_delta = new Double[m_NumLayers];
		Double *R_delta = new Double[m_NumLayers];
		Double Qstep1 = GetQstep(*(Layer_Qp+1));
		//D_delta[1] = 0.008 * Qstep1;
		//R_delta[1] = -0.0643 * Qstep1 + 0.5337;
		D_delta[1] = 0.001 * Qstep1;
		//R_delta[1] = -0.025 * Qstep1 + 0.55;
		R_delta[1] = -0.002 * Qstep1 + 0.2;
		for (k=2; k<m_NumLayers; k++)
		{
			D_delta[k] = 0;
			//R_delta[k] = 0.818;
			R_delta[k] = 0.5;
		}
		for (k=0; k<m_NumLayers-1; k++)
		{
			Double theta_1, theta_2, theta_3, theta_4;
			theta_1 = theta_2 = *(alpha+k);
			theta_3 = theta_4 = *(beta+k);
			for (i=k+1; i<m_NumLayers; i++)
			{
				Double theta_5 = 1, theta_6 = 1;
				for (j=k+1; j<=i; j++)
				{
					theta_5 *= D_delta[j];
					theta_6 *= R_delta[j];
				}
				theta_1 += (*(alpha+i)) * theta_5;
				theta_2 += *(alpha+i);
				theta_3 += (*(beta+i)) * theta_6;
				theta_4 += *(beta+i);
			}
			m_LayerFactor[k] = theta_1 * theta_4 / theta_2 / theta_3;
		}
	}
	m_LayerFactor[m_NumLayers-1] = 1.0;
#endif INTER_LAYER_ADJ

#ifdef INTRA_LAYER_ADJ
	m_TLevelFactor = new Double[m_NumTLevels];
	Double distortion_slope = 0.3;
	m_TLevelFactor[0] = pow(1+2*distortion_slope, m_NumTLevels) / (1-distortion_slope);
	for (k=1; k<m_NumTLevels; k++)
	{
		m_TLevelFactor[k] = pow(1+2*distortion_slope, m_NumTLevels-k);
	}
#endif INTRA_LAYER_ADJ
}

xSSIMRDO::~xSSIMRDO()
{
	delete(m_TLevelFactor);
	delete(m_LayerFactor);
	delete(m_ImgRDO[0]);
	delete(m_ImgRDO);
}

Double xSSIMRDO::GetQstep(int Qp)
{
	Double Q[6] = {0.625, 0.6875, 0.8125, 0.875, 1, 1.125};
	int a = Qp%6, b = Qp/6;
	return Q[a] * pow(2.0, b);
}

Double xSSIMRDO::CalculateLambda(UInt Layer, UInt TemporalLevel, int Qp, int frame_type, XPel *ImgLumAddr, UInt LStride)
{
	m_Layer = Layer;
	m_TLevel = TemporalLevel;
	if (m_ImgRDO[m_Layer][m_TLevel].GetFrameCnt() < 0)
		m_ImgRDO[m_Layer][m_TLevel].SetQstep(Qp, GetQstep(Qp));
	Double Lambda = m_ImgRDO[m_Layer][m_TLevel].CalculateLambda(TemporalLevel, frame_type, ImgLumAddr, LStride);
	//if (m_TLevel > 0) 
	//if(frame_type!=2)
#ifdef INTER_LAYER_ADJ
	Lambda *= m_LayerFactor[m_Layer];	
#endif INTER_LAYER_ADJ
#ifdef INTRA_LAYER_ADJ
	Lambda *= m_TLevelFactor[m_TLevel];	
#endif INTRA_LAYER_ADJ
	return (Lambda*SSIMDIST_EXT);
}

void xSSIMRDO::UpdateSkipMode(bool IsSkip)
{
	m_ImgRDO[m_Layer][m_TLevel].UpdateSkipMode(IsSkip);
}

void xSSIMRDO::StoreOrgImg(XPel *OrgLum, UInt Stride)
{
	m_ImgRDO[m_Layer][m_TLevel].StoreOrgImg(OrgLum, Stride);
}

void xSSIMRDO::StorePredImg(XPel *PredLum, UInt Stride)
{
	m_ImgRDO[m_Layer][m_TLevel].StorePredImg(PredLum, Stride);
}

void xSSIMRDO::StoreRecImg(XPel *RecLum, UInt Stride)
{
	m_ImgRDO[m_Layer][m_TLevel].StoreRecImg(RecLum, Stride);
}

void xSSIMRDO::UpdateSSIMRate(double SSIM, double Rates)
{
	m_ImgRDO[m_Layer][m_TLevel].UpdateSSIMRate(SSIM, Rates);
}

#ifdef MB_LEVEL_SSIM_RDO
double xSSIMRDO::GetMBLambda(int MbY, int MbX)
{
	Double Lambda = m_ImgRDO[m_Layer][m_TLevel].GetLambda();
	Lambda *= m_Theta[m_Layer];
	if (m_TLevel > 0) // not applicable in I frame 
		Lambda *= m_ImgRDO[m_Layer][m_TLevel].GetLambdaMultiplier(MbY, MbX);
	return (Lambda*SSIMDIST_EXT);
}

void xSSIMRDO::UpdateMBLambda(int MbY, int MbX, double MB_MV_y[4][4], double MB_MV_x[4][4], XPel *MB_Lum, int iStride)
{
	if (m_TLevel > 0) // not applicable in I frame 
		m_ImgRDO[m_Layer][m_TLevel].UpdateLambdaMultiplier(MbY, MbX, MB_MV_y, MB_MV_x, MB_Lum, iStride);
}
#endif MB_LEVEL_SSIM_RDO