#ifndef __SSIM_DISTORTION_H__
#define __SSIM_DISTORTION_H__

/*
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
*/
#include "math.h"
#include "H264AVCCommonIf.h"


#define N_SQ_C1 1664.64
#define N_SQ_C2 14981.76
// N for number of reference pixels to caculate ssim
#define SSIMDIST_EXT 256
// just make a integer distortion 
// both distortion & labmda multiplied by ssimdist_ext

#define SSIM_DISTORTION
// enabled: ssim bases distortion used
// disabled: ssd based distortion used 
#define SSIM_OUTPUT
// enabled: output ssim values in the cmd window
// disabled: output psnr

//#define INTRA_MODE_DIST

#define SHIQI_SSIM

/*
H264AVC_NAMESPACE_BEGIN


#if defined( MSYS_WIN32 )
#pragma warning( disable: 4275 )
#endif
*/

class xSSIMDistortion{
public:
	//xSSIMDistortion();
	xSSIMDistortion(UInt ImgMaxHeightInPixels, UInt ImgMaxWidthInPixels);
	// Initialize all; allocate storage
	//void InitSSIMDistortion(UInt ImgHeightInPixels, UInt ImgWidthInPixels);
	~xSSIMDistortion();

	void LoadOriginalImage(XPel *LumAddr, XPel *CbAddr, XPel *CrAddr, UInt LHeight, UInt LWidth, UInt LStride);
	// Load original image, compute and store Org_Mu, Org_Sigma for Y, U, V

	UInt GetDistLum16x16(XPel *RecLumAddr, UInt LStride, UInt topleft_pix_y, UInt topleft_pix_x);
	// N(1-MSSIM)*65535
	UInt GetDistLum8x8(XPel *RecLumAddr, UInt LStride, UInt topleft_pix_y, UInt topleft_pix_x);
#ifdef INTRA_MODE_DIST
	UInt GetDistLum4x4(XPel *RecLumAddr, UInt LStride, UInt topleft_pix_y, UInt topleft_pix_x);
#endif INTRA_MODE_DIST
	UInt GetDistCb8x8(XPel *RecCbAddr, UInt CStride, UInt topleft_pix_y, UInt topleft_pix_x);
	UInt GetDistCr8x8(XPel *RecCrAddr, UInt CStride, UInt topleft_pix_y, UInt topleft_pix_x);
	
	Double GetImageLumSSIM(XPel *RecLumAddr, UInt LStride);
	Double GetImageCbSSIM(XPel *RecCbAddr, UInt CStride);
	Double GetImageCrSSIM(XPel *RecCrAddr, UInt CStride);

	void SetLambda(Double lambda);
	//Double GetLambda();
	Double GetRDCost(UInt uiBits, UInt Dist);
#ifdef INTRA_MODE_DIST
	Double GetFRDCost(UInt uiBits, UInt Dist);
#endif INTRA_MODE_DIST

private:

	UInt m_MaxLumaHeightInPixels, m_MaxLumaWidthInPixels;
	UInt m_MaxChromaHeightInPixels, m_MaxChromaWidthInPixels;

	UInt m_ImgLumaHeight, m_ImgLumaWidth;
	UInt m_ImgChromaHeight, m_ImgChromaWidth;

	Double m_dLambda;

	XPel **m_OrgImgY, **m_RecImgY;
	XPel **m_OrgImgCb, **m_RecImgCb;
	XPel **m_OrgImgCr, **m_RecImgCr;
	int **t_OrgY_NMu, **t_OrgY_NSigma_sq;
	int **t_OrgCb_NMu, **t_OrgCb_NSigma_sq;
	int **t_OrgCr_NMu, **t_OrgCr_NSigma_sq;

	int **t_OrgY_sq, **t_RecY_sq, **t_CovY;
	int **t_OrgCb_sq, **t_RecCb_sq, **t_CovCb;
	int **t_OrgCr_sq, **t_RecCr_sq, **t_CovCr;

	void Allocate2DXPel(XPel ***mat, int height, int width);
	void Allocate2DInt32(int ***mat, int height, int width);
	void Delete2DXPel(XPel ***mat);
	void Delete2DInt32(int ***mat);

	static void ComputeRecPara(XPel **OrgImg, XPel **RecImg, int **Rec_sq, int **CovImg, UInt ImageWidth, 
		XPel *RecAddr, UInt iStride, UInt topleft_y, UInt topleft_x, UInt size_y, UInt size_x);

	static Double ComputeSSIM(XPel **OrgImg, int **Org_NMu, int **Org_NSigma_sq, 
		XPel **RecImg, int **Rec_sq, int **CovImg, 
		UInt y_min, UInt y_max_plus1, UInt x_min, UInt x_max_plus1, UInt ImageWidth);
};

#if defined SSIM_DISTORTION || defined SSIM_OUTPUT
extern xSSIMDistortion *z_SSIMDistortion;
#endif 


/*
#if defined( MSYS_WIN32 )
#pragma warning( default: 4275 )
#endif


H264AVC_NAMESPACE_END
*/

#endif __SSIM_DISTORTION_H__
