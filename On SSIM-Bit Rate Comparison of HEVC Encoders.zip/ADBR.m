function [R] = ADBR(SSIM, BR, SSIM_0, BR_0, Weight, SSIMRange)
% Ouput: ADBR (%)
% Input: SSIM[size],BR[size],SSIM_0[size],BR_0[size], size>=4
%        Weight[size] for fitting weights
%        SSIMRange[2]: 1: SSIM_min, 2: SSIM_max

N = 3; % cubic fit

if nargin < 4 || nargin > 6
    error('Invalid input: the number of arguments is invalid.');   
%    return;
end    
if size(SSIM,1) < size(SSIM,2)
    SSIM = SSIM';
end
if size(SSIM_0,1) < size(SSIM_0,2)
    SSIM_0 = SSIM_0';
end
if size(BR,1) < size(BR,2)
    BR = BR';
end
if size(BR_0,1) < size(BR_0,2)
    BR_0 = BR_0';
end  
M = size(SSIM,1);
if size(SSIM,2)~=1 || size(SSIM_0,2)~=1 || size(BR,2)~=1 || size(BR_0,2)~=1 ...
        || size(SSIM_0,1)~=M || size(BR,1)~=M || size(BR_0,1)~=M
    error('Invalid input: SSIM, BR, SSIM_0, BR_0 should be with size M*1.');   
%    return;
end  
if M <= N
    error('Invalid input: the size of SSIM, BR, SSIM_0, BR_0 should not larger than N.');   
%    return;
end  
if nargin == 4
    Weight = ones(M,1);
    SSIMRange = [max(min(SSIM),min(SSIM_0)); min(max(SSIM),max(SSIM_0))];    
end
if nargin == 5
    SSIMRange = [max(min(SSIM),min(SSIM_0)); min(max(SSIM),max(SSIM_0))];  
end
if size(Weight,1) < size(Weight,2)
    Weight = Weight';
end
if size(SSIMRange,1) < size(SSIMRange,2)
    SSIMRange = SSIMRange';
end
if size(Weight,1)~=M || size(Weight,2)~=1
    error('Invalid input: Weight should be with size M*1.');   
%    return;
end 
if size(SSIMRange,1)~=2 || size(SSIMRange,2)~=1 
    error('Invalid input: SSIMRange should be with size 2*1.');   
%    return;
end 
if SSIMRange(1)>=SSIMRange(2) 
    error('Invalid input: SSIMRange should be [BR_min, BR_max].');   
%    return;
end 

LogSSIM = -log10(1-SSIM);
LogSSIM_0 = -log10(1-SSIM_0);
LogBR = log10(BR);
LogBR_0 = log10(BR_0);
LogSSIM_min = -log10(1-SSIMRange(1));
LogSSIM_max = -log10(1-SSIMRange(2));
if nargin == 4
    % default: identical weight for all log(BR)s
    LogWeight = Weight;
    LogWeight_0 = Weight;
else
    LogWeight = Weight.*BR.*BR;
    LogWeight_0 = Weight.*BR_0.*BR_0;
end

p = polyfitweighted(LogSSIM, LogBR, N, LogWeight);
p_0 = polyfitweighted(LogSSIM_0, LogBR_0, N, LogWeight_0);
p_d = p - p_0;
F = @(x) p_d(1)*x.^3+p_d(2)*x.^2+p_d(3)*x+p_d(4);
R = quad(F,LogSSIM_min,LogSSIM_max)/(LogSSIM_max-LogSSIM_min);
  
R = (10^R -1)*100;

end

