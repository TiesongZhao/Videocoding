function [S] = ADSSIM(SSIM, BR, SSIM_0, BR_0, Weight, BRRange)
% Ouput: ADSSIM 
% Input: SSIM[size],BR[size],SSIM_0[size],BR_0[size], size>=4
%        Weight[size] for fitting weights
%        BRRange[2]: 1: BR_min, 2: BR_max

N = 3; % cubic fit

if nargin < 4 || nargin > 6
    error('Invalid input: the number of arguments is invalid.');   
%    return;
end    
if size(SSIM,1) < size(SSIM,2)
    SSIM = SSIM';
end
if size(SSIM_0,1) < size(SSIM_0,2)
    SSIM_0 = SSIM_0';
end
if size(BR,1) < size(BR,2)
    BR = BR';
end
if size(BR_0,1) < size(BR_0,2)
    BR_0 = BR_0';
end  
M = size(SSIM,1);
if size(SSIM,2)~=1 || size(SSIM_0,2)~=1 || size(BR,2)~=1 || size(BR_0,2)~=1 ...
        || size(SSIM_0,1)~=M || size(BR,1)~=M || size(BR_0,1)~=M
    error('Invalid input: SSIM, BR, SSIM_0, BR_0 should be with size M*1.');   
%    return;
end  
if M <= N
    error('Invalid input: the size of SSIM, BR, SSIM_0, BR_0 should not larger than N.');   
%    return;
end  
if nargin == 4
    % default: identical weight for all SSIMs
    Weight = ones(M,1);
    BRRange = [max(min(BR),min(BR_0)); min(max(BR),max(BR_0))];    
end
if nargin == 5
    BRRange = [max(min(BR),min(BR_0)); min(max(BR),max(BR_0))];
end
if size(Weight,1) < size(Weight,2)
    Weight = Weight';
end
if size(BRRange,1) < size(BRRange,2)
    BRRange = BRRange';
end
if size(Weight,1)~=M || size(Weight,2)~=1
    error('Invalid input: Weight should be with size M*1.');   
%    return;
end 
if size(BRRange,1)~=2 || size(BRRange,2)~=1 
    error('Invalid input: BRRange should be with size 2*1.');   
%    return;
end 
if BRRange(1)>=BRRange(2) 
    error('Invalid input: BRRange should be [BR_min, BR_max].');   
%    return;
end 

LogSSIM = -log10(1-SSIM);
LogSSIM_0 = -log10(1-SSIM_0);
LogBR = log10(BR);
LogBR_0 = log10(BR_0);
LogBR_min = log10(BRRange(1));
LogBR_max = log10(BRRange(2));
LogWeight = Weight.*(1-SSIM).*(1-SSIM);
LogWeight_0 = Weight.*(1-SSIM_0).*(1-SSIM_0);

p = polyfitweighted(LogBR, LogSSIM, N, LogWeight);
p_0 = polyfitweighted(LogBR_0, LogSSIM_0, N, LogWeight_0);
F = @(x) (1- 1./ 10.^(p(1)*x.^3+p(2)*x.^2+p(3)*x+p(4))) - ...
    (1- 1./ 10.^(p_0(1)*x.^3+p_0(2)*x.^2+p_0(3)*x+p_0(4)));
S = quad(F,LogBR_min,LogBR_max)/(LogBR_max-LogBR_min);

end

